# ARIES76 SERVICE CATALOG
## Comprehensive Service Offerings for GPs & LPs
### Strategic Expansion Beyond Fundraising

---

# PART 1: SERVICES FOR GPs (FUND MANAGERS)

---

## SERVICE LINE 1: DEAL SOURCING AS A SERVICE

### 1.1 Sector Monitoring Subscription

**What It Is:**
Real-time intelligence on fintech/AI companies across Europe, delivered through regular briefings and alerts.

**Deliverables:**
- Weekly deal flow digest (15-25 companies per week)
- Real-time alerts on funding rounds, key hires, product launches
- Monthly sector trend analysis
- Quarterly market map updates
- Direct access to Aries76 analyst for ad-hoc questions

**Target Client:**
- Growth-stage PE/VC funds with fintech/AI focus
- Corporate development teams at financial institutions
- Family offices building direct investment capabilities

**Pricing:**

| Tier | Coverage | Deliverables | Monthly Price | Annual Price |
|------|----------|--------------|---------------|--------------|
| **Essential** | 1 vertical (e.g., Payments) | Weekly digest, monthly analysis | €3,000 | €30,000 (17% discount) |
| **Professional** | 3 verticals | + Real-time alerts, analyst access | €5,000 | €50,000 (17% discount) |
| **Enterprise** | Full fintech/AI coverage | + Quarterly deep dives, custom requests | €8,000 | €80,000 (17% discount) |

**Cost Structure:**
- Analyst time: 20-40 hours/month per client
- Technology/data costs: €500-1,000/month
- Gross margin target: 65-75%

**Sales Approach:**
- Offer 2-week free trial with sample deliverables
- Upsell path: Essential → Professional → Enterprise
- Cross-sell to Deal Flow Partnership

---

### 1.2 Qualified Deal Flow Partnership

**What It Is:**
Proactive sourcing of investment opportunities that match the fund's specific thesis, with full qualification before introduction.

**Deliverables:**
- Customized sourcing criteria and ideal company profile
- Monthly pipeline of 10-20 pre-qualified opportunities
- Investment memo summary for each opportunity (2-3 pages)
- Warm introductions to founders/management
- Ongoing tracking of introduced companies

**Qualification Process:**
1. Initial screening (500+ companies/month) → 50-100 pass
2. Thesis alignment check → 20-30 match
3. Preliminary outreach and interest validation → 10-20 qualified
4. Investment memo preparation → Delivered to client

**Target Client:**
- PE/VC funds with €50M+ AUM
- Funds without dedicated sourcing teams
- Funds entering European market

**Pricing:**

| Model | Structure | Typical Annual Value |
|-------|-----------|---------------------|
| **Retainer Only** | €7,500/month | €90,000/year |
| **Retainer + Success** | €5,000/month + 1.5% success fee | €60,000 + variable |
| **Success Only** | 2.5% of invested capital | Variable (for established relationships only) |

**Success Fee Calculation:**
- Fee based on equity invested by client fund
- Paid at closing
- 12-month tail on introduced companies
- Exclusions: companies already in client's pipeline

**Minimum Commitment:** 6 months

---

### 1.3 Exclusive First-Look Program

**What It Is:**
Premium service offering exclusive, time-limited access to curated opportunities before they reach the broader market.

**Deliverables:**
- 3-5 exclusive opportunities per quarter
- 2-week exclusivity window for evaluation
- Full investment memo with financial model
- Management meeting facilitation
- Deal structuring support

**How We Source Exclusives:**
- Founder relationships developed over 26 years
- Companies seeking "smart money" not just capital
- Situations requiring discretion (spin-outs, special situations)
- Pre-market opportunities from accelerators/incubators

**Target Client:**
- Top-tier PE/VC funds willing to pay premium for quality
- Funds with rapid decision-making capability
- Strategic investors seeking proprietary deal flow

**Pricing:**

| Component | Amount |
|-----------|--------|
| Annual Access Fee | €50,000 |
| Success Fee | 2.0% of invested capital |
| Minimum Annual Commitment | €50,000 (access fee) |

**Exclusivity Terms:**
- Maximum 5 clients in program (to preserve exclusivity value)
- Non-competing mandates only (no two funds with identical thesis)
- 2-week response window required

---

## SERVICE LINE 2: PORTFOLIO SUPPORT SERVICES

### 2.1 Follow-on Fundraising for Portfolio Companies

**What It Is:**
Full-service fundraising support for GP portfolio companies raising Series A through Series C.

**Deliverables:**
- Fundraising strategy and timeline development
- Investor targeting and prioritization (200+ mapped)
- Materials preparation (deck, data room, model review)
- Investor outreach and meeting coordination
- Process management through term sheet and closing
- Negotiation support

**Process Timeline:**
- Week 1-2: Strategy and materials
- Week 3-4: Investor mapping and outreach launch
- Week 5-12: Meeting management and follow-ups
- Week 13-16: Term sheet negotiation and closing

**Target Client:**
- PE/VC funds seeking to maximize portfolio value
- Portfolio companies raising €5-50M
- Companies in fintech, AI, or adjacent sectors

**Pricing:**

| Round Size | Retainer | Success Fee | Total Potential |
|------------|----------|-------------|-----------------|
| €5-10M | €15,000 | 3.0% | €15K + €150-300K |
| €10-25M | €20,000 | 2.5% | €20K + €250-625K |
| €25-50M | €25,000 | 2.0% | €25K + €500K-1M |
| €50M+ | €30,000 | 1.5% | €30K + €750K+ |

**Payment Terms:**
- Retainer: 50% upfront, 50% at process launch
- Success fee: 100% at closing
- 12-month tail on investors introduced

---

### 2.2 Strategic Partnership Development

**What It Is:**
Identify and facilitate strategic partnerships for portfolio companies—customers, distribution partners, technology partners.

**Deliverables:**
- Partnership strategy workshop
- Target partner mapping (50-100 potential partners)
- Outreach and introduction facilitation
- Meeting preparation and support
- Deal structuring advisory
- Post-signing relationship support

**Partnership Types:**
- Commercial partnerships (distribution, reselling)
- Technology integrations
- Data partnerships
- Co-development agreements
- White-label arrangements

**Target Client:**
- Portfolio companies seeking growth acceleration
- Companies entering new markets
- B2B fintech needing distribution

**Pricing:**

| Engagement Type | Structure | Price |
|-----------------|-----------|-------|
| **Partnership Sprint** | 6-week intensive, 10 qualified intros | €25,000 flat fee |
| **Ongoing Partnership Development** | Monthly engagement, 5 intros/month | €8,000/month (6-month minimum) |
| **Success-Based** | Introductions + success fee | €5,000/month + €15-25K per signed partnership |

---

### 2.3 Exit Preparation & M&A Advisory

**What It Is:**
Comprehensive preparation for portfolio company exits—whether trade sale, secondary, or IPO track.

**Deliverables:**

**Phase 1: Exit Readiness Assessment (Month 1-2)**
- Strategic positioning analysis
- Buyer/acquirer landscape mapping
- Valuation benchmarking
- Gap analysis and remediation plan
- Timeline and process recommendation

**Phase 2: Exit Preparation (Month 3-6)**
- Management presentation development
- Data room preparation
- Financial model refinement
- Due diligence preparation
- Buyer relationship development

**Phase 3: Process Execution (Month 7-12)**
- Controlled auction or targeted approach
- Buyer outreach and management
- Due diligence coordination
- Negotiation support
- Closing coordination

**Target Client:**
- PE/VC funds with portfolio companies at exit stage
- Companies with €20M+ revenue or strategic value
- 3-5 year hold period situations

**Pricing:**

| Phase | Fee Structure |
|-------|---------------|
| **Exit Readiness Assessment** | €35,000 flat fee |
| **Full Exit Preparation** | €15,000/month (6-month engagement) |
| **M&A Execution** | 1.5-2.5% of transaction value (min €200,000) |
| **Combined Package** | €75,000 retainer + 1.5% success fee |

**Success Fee Scale:**

| Transaction Value | Success Fee |
|-------------------|-------------|
| Up to €50M | 2.5% |
| €50-100M | 2.0% |
| €100-250M | 1.5% |
| €250M+ | 1.0% (negotiable) |

---

## SERVICE LINE 3: MARKET INTELLIGENCE

### 3.1 Sector Deep Dive Reports

**What It Is:**
Comprehensive analysis of specific fintech/AI verticals, providing actionable intelligence for investment decisions.

**Report Contents:**
- Market sizing and growth projections
- Competitive landscape mapping (50-100 companies)
- Business model analysis
- Investment activity and valuations
- Regulatory landscape
- Key trends and predictions
- Target company profiles (10-15 detailed)

**Available Verticals:**
- Payments & Infrastructure
- Lending & Credit
- Wealthtech & Asset Management
- Insurtech
- RegTech & Compliance
- Embedded Finance
- B2B Financial Software
- Blockchain & Digital Assets
- AI/ML in Financial Services

**Pricing:**

| Report Type | Scope | Price | Delivery |
|-------------|-------|-------|----------|
| **Standard Report** | Single vertical, pan-European | €12,000 | 4 weeks |
| **Deep Dive** | Single vertical, specific geography | €18,000 | 6 weeks |
| **Custom Research** | Tailored scope and questions | €25,000+ | 6-8 weeks |
| **Annual Subscription** | 4 reports/year, choice of topics | €40,000/year | Quarterly |

**Add-on Services:**
- Presentation to investment committee: +€3,000
- Expert interviews (5 industry experts): +€5,000
- Quarterly update service: +€5,000/quarter

---

### 3.2 Competitive Intelligence

**What It Is:**
Detailed analysis of specific companies for investment evaluation, competitive positioning, or strategic planning.

**Deliverables:**

| Package | Contents | Price |
|---------|----------|-------|
| **Company Profile** | Business model, financials (estimated), team, funding history, competitive position | €3,500 |
| **Competitive Analysis** | Target company + 5 key competitors, positioning matrix, SWOT | €8,000 |
| **Full Due Diligence Support** | Comprehensive analysis, customer references, expert interviews, risk assessment | €20,000 |

**Turnaround:**
- Company Profile: 5 business days
- Competitive Analysis: 10 business days
- Full Due Diligence: 3-4 weeks

---

### 3.3 Valuation Benchmarking

**What It Is:**
Comparable company analysis and valuation framework for investment decisions or portfolio marking.

**Deliverables:**
- Comparable company set (10-20 companies)
- Trading and transaction multiples analysis
- Valuation range derivation
- Key value driver analysis
- Methodology documentation

**Pricing:**

| Service | Price |
|---------|-------|
| Single company valuation benchmark | €5,000 |
| Portfolio valuation review (up to 10 companies) | €25,000 |
| Quarterly portfolio marking service | €15,000/quarter |

---

# PART 2: SERVICES FOR LPs (INSTITUTIONAL INVESTORS)

---

## SERVICE LINE 4: FUND SELECTION & DUE DILIGENCE

### 4.1 GP Screening Service

**What It Is:**
Systematic identification and pre-qualification of PE/VC funds matching LP's investment criteria.

**Deliverables:**
- Customized screening criteria development
- Quarterly shortlist of 15-25 qualified funds
- Summary profiles on each fund (2-page brief)
- Preliminary assessment and recommendation
- Introduction facilitation to selected GPs

**Screening Criteria Examples:**
- Strategy and sector focus
- Fund size and vintage
- Geographic focus
- Track record (DPI, TVPI, IRR)
- Team composition and stability
- ESG/Impact considerations

**Target Client:**
- Pension funds, insurance companies, endowments
- Family offices building PE/VC allocations
- Fund of funds seeking deal flow

**Pricing:**

| Tier | Scope | Monthly Fee | Annual Fee |
|------|-------|-------------|------------|
| **Core** | Single strategy (e.g., European VC) | €6,000 | €60,000 |
| **Expanded** | Multiple strategies | €10,000 | €100,000 |
| **Comprehensive** | Full PE/VC coverage + emerging managers | €15,000 | €150,000 |

---

### 4.2 Fund Due Diligence

**What It Is:**
Comprehensive due diligence on specific PE/VC funds being considered for commitment.

**Deliverables:**

**Standard Due Diligence Package:**
- Investment strategy analysis
- Track record verification and attribution
- Team assessment (background checks, references)
- Portfolio company review (sample of 5-10)
- Operational due diligence
- Terms analysis and benchmarking
- ESG/responsible investment assessment
- Risk assessment and recommendation

**Enhanced Due Diligence (add-ons):**
- Extended reference program (15+ references)
- Site visits and GP meetings
- Legal review coordination
- Side letter negotiation support

**Pricing:**

| Package | Scope | Price | Timeline |
|---------|-------|-------|----------|
| **Express DD** | Key areas only, for re-ups or known GPs | €12,000 | 2 weeks |
| **Standard DD** | Full due diligence package | €25,000 | 4-5 weeks |
| **Enhanced DD** | Standard + enhanced add-ons | €40,000 | 6-8 weeks |
| **Emerging Manager DD** | First-time fund, extra scrutiny | €35,000 | 5-6 weeks |

**Volume Discounts:**
- 5+ funds/year: 10% discount
- 10+ funds/year: 20% discount

---

### 4.3 Reference Check Program

**What It Is:**
Comprehensive reference checking on GPs, including portfolio company executives, co-investors, and limited partners.

**Deliverables:**
- 10-15 structured reference calls
- Detailed notes and analysis
- Pattern identification and red flag assessment
- Summary report with recommendation
- Optional: Background verification

**Reference Categories:**
- Current and former portfolio company CEOs
- Co-investors and syndicate partners
- Current LPs (with appropriate permissions)
- Former team members
- Industry experts and advisors

**Pricing:**

| Package | References | Price |
|---------|------------|-------|
| **Core** | 10 references | €8,000 |
| **Extended** | 15 references | €12,000 |
| **Comprehensive** | 20+ references + background check | €18,000 |

---

## SERVICE LINE 5: PORTFOLIO MANAGEMENT SUPPORT

### 5.1 Fund Monitoring & Reporting

**What It Is:**
Ongoing monitoring and analysis of LP's PE/VC fund investments.

**Deliverables:**
- Quarterly performance analysis and commentary
- Benchmark comparison (Cambridge, Preqin, etc.)
- Cash flow tracking and forecasting
- Portfolio company monitoring (key holdings)
- GP communication summary
- Annual portfolio review presentation

**Target Client:**
- LPs with 10+ fund commitments
- Organizations without dedicated PE/VC staff
- Family offices seeking institutional-quality reporting

**Pricing:**

| Portfolio Size | Annual Fee |
|----------------|------------|
| Up to 15 funds | €30,000/year |
| 15-30 funds | €50,000/year |
| 30-50 funds | €75,000/year |
| 50+ funds | Custom pricing |

**Add-on Services:**
- Board/committee presentation: €5,000/presentation
- Ad-hoc analysis requests: €2,500 each
- GP meeting attendance: €1,500/meeting

---

### 5.2 Co-Investment Sourcing

**What It Is:**
Identify and facilitate co-investment opportunities from LP's existing GP relationships and broader network.

**Deliverables:**
- Co-investment strategy development
- Opportunity screening and qualification
- Due diligence support on selected deals
- Execution coordination
- Portfolio tracking of co-investments

**Process:**
1. Map LP's GP relationships and co-invest rights
2. Proactively engage GPs on upcoming opportunities
3. Screen opportunities against LP criteria
4. Present qualified opportunities with preliminary analysis
5. Support due diligence and execution

**Target Client:**
- LPs seeking to increase PE/VC exposure without incremental fees
- Investors with co-investment rights not fully utilized
- Family offices seeking direct deal flow

**Pricing:**

| Model | Structure |
|-------|-----------|
| **Retainer + Success** | €5,000/month + 1.0% of invested capital |
| **Success Only** | 1.5% of invested capital (minimum €50,000/deal) |
| **Annual Program** | €75,000/year + 0.75% success fee |

---

### 5.3 Secondary Advisory

**What It Is:**
Advisory services for LPs buying or selling PE/VC fund interests in the secondary market.

**Deliverables:**

**For Sellers:**
- Portfolio valuation and pricing guidance
- Buyer identification and outreach
- Process management
- Negotiation support
- Closing coordination

**For Buyers:**
- Opportunity sourcing
- Pricing analysis and bid preparation
- Due diligence on underlying funds
- Portfolio construction advice
- Execution support

**Pricing:**

| Transaction Type | Fee Structure |
|------------------|---------------|
| **Sell-side Advisory** | 1.0-1.5% of transaction value (min €75,000) |
| **Buy-side Advisory** | 0.75-1.0% of transaction value (min €50,000) |
| **Valuation Only** | €15,000 per fund (or €50,000 for portfolio) |

---

## SERVICE LINE 6: STRATEGIC ADVISORY

### 6.1 PE/VC Allocation Strategy

**What It Is:**
Help LPs design or optimize their private equity and venture capital investment program.

**Deliverables:**

**Phase 1: Assessment (4 weeks)**
- Current portfolio analysis
- Peer benchmarking
- Risk/return assessment
- Gap identification

**Phase 2: Strategy Development (6 weeks)**
- Target allocation framework
- Strategy mix optimization
- Geographic and sector allocation
- Manager selection criteria
- Pacing model development

**Phase 3: Implementation Planning (4 weeks)**
- Manager pipeline development
- Commitment schedule
- Operational requirements
- Reporting framework
- Governance recommendations

**Target Client:**
- Pension funds reviewing PE/VC allocation
- Insurance companies entering private markets
- Family offices professionalizing investment approach
- Endowments optimizing existing programs

**Pricing:**

| Engagement | Scope | Fee |
|------------|-------|-----|
| **Allocation Review** | Assessment only | €35,000 |
| **Strategy Development** | Assessment + strategy | €75,000 |
| **Full Program Design** | End-to-end, including implementation | €125,000 |

---

### 6.2 Emerging Manager Program Design

**What It Is:**
Design and implement a program for investing in first-time and emerging fund managers.

**Deliverables:**
- Program strategy and rationale
- Risk framework for emerging managers
- Screening and selection criteria
- Due diligence process design
- Legal/structural considerations
- Pipeline development (25-50 managers)
- Ongoing program management (optional)

**Why Emerging Managers:**
- Potential for alpha vs. established managers
- Access to differentiated strategies
- Relationship building for future funds
- Diversification benefits

**Pricing:**

| Engagement | Scope | Fee |
|------------|-------|-----|
| **Program Design** | Strategy and framework | €60,000 |
| **Design + Pipeline** | Above + initial manager pipeline | €90,000 |
| **Full Implementation** | Above + first-year program management | €150,000 |
| **Ongoing Management** | Annual program management | €75,000/year |

---

# PART 3: PRODUCTIZED SERVICES (FIXED SCOPE, FIXED PRICE)

---

## Quick-Turn Packaged Offerings

### For GPs

| Product | Description | Deliverables | Price | Timeline |
|---------|-------------|--------------|-------|----------|
| **Fund Positioning Audit** | Assess fund's market positioning and materials | Written report, materials feedback, 2-hour workshop | €15,000 | 2 weeks |
| **LP Readiness Assessment** | Evaluate readiness for institutional LP conversations | Gap analysis, remediation roadmap, template materials | €20,000 | 3 weeks |
| **European Market Entry Brief** | Landscape analysis for funds entering Europe | Market map, regulatory overview, target LP list | €25,000 | 4 weeks |
| **Co-Investor Mapping** | Identify potential co-investors for specific deal | 50 qualified co-investors, outreach templates | €10,000 | 10 days |
| **Competitor Teardown** | Detailed analysis of 3-5 competing funds | Positioning comparison, differentiation opportunities | €18,000 | 3 weeks |

### For LPs

| Product | Description | Deliverables | Price | Timeline |
|---------|-------------|--------------|-------|----------|
| **GP Landscape Map** | Overview of funds in specific strategy | 50+ fund profiles, shortlist of 10-15 | €20,000 | 3 weeks |
| **Portfolio Health Check** | Quick assessment of existing PE/VC portfolio | Performance analysis, risk flags, recommendations | €25,000 | 3 weeks |
| **Terms Benchmarking** | Analyze fund terms vs. market standards | Detailed comparison, negotiation recommendations | €8,000 | 1 week |
| **Reference Fast-Track** | Rapid reference check on specific GP | 8 references, summary report | €6,000 | 1 week |
| **Co-Investment Readiness** | Assess LP's ability to execute co-investments | Capability assessment, process recommendations | €15,000 | 2 weeks |

---

# PART 4: GO-TO-MARKET STRATEGY

---

## Phase 1: Service Launch Sequence (Months 1-6)

### Month 1-2: Core GP Services
**Launch:**
- Deal Sourcing Subscription (Sector Monitoring)
- Portfolio Company Fundraising

**Rationale:**
- Natural extension of current capabilities
- Immediate revenue potential
- Builds case studies for other services

**Target:** 3-5 GP clients

### Month 3-4: Intelligence Products
**Launch:**
- Sector Deep Dive Reports
- Competitive Intelligence

**Rationale:**
- Scalable revenue
- Positions Aries76 as thought leader
- Lower commitment barrier for new clients

**Target:** 5-10 report sales

### Month 5-6: LP Services
**Launch:**
- Fund Due Diligence
- GP Screening Service

**Rationale:**
- Higher-margin services
- Different buyer (diversifies revenue)
- Builds LP relationships for future

**Target:** 2-3 LP clients

---

## Phase 2: Expansion (Months 7-12)

### Add Services Based on Demand:
- Exit Preparation (when GP relationships mature)
- Co-Investment Sourcing (when LP relationships established)
- Secondary Advisory (opportunistic)

### Geographic Expansion:
- Nordics: High LP concentration, sophisticated buyers
- Switzerland: Family offices, wealth managers
- Germany: Insurance companies, pension funds

---

## Pricing Philosophy

### Value-Based Pricing Principles:
1. **Price to value delivered, not time spent**
2. **Offer tiered options** (good/better/best)
3. **Include success alignment** where possible
4. **Annual commitments** for recurring services (discount incentive)
5. **Premium for exclusivity** or speed

### Negotiation Guidelines:

| Client Request | Response |
|----------------|----------|
| "Can you lower the retainer?" | Offer success-only with higher % instead |
| "We want to try before committing" | Offer productized service as pilot |
| "This is more than we budgeted" | Offer phased approach or reduced scope |
| "What's the discount for annual?" | 15-20% is standard; preserve value |

---

## Sales Enablement Materials Needed

### Collateral to Develop:

| Material | Purpose | Priority |
|----------|---------|----------|
| Service Overview Brochure | General introduction | HIGH |
| GP Services One-Pager | Sales tool for fund managers | HIGH |
| LP Services One-Pager | Sales tool for institutional investors | HIGH |
| Sample Deliverables | Demonstrate quality (redacted) | HIGH |
| Case Studies | Prove track record | MEDIUM |
| Pricing Calculator | Interactive quoting tool | MEDIUM |
| FAQ Document | Handle common objections | MEDIUM |
| Contract Templates | Streamline closing | HIGH |

---

## Revenue Projections (Year 1)

### Conservative Scenario:

| Service Line | Clients | Avg. Revenue | Total |
|--------------|---------|--------------|-------|
| Sector Monitoring | 5 | €40,000 | €200,000 |
| Deal Flow Partnership | 3 | €80,000 | €240,000 |
| Portfolio Fundraising | 4 | €75,000 | €300,000 |
| Sector Reports | 12 | €15,000 | €180,000 |
| Fund Due Diligence | 6 | €25,000 | €150,000 |
| GP Screening | 2 | €60,000 | €120,000 |
| Productized Services | 15 | €15,000 | €225,000 |
| **TOTAL** | | | **€1,415,000** |

### Optimistic Scenario:

| Service Line | Clients | Avg. Revenue | Total |
|--------------|---------|--------------|-------|
| Sector Monitoring | 8 | €50,000 | €400,000 |
| Deal Flow Partnership | 5 | €100,000 | €500,000 |
| Portfolio Fundraising | 6 | €100,000 | €600,000 |
| Sector Reports | 20 | €15,000 | €300,000 |
| Fund Due Diligence | 10 | €28,000 | €280,000 |
| GP Screening | 4 | €75,000 | €300,000 |
| Co-Investment Sourcing | 2 | €100,000 | €200,000 |
| Productized Services | 25 | €15,000 | €375,000 |
| **TOTAL** | | | **€2,955,000** |

---

## Key Success Factors

1. **Start with what you know** - GP services first, leverage existing relationships
2. **Build proof points** - Every engagement should generate a case study
3. **Systematize delivery** - Create templates, checklists, processes
4. **Hire strategically** - Analyst support for research-heavy services
5. **Cross-sell relentlessly** - Every client should know all services
6. **Annual contracts** - Push for recurring revenue over one-off projects

---

*Aries76 Service Catalog | Confidential | January 2026*
