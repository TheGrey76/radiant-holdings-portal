# ARIES76 | SERVICES FOR LIMITED PARTNERS
## Independent Advisory for PE/VC Allocators

---

## THE LP CHALLENGE

Building and managing a PE/VC portfolio is resource-intensive. You need to source quality funds, conduct thorough due diligence, monitor performance, and optimize allocation—often with limited internal bandwidth and information asymmetry working against you.

**Aries76 levels the playing field.**

---

## OUR LP SERVICE SUITE

### 1. FUND SELECTION & DUE DILIGENCE

**Find the right funds. Avoid the wrong ones.**

| Service | What You Get | Investment |
|---------|--------------|------------|
| **GP Screening** | Quarterly shortlist of 15-25 qualified funds matching your criteria | From €6,000/month |
| **Fund Due Diligence** | Comprehensive DD package: strategy, track record, team, operations | From €12,000 per fund |
| **Reference Program** | 10-15 structured references on GP under consideration | From €8,000 per fund |

**Why It Works:**
- We see hundreds of funds; you see the best 20
- Institutional-grade DD process, regardless of your team size
- Independent perspective, no GP conflicts

---

### 2. PORTFOLIO MANAGEMENT SUPPORT

**Maximize value from existing commitments.**

| Service | What You Get | Investment |
|---------|--------------|------------|
| **Fund Monitoring** | Quarterly performance analysis, benchmarking, reporting | From €30,000/year |
| **Co-Investment Sourcing** | Proactive identification of co-invest opportunities | From €5,000/month + 1% success |
| **Secondary Advisory** | Buy-side or sell-side support for fund interest transactions | From 0.75% of transaction |

**Why It Works:**
- Consistent, institutional-quality reporting
- Unlock co-investment rights you're not fully utilizing
- Navigate secondary market with expert guidance

---

### 3. STRATEGIC ADVISORY

**Build or optimize your private markets program.**

| Service | What You Get | Investment |
|---------|--------------|------------|
| **Allocation Strategy** | Full program design: targets, pacing, manager selection | From €35,000 per project |
| **Emerging Manager Program** | Design and implement first-time fund strategy | From €60,000 per project |

**Why It Works:**
- Benefit from seeing hundreds of fund programs
- Objective advice, no product to sell
- Practical recommendations, not theoretical frameworks

---

## QUICK-WIN PACKAGES

Fixed scope, fixed price, fast delivery.

| Package | What It Solves | Price | Timeline |
|---------|----------------|-------|----------|
| **GP Landscape Map** | "Who's raising in my target strategy?" | €20,000 | 3 weeks |
| **Portfolio Health Check** | "How is my PE/VC portfolio really doing?" | €25,000 | 3 weeks |
| **Terms Benchmarking** | "Are these terms fair?" | €8,000 | 1 week |
| **Reference Fast-Track** | "Quick read on this GP" | €6,000 | 1 week |
| **Co-Investment Readiness** | "Can we execute co-invests effectively?" | €15,000 | 2 weeks |

---

## HOW WE ENGAGE

### Engagement Models

**Annual Retainer**
Ongoing support across multiple needs
*Best for: Active allocators, continuous pipeline*

**Project-Based**
Specific initiatives with clear scope
*Best for: Discrete needs, budget certainty*

**Transaction-Based**
Fee on specific outcomes (co-invests, secondaries)
*Best for: Aligned incentives, lower fixed cost*

---

## WHAT MAKES US DIFFERENT

| Placement Agents | Aries76 |
|------------------|---------|
| Paid by GPs | Paid by you (no conflicts) |
| Sell specific funds | Advise on your portfolio |
| Marketing materials | Independent analysis |
| Transaction-focused | Relationship-focused |

| Large Consultants | Aries76 |
|-------------------|---------|
| Generalist coverage | Fintech/AI specialist |
| Junior staff delivery | Senior-led engagement |
| Standardized process | Tailored approach |
| High overhead pricing | Efficient fee structure |

---

## IDEAL CLIENT PROFILE

We work best with:
- Pension funds, insurance companies, endowments with PE/VC allocation
- Family offices building institutional-quality programs
- Fund of funds seeking specialist support
- Organizations entering private markets or expanding allocation

---

## INDEPENDENCE MATTERS

**Aries76 is 100% independent.**

- We do not raise capital for GPs
- We do not receive placement fees
- We do not have affiliated funds
- Our only client is you

This means our advice is always in your interest—never influenced by what's easiest to sell.

---

## NEXT STEP

**30-minute consultation**

Let's discuss:
- Your current PE/VC program and challenges
- Where independent support could add value
- Specific services that match your needs

No commitment required.

---

**ARIES76**
Independent Advisor for Private Markets Allocators

🌐 www.aries76.com
📧 [contact email]

*London | Milan*
