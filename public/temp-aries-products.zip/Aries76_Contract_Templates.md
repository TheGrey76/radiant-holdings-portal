# ARIES76 CONTRACT TEMPLATES
## Standard Agreement Frameworks

---

# TEMPLATE 1: DEAL SOURCING PARTNERSHIP AGREEMENT

---

## DEAL SOURCING SERVICES AGREEMENT

**Between:**
- Aries76 Ltd ("Advisor")
- [Fund Name] ("Client")

**Effective Date:** [Date]

---

### 1. SERVICES

Advisor agrees to provide deal sourcing services to Client, including:

a) **Sector Monitoring:** Continuous monitoring of fintech/AI companies within agreed verticals
b) **Opportunity Identification:** Identification of potential investment targets meeting Client's criteria
c) **Preliminary Qualification:** Initial assessment of opportunities against Client's investment thesis
d) **Introduction Facilitation:** Warm introductions to qualified companies
e) **Monthly Reporting:** Written summary of pipeline activity and market observations

---

### 2. CLIENT INVESTMENT CRITERIA

Client's target investment profile:

| Criteria | Specification |
|----------|---------------|
| Sectors | [e.g., B2B Fintech, AI/ML Infrastructure] |
| Stage | [e.g., Series A - Series C] |
| Revenue | [e.g., €2M - €20M ARR] |
| Geography | [e.g., UK, Nordics, DACH] |
| Ticket Size | [e.g., €5M - €25M] |
| Exclusions | [e.g., Consumer fintech, Crypto] |

Client may update criteria with 30 days written notice.

---

### 3. FEES

**Option A: Retainer + Success Fee**

| Component | Amount |
|-----------|--------|
| Monthly Retainer | €[X],000 |
| Success Fee | [X]% of equity invested |

**Option B: Success Fee Only**

| Component | Amount |
|-----------|--------|
| Success Fee | [X]% of equity invested |
| Minimum Fee | €[X] per transaction |

---

### 4. SUCCESS FEE TERMS

4.1 **Triggering Event:** Success Fee is payable upon the closing of any investment by Client in a company introduced by Advisor.

4.2 **Definition of "Introduced":** A company is considered introduced if:
- Advisor provided the initial introduction, OR
- Advisor provided material information that led to Client's engagement with the company

4.3 **Tail Period:** Success Fee applies to investments closed within [12/18/24] months following the termination of this Agreement in companies introduced during the Agreement term.

4.4 **Exclusions:** Success Fee does not apply to:
- Companies already in Client's active pipeline as of Effective Date (see Exhibit A)
- Companies where Client had substantive prior contact

4.5 **Payment:** Success Fee is due within 30 days of investment closing.

---

### 5. TERM AND TERMINATION

5.1 **Initial Term:** [6/12] months from Effective Date

5.2 **Renewal:** Automatic renewal for successive [6/12] month periods unless terminated

5.3 **Termination:** Either party may terminate with [60/90] days written notice

5.4 **Effect of Termination:** 
- Retainer payments cease at termination
- Tail period for Success Fee survives termination
- Confidentiality obligations survive termination

---

### 6. CONFIDENTIALITY

6.1 Both parties agree to maintain confidentiality of all non-public information disclosed during the engagement.

6.2 Advisor shall not disclose Client's investment criteria or pipeline to third parties without consent.

6.3 Client shall not disclose Advisor's proprietary methodology or data sources.

---

### 7. EXCLUSIVITY

**Option A: Non-Exclusive**
This Agreement is non-exclusive. Client may engage other advisors for similar services.

**Option B: Exclusive (Sector-Specific)**
Client agrees not to engage other advisors for deal sourcing in [specified sectors] during the Agreement term.

---

### 8. REPRESENTATIONS

8.1 Advisor represents that it is not a registered broker-dealer and does not provide investment advice. Advisor's services are limited to sourcing and introduction.

8.2 Client is solely responsible for all investment decisions, due diligence, and compliance.

---

### 9. LIMITATION OF LIABILITY

Advisor's total liability under this Agreement shall not exceed fees paid by Client in the 12 months preceding any claim.

---

### 10. GOVERNING LAW

This Agreement is governed by the laws of [England and Wales / relevant jurisdiction].

---

**SIGNATURES**

For Aries76 Ltd:
_________________________ Date: _________
Name:
Title:

For [Client]:
_________________________ Date: _________
Name:
Title:

---

**EXHIBIT A: CLIENT'S EXISTING PIPELINE**

[List of companies already in Client's pipeline as of Effective Date, excluded from Success Fee]

---

# TEMPLATE 2: FUND DUE DILIGENCE ENGAGEMENT LETTER

---

## DUE DILIGENCE ENGAGEMENT LETTER

**To:** [LP Name]
**From:** Aries76 Ltd
**Date:** [Date]
**Re:** Due Diligence on [Fund Name]

---

### 1. ENGAGEMENT SCOPE

Aries76 Ltd ("Advisor") is pleased to confirm our engagement to conduct due diligence on [Fund Name] ("Subject Fund") on behalf of [LP Name] ("Client").

---

### 2. SERVICES

We will perform the following due diligence procedures:

**Standard Due Diligence Package includes:**

| Area | Scope |
|------|-------|
| **Investment Strategy** | Thesis analysis, market opportunity assessment, competitive positioning |
| **Track Record** | Performance verification, attribution analysis, loss analysis |
| **Team Assessment** | Background verification, team stability, succession planning |
| **Portfolio Review** | Sample of 5-7 investments, value creation analysis |
| **Operational DD** | Fund administration, compliance, valuation policy |
| **Terms Analysis** | Fee benchmarking, alignment assessment, key terms review |
| **ESG Assessment** | Policy review, integration approach, reporting |
| **Risk Assessment** | Key risks identified, mitigation factors |

**Deliverable:** Written due diligence report with recommendation

---

### 3. TIMELINE

| Milestone | Target Date |
|-----------|-------------|
| Engagement Start | [Date] |
| Initial Materials Review | +1 week |
| Management Meeting | +2 weeks |
| Reference Calls Complete | +3 weeks |
| Draft Report | +4 weeks |
| Final Report | +5 weeks |

Timeline assumes timely receipt of materials from Subject Fund.

---

### 4. FEES

| Service | Fee |
|---------|-----|
| Standard Due Diligence | €[25,000] |
| Expenses (travel, if required) | At cost, pre-approved |

**Payment Terms:**
- 50% upon engagement
- 50% upon delivery of final report

---

### 5. ADDITIONAL SERVICES (Optional)

| Service | Fee |
|---------|-----|
| Extended Reference Program (+10 references) | €[5,000] |
| On-site GP Visit | €[3,000] + travel |
| Legal Document Review Coordination | €[2,500] |
| Investment Committee Presentation | €[3,000] |

---

### 6. CLIENT RESPONSIBILITIES

Client agrees to:
- Provide any existing information on Subject Fund
- Facilitate introductions if helpful
- Review draft report within 5 business days
- Maintain confidentiality of our report and findings

---

### 7. INDEPENDENCE

Advisor confirms that:
- We have no financial relationship with Subject Fund or its GP
- We do not receive placement fees or other compensation from Subject Fund
- Our compensation is solely from Client as outlined above

---

### 8. LIMITATIONS

8.1 Our due diligence is based on information provided by Subject Fund, public sources, and our independent research. We do not audit financial statements or verify all representations.

8.2 Our report represents our professional opinion and should not be the sole basis for investment decisions.

8.3 This engagement does not constitute investment advice. Client is responsible for its own investment decisions.

---

### 9. CONFIDENTIALITY

Our report is confidential to Client and may not be shared with third parties without our consent, except as required by law or regulation.

---

### 10. ACCEPTANCE

Please confirm your acceptance by signing below and returning with the initial payment.

**For Aries76 Ltd:**

_________________________ Date: _________
[Name], [Title]

**Accepted and Agreed:**

_________________________ Date: _________
[Client Name]
[Title]
[Organization]

---

# TEMPLATE 3: INTELLIGENCE PRODUCT SUBSCRIPTION

---

## MARKET INTELLIGENCE SUBSCRIPTION AGREEMENT

**Between:**
- Aries76 Ltd ("Provider")
- [Client Name] ("Subscriber")

**Effective Date:** [Date]

---

### 1. SUBSCRIPTION SERVICE

Provider agrees to deliver the following intelligence products:

**☐ Sector Monitoring - Essential (€3,000/month)**
- Coverage: 1 vertical
- Weekly deal flow digest
- Monthly trend analysis

**☐ Sector Monitoring - Professional (€5,000/month)**
- Coverage: 3 verticals
- Weekly deal flow digest
- Real-time funding alerts
- Monthly trend analysis
- Analyst access (email support)

**☐ Sector Monitoring - Enterprise (€8,000/month)**
- Coverage: Full fintech/AI landscape
- All Professional features
- Quarterly deep dive reports
- Priority analyst access (call support)
- Custom research requests (2/quarter)

**Selected Verticals:**
1. _________________________
2. _________________________
3. _________________________

---

### 2. DELIVERABLES SCHEDULE

| Deliverable | Frequency | Delivery |
|-------------|-----------|----------|
| Deal Flow Digest | Weekly (Friday) | Email |
| Funding Alerts | Real-time | Email/Slack |
| Trend Analysis | Monthly (1st week) | PDF Report |
| Deep Dive Reports | Quarterly | PDF Report |

---

### 3. FEES AND PAYMENT

**Subscription Fee:** €[X],000 per month

**Payment Options:**

☐ **Monthly:** Due on 1st of each month
☐ **Annual (15% discount):** €[X] due upon signing

**Payment Method:** Bank transfer within 14 days of invoice

---

### 4. TERM

**Initial Term:** 12 months from Effective Date

**Renewal:** Automatic renewal for successive 12-month periods unless terminated with 90 days written notice.

**Price Adjustment:** Provider may adjust fees with 90 days notice prior to renewal.

---

### 5. INTELLECTUAL PROPERTY

5.1 All reports, data, and analysis remain the intellectual property of Provider.

5.2 Subscriber receives a non-exclusive, non-transferable license to use deliverables for internal purposes only.

5.3 Subscriber may not redistribute, resell, or publish deliverables without written consent.

---

### 6. DISCLAIMER

6.1 Intelligence products are provided for informational purposes only and do not constitute investment advice.

6.2 Provider does not guarantee accuracy or completeness of all information.

6.3 Subscriber is responsible for its own investment decisions.

---

### 7. CONFIDENTIALITY

Both parties agree to maintain confidentiality of proprietary information disclosed under this Agreement.

---

**SIGNATURES**

For Aries76 Ltd:
_________________________ Date: _________

For Subscriber:
_________________________ Date: _________

---

# TEMPLATE 4: PORTFOLIO COMPANY FUNDRAISING MANDATE

---

## FUNDRAISING ADVISORY MANDATE

**Between:**
- Aries76 Ltd ("Advisor")
- [Portfolio Company Name] ("Company")
- [Sponsoring Fund Name] ("Sponsor")

**Date:** [Date]

---

### 1. ENGAGEMENT

Advisor is engaged to provide fundraising advisory services to Company for its [Series X] financing round.

---

### 2. TARGET TRANSACTION

| Parameter | Target |
|-----------|--------|
| Round Size | €[X]M - €[X]M |
| Valuation Range | €[X]M - €[X]M (pre-money) |
| Target Investors | [Growth equity / Late-stage VC / Strategic] |
| Timeline | [X] months from engagement |

---

### 3. SERVICES

Advisor will provide:

a) **Strategy Development**
- Fundraising positioning and narrative
- Valuation framework and justification
- Timeline and process design

b) **Materials Preparation**
- Investor presentation review and enhancement
- Financial model review
- Data room organization guidance

c) **Investor Targeting**
- Identification of 150+ potential investors
- Prioritization and tiering
- Customized outreach strategy

d) **Process Management**
- Investor outreach and scheduling
- Meeting preparation and follow-up
- Due diligence coordination
- Term sheet review and comparison
- Negotiation support

e) **Closing Support**
- Documentation coordination
- Closing logistics

---

### 4. FEES

| Component | Amount |
|-----------|--------|
| **Retainer Fee** | €[20,000] |
| **Success Fee** | [2.5]% of capital raised |

**Retainer Payment:**
- 50% upon signing (€[10,000])
- 50% upon investor outreach launch (€[10,000])

**Success Fee Payment:**
- 100% upon closing of financing

**Minimum Success Fee:** €[100,000]

---

### 5. EXCLUSIVITY

During the term of this Agreement, Company agrees to work exclusively with Advisor on this financing round.

---

### 6. TERM

**Initial Term:** [6] months from Effective Date

**Extension:** May be extended by mutual agreement

**Termination:** 
- Either party may terminate with 30 days written notice
- Success Fee tail period of [12] months applies to investors introduced during engagement

---

### 7. SPONSOR ACKNOWLEDGMENT

Sponsor acknowledges and consents to this engagement and agrees to:
- Provide reasonable support and information access
- Participate in investor meetings as appropriate
- Not engage alternative advisors during the exclusivity period

---

**SIGNATURES**

For Aries76 Ltd:
_________________________ Date: _________

For Company:
_________________________ Date: _________

For Sponsor (Acknowledgment):
_________________________ Date: _________

---

*These templates are provided as starting frameworks and should be reviewed by legal counsel before use.*
