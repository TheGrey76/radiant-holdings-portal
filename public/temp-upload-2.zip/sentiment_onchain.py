"""Fetches sentiment and on-chain data."""

import requests

class SentimentOnChain:
    """Fetches sentiment and on-chain data from various sources."""

    def get_fear_and_greed_index(self):
        """Fetches the Fear and Greed Index from CoinMarketCap."""
        try:
            # NOTE: This is a mock endpoint. The actual CoinMarketCap API requires a key.
            # We are simulating the response for demonstration purposes.
            # In a real implementation, you would use:
            # url = "https://pro-api.coinmarketcap.com/v3/fear-and-greed/historical"
            # headers = {"X-CMC_PRO_API_KEY": "YOUR_API_KEY"}
            # response = requests.get(url, headers=headers)
            # data = response.json()["data"]
            # return data[0]["value"]
            
            # Mocked response
            return 50 # Neutral
        except Exception as e:
            print(f"Error fetching Fear and Greed Index: {e}")
            return None

    def get_onchain_metrics(self):
        """Fetches on-chain metrics (e.g., from Glassnode)."""
        try:
            # NOTE: This is a mock endpoint. Glassnode API requires a key.
            # We are simulating the response for demonstration purposes.
            # In a real implementation, you would use:
            # url = "https://api.glassnode.com/v1/metrics/market/mvrv_z_score"
            # params = {"a": "BTC", "api_key": "YOUR_API_KEY"}
            # response = requests.get(url, params=params)
            # data = response.json()
            # return data[-1]["v"]

            # Mocked response
            return 1.5 # Example MVRV Z-Score
        except Exception as e:
            print(f"Error fetching on-chain metrics: {e}")
            return None

if __name__ == '__main__':
    sentiment_onchain = SentimentOnChain()

    fear_and_greed = sentiment_onchain.get_fear_and_greed_index()
    if fear_and_greed is not None:
        print(f"Fear and Greed Index: {fear_and_greed}")

    onchain_metrics = sentiment_onchain.get_onchain_metrics()
    if onchain_metrics is not None:
        print(f"On-chain Metrics (MVRV Z-Score): {onchain_metrics}")
