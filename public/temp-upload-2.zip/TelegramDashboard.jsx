/**
 * ARIES76 Telegram Publication Dashboard
 * React Component for Lovable Integration
 * 
 * Manages and monitors Telegram channel publications
 */

import React, { useState, useEffect } from 'react';
import TelegramPublicationManager from './lovable_telegram_manager';

export default function TelegramDashboard() {
  const [manager] = useState(() => new TelegramPublicationManager({
    botToken: process.env.REACT_APP_TELEGRAM_BOT_TOKEN,
    channelId: '@aries76_bitcoin'
  }));

  const [publications, setPublications] = useState([]);
  const [logs, setLogs] = useState([]);
  const [activeTab, setActiveTab] = useState('schedule');
  const [formData, setFormData] = useState({
    time: '06:00',
    type: 'bitcoin',
    price: '$90,000',
    change24h: '+0.50%'
  });

  // Load publications on mount
  useEffect(() => {
    setPublications(manager.getPublicationHistory());
    setLogs(manager.getLogs());
  }, [manager]);

  // Refresh publications every minute
  useEffect(() => {
    const interval = setInterval(() => {
      manager.checkAndPublish();
      setPublications(manager.getPublicationHistory());
      setLogs(manager.getLogs());
    }, 60000);

    return () => clearInterval(interval);
  }, [manager]);

  const handleSchedulePublication = async (e) => {
    e.preventDefault();
    
    const data = {
      price: formData.price,
      change24h: formData.change24h
    };

    manager.schedulePublication(formData.time, formData.type, data);
    setPublications(manager.getPublicationHistory());
    
    // Reset form
    setFormData({
      time: '06:00',
      type: 'bitcoin',
      price: '$90,000',
      change24h: '+0.50%'
    });
  };

  const handlePublishNow = async () => {
    let message = '';
    
    switch (formData.type) {
      case 'bitcoin':
        message = manager.generateBitcoinAnalysis({
          price: formData.price,
          change24h: formData.change24h
        });
        break;
      case 'ethereum':
        message = manager.generateEthereumAnalysis({
          price: formData.price,
          change24h: formData.change24h
        });
        break;
      default:
        break;
    }

    if (message) {
      const result = await manager.publishMessage(message, formData.type);
      setPublications(manager.getPublicationHistory());
      setLogs(manager.getLogs());
      
      if (result.success) {
        alert('✅ Message published successfully!');
      } else {
        alert(`❌ Error: ${result.error}`);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            📱 ARIES76 Telegram Dashboard
          </h1>
          <p className="text-slate-400">
            Manage and monitor automated Telegram channel publications
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-slate-700">
          <button
            onClick={() => setActiveTab('schedule')}
            className={`px-4 py-2 font-semibold transition ${
              activeTab === 'schedule'
                ? 'text-blue-400 border-b-2 border-blue-400'
                : 'text-slate-400 hover:text-slate-300'
            }`}
          >
            📅 Schedule Publication
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 font-semibold transition ${
              activeTab === 'history'
                ? 'text-blue-400 border-b-2 border-blue-400'
                : 'text-slate-400 hover:text-slate-300'
            }`}
          >
            📊 Publication History
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`px-4 py-2 font-semibold transition ${
              activeTab === 'logs'
                ? 'text-blue-400 border-b-2 border-blue-400'
                : 'text-slate-400 hover:text-slate-300'
            }`}
          >
            📝 Logs
          </button>
        </div>

        {/* Schedule Tab */}
        {activeTab === 'schedule' && (
          <div className="bg-slate-800 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-white mb-6">Schedule New Publication</h2>
            
            <form onSubmit={handleSchedulePublication} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Time (HH:MM)
                  </label>
                  <input
                    type="time"
                    value={formData.time}
                    onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Type
                  </label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                  >
                    <option value="bitcoin">Bitcoin Analysis</option>
                    <option value="ethereum">Ethereum Analysis</option>
                    <option value="news">Digital Assets News</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Price
                  </label>
                  <input
                    type="text"
                    placeholder="$90,000"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    24h Change
                  </label>
                  <input
                    type="text"
                    placeholder="+0.50%"
                    value={formData.change24h}
                    onChange={(e) => setFormData({ ...formData, change24h: e.target.value })}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded text-white"
                  />
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition"
                >
                  📅 Schedule Publication
                </button>
                <button
                  type="button"
                  onClick={handlePublishNow}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition"
                >
                  🚀 Publish Now
                </button>
              </div>
            </form>
          </div>
        )}

        {/* History Tab */}
        {activeTab === 'history' && (
          <div className="bg-slate-800 rounded-lg p-6">
            <h2 className="text-2xl font-bold text-white mb-6">Publication History</h2>
            
            {publications.length === 0 ? (
              <p className="text-slate-400">No publications yet</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-700">
                      <th className="text-left py-2 px-4 text-slate-300">Time</th>
                      <th className="text-left py-2 px-4 text-slate-300">Type</th>
                      <th className="text-left py-2 px-4 text-slate-300">Status</th>
                      <th className="text-left py-2 px-4 text-slate-300">Published</th>
                    </tr>
                  </thead>
                  <tbody>
                    {publications.map((pub, idx) => (
                      <tr key={idx} className="border-b border-slate-700">
                        <td className="py-2 px-4 text-slate-300">{pub.time}</td>
                        <td className="py-2 px-4 text-slate-300">{pub.type}</td>
                        <td className="py-2 px-4">
                          <span className={`px-2 py-1 rounded text-xs font-bold ${
                            pub.status === 'published' ? 'bg-green-900 text-green-300' :
                            pub.status === 'failed' ? 'bg-red-900 text-red-300' :
                            'bg-yellow-900 text-yellow-300'
                          }`}>
                            {pub.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-2 px-4 text-slate-300">
                          {pub.published ? new Date(pub.published).toLocaleString() : '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Logs Tab */}
        {activeTab === 'logs' && (
          <div className="bg-slate-800 rounded-lg p-6">
            <h2 className="text-2xl font-bold text-white mb-6">System Logs</h2>
            
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {logs.length === 0 ? (
                <p className="text-slate-400">No logs yet</p>
              ) : (
                logs.map((log, idx) => (
                  <div key={idx} className="text-xs font-mono p-2 bg-slate-900 rounded">
                    <span className={`font-bold ${
                      log.level === 'error' ? 'text-red-400' :
                      log.level === 'success' ? 'text-green-400' :
                      'text-blue-400'
                    }`}>
                      [{log.level.toUpperCase()}]
                    </span>
                    <span className="text-slate-400"> {log.timestamp}</span>
                    <span className="text-slate-300"> {log.message}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Default Schedule */}
        <div className="mt-8 bg-slate-800 rounded-lg p-6">
          <h2 className="text-2xl font-bold text-white mb-4">📅 Default Schedule</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-700 rounded p-4">
              <p className="text-slate-400 text-sm">Morning</p>
              <p className="text-white font-bold">6:00 AM</p>
              <p className="text-slate-300 text-xs">Bitcoin Analysis</p>
            </div>
            <div className="bg-slate-700 rounded p-4">
              <p className="text-slate-400 text-sm">Mid-Morning</p>
              <p className="text-white font-bold">9:00 AM</p>
              <p className="text-slate-300 text-xs">Ethereum Analysis</p>
            </div>
            <div className="bg-slate-700 rounded p-4">
              <p className="text-slate-400 text-sm">Evening</p>
              <p className="text-white font-bold">6:00 PM</p>
              <p className="text-slate-300 text-xs">Digital Assets News</p>
            </div>
            <div className="bg-slate-700 rounded p-4">
              <p className="text-slate-400 text-sm">Late Evening</p>
              <p className="text-white font-bold">6:30 PM</p>
              <p className="text-slate-300 text-xs">Bitcoin Evening</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
