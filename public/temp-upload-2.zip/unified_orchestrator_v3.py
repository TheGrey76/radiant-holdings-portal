#!/usr/bin/env python3
"""
ARIES76 Unified Orchestrator V3
Automated Bitcoin analysis publishing with trending news
2x daily: 6:00 AM + 6:00 PM CET
"""

import asyncio
import logging
import schedule
import time
from datetime import datetime
from pathlib import Path
from enhanced_content_generator import EnhancedContentGenerator

logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'orchestrator_v3.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class UnifiedOrchestratorV3:
    """Orchestrate Bitcoin analysis publishing with trending news"""
    
    def __init__(self):
        self.generator = EnhancedContentGenerator()
        self.morning_time = "06:00"
        self.evening_time = "18:00"
        logger.info("Unified Orchestrator V3 initialized")
        logger.info(f"Schedule: {self.morning_time} AM CET + {self.evening_time} PM CET")
    
    async def publish_morning_analysis(self):
        """Publish morning Bitcoin analysis with trending news"""
        try:
            logger.info("=" * 70)
            logger.info("📤 MORNING ANALYSIS - GENERATING & PUBLISHING")
            logger.info("=" * 70)
            
            message = self.generator.generate_telegram_message_with_news()
            
            if not message:
                logger.error("Failed to generate morning message")
                return False
            
            result = await self._send_to_channel(message)
            
            if result:
                logger.info("✅ Morning analysis published successfully")
                logger.info(f"⏰ Published at: {datetime.now().isoformat()}")
                return True
            else:
                logger.error("Failed to publish morning analysis")
                return False
        except Exception as e:
            logger.error(f"Error in morning analysis: {e}")
            return False
    
    async def publish_evening_analysis(self):
        """Publish evening Bitcoin analysis with trending news"""
        try:
            logger.info("=" * 70)
            logger.info("📤 EVENING ANALYSIS - GENERATING & PUBLISHING")
            logger.info("=" * 70)
            
            message = self.generator.generate_news_focused_post()
            
            if not message:
                logger.error("Failed to generate evening message")
                return False
            
            result = await self._send_to_channel(message)
            
            if result:
                logger.info("✅ Evening analysis published successfully")
                logger.info(f"⏰ Published at: {datetime.now().isoformat()}")
                return True
            else:
                logger.error("Failed to publish evening analysis")
                return False
        except Exception as e:
            logger.error(f"Error in evening analysis: {e}")
            return False
    
    async def _send_to_channel(self, message):
        """Send message to Telegram channel"""
        try:
            import httpx
            
            token = "8269982447:AAGR7PM7Dkpbslb7eT-rAimj5puKxcEfaV8"
            channel = "@aries76_bitcoin"
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"https://api.telegram.org/bot{token}/sendMessage",
                    json={
                        "chat_id": channel,
                        "text": message,
                        "parse_mode": "HTML"
                    },
                    timeout=30
                )
                
                if response.status_code == 200:
                    logger.info("Message sent to Telegram successfully")
                    return True
                else:
                    logger.error(f"Telegram error: {response.text}")
                    return False
        except Exception as e:
            logger.error(f"Error sending to channel: {e}")
            return False
    
    def schedule_tasks(self):
        """Schedule daily tasks"""
        logger.info("Scheduling tasks...")
        
        schedule.every().day.at(self.morning_time).do(self._run_morning)
        schedule.every().day.at(self.evening_time).do(self._run_evening)
        
        logger.info(f"✓ Morning task scheduled at {self.morning_time} CET")
        logger.info(f"✓ Evening task scheduled at {self.evening_time} CET")
    
    def _run_morning(self):
        """Wrapper for morning task"""
        logger.info("Running morning task...")
        asyncio.run(self.publish_morning_analysis())
    
    def _run_evening(self):
        """Wrapper for evening task"""
        logger.info("Running evening task...")
        asyncio.run(self.publish_evening_analysis())
    
    def run(self):
        """Start the orchestrator"""
        logger.info("Starting Unified Orchestrator V3...")
        logger.info("Press Ctrl+C to stop")
        
        self.schedule_tasks()
        
        try:
            while True:
                schedule.run_pending()
                time.sleep(60)
        except KeyboardInterrupt:
            logger.info("Orchestrator stopped")
        except Exception as e:
            logger.error(f"Error: {e}")

def main():
    """Main entry point"""
    orchestrator = UnifiedOrchestratorV3()
    orchestrator.run()

if __name__ == '__main__':
    main()
