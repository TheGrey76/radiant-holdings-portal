#!/usr/bin/env python3
"""
Content generator for advanced analysis.

This module will use the data fetcher and calculator to generate a formatted message for Telegram.
"""

from advanced_data_fetcher import AdvancedDataFetcher
from advanced_analysis_calculator import AdvancedAnalysisCalculator

class AdvancedContentGenerator:
    def __init__(self, symbol, correlation_assets=None):
        self.symbol = symbol
        self.fetcher = AdvancedDataFetcher()
        self.historical_data = self.fetcher.get_historical_data(symbol)
        self.order_book = self.fetcher.get_order_book(f"{symbol.split('-')[0]}USDT") # Assuming USDT pair for order book
        self.correlation_assets_data = {name: self.fetcher.get_historical_data(name) for name in correlation_assets}
        self.calculator = AdvancedAnalysisCalculator(self.historical_data, self.correlation_assets_data, self.order_book)

    def generate_message(self):
        """Generates a formatted message with the advanced analysis."""
        pivot_points = self.calculator.calculate_pivot_points().iloc[-1]
        correlations = self.calculator.calculate_correlation()
        inversion_signals = self.calculator.find_inversion_signals()
        liquidity = self.calculator.analyze_liquidity()
        volume_analysis = self.calculator.analyze_volume()

        message = f"📈 **Analisi Avanzata per {self.symbol}** 📈\n\n"
        message += f"**Livelli Pivot (Giornalieri):**\n"
        message += f"- Pivot: {pivot_points['pivot']:.2f}\n"
        message += f"- R1: {pivot_points['r1']:.2f}, S1: {pivot_points['s1']:.2f}\n"
        message += f"- R2: {pivot_points['r2']:.2f}, S2: {pivot_points['s2']:.2f}\n\n"

        if correlations:
            message += f"**Correlazione (30gg):**\n"
            for asset, corr in correlations.items():
                message += f"- vs {asset}: {corr:.2f}\n"
            message += "\n"

        message += f"**Segnali di Inversione:**\n"
        message += f"- RSI (14): {inversion_signals['rsi']:.2f}\n\n"

        if liquidity:
            message += f"**Livelli di Liquidità (Top 5):**\n"
            message += f"**Bids (Supporti):**\n"
            for _, row in liquidity['bids'].iterrows():
                message += f"- Prezzo: {row['price']:.2f}, Size: {row['size']}\n"
            message += f"**Asks (Resistenze):**\n"
            for _, row in liquidity['asks'].iterrows():
                message += f"- Prezzo: {row['price']:.2f}, Size: {row['size']}\n"
            message += "\n"

        message += f"**Analisi dei Volumi:**\n"
        message += f"- MFI: {volume_analysis['mfi']:.2f}\n"
        message += f"- OBV: {volume_analysis['obv']:.2f}\n\n"

        message += "Vuoi un'analisi ancora più dettagliata? Scopri il nostro report completo!\n"
        message += "https://www.aries76.com/bitcoin-2026-report-preview"

        return message

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--symbol', required=True)
    parser.add_argument('--correlation_assets', default='')
    args = parser.parse_args()

    correlation_assets = args.correlation_assets.split(',') if args.correlation_assets else []

    generator = AdvancedContentGenerator(args.symbol, correlation_assets=correlation_assets)
    message = generator.generate_message()
    print(message)
