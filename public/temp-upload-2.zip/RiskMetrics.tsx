import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, Shield } from 'lucide-react';

interface RiskData {
  model: string;
  sharpe_ratio: number;
  sortino_ratio: number;
  var_95: number;
  cvar_95: number;
  timestamp: string;
}

interface RiskMetricsProps {
  modelName: 'conservative' | 'balanced' | 'aggressive';
}

export const RiskMetrics: React.FC<RiskMetricsProps> = ({ modelName }) => {
  const [riskData, setRiskData] = useState<RiskData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRiskData();
  }, [modelName]);

  const fetchRiskData = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/portfolio-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: modelName, action: 'risk' })
      });
      const data = await response.json();
      setRiskData(data);
    } catch (error) {
      console.error('Error fetching risk data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>;
  }

  if (!riskData) {
    return <div className="text-red-500">Failed to load risk data</div>;
  }

  const metrics = [
    {
      name: 'Sharpe Ratio',
      value: riskData.sharpe_ratio.toFixed(2),
      icon: TrendingUp,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      name: 'Sortino Ratio',
      value: riskData.sortino_ratio.toFixed(2),
      icon: TrendingUp,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      name: 'Value at Risk (95%)',
      value: `${(riskData.var_95 * 100).toFixed(2)}%`,
      icon: AlertTriangle,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    },
    {
      name: 'CVaR (95%)',
      value: `${(riskData.cvar_95 * 100).toFixed(2)}%`,
      icon: Shield,
      color: 'text-red-600',
      bgColor: 'bg-red-100'
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold mb-6 capitalize">{modelName} Risk Metrics</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{metric.name}</p>
                  <p className={`text-2xl font-bold ${metric.color}`}>{metric.value}</p>
                </div>
                <div className={`${metric.bgColor} p-3 rounded-full`}>
                  <Icon className={`w-6 h-6 ${metric.color}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-6 text-sm text-gray-500">
        Last updated: {new Date(riskData.timestamp).toLocaleString()}
      </div>
    </div>
  );
};
