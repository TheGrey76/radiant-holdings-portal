#!/usr/bin/env python3
"""
Test script for Bitcoin Content Automation
Tests all components and generates sample content
"""

import sys
import os
import json
import logging
from datetime import datetime

# Add project to path
sys.path.insert(0, '/home/ubuntu/bitcoin_automation')

from bitcoin_content_generator import BitcoinDataCollector, AIContentGenerator, ContentPackage
from image_generator import SocialMediaImageGenerator
from social_media_publisher import ContentPublisher

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def test_data_collection():
    """Test Bitcoin data collection"""
    
    logger.info("=" * 70)
    logger.info("TEST 1: Bitcoin Data Collection")
    logger.info("=" * 70)
    
    try:
        collector = BitcoinDataCollector()
        context = collector.compile_context()
        
        logger.info(f"✓ Data collection successful")
        logger.info(f"  - BTC Price: ${context['price']:,.2f}")
        logger.info(f"  - 24h Change: {context['price_change_24h']:+.2f}%")
        logger.info(f"  - BTC Dominance: {context['btc_dominance']:.1f}%")
        logger.info(f"  - Fear & Greed: {context['fear_greed_index']:.0f}/100")
        
        return True, context
        
    except Exception as e:
        logger.error(f"✗ Data collection failed: {e}")
        return False, None


def test_content_generation(context):
    """Test AI content generation"""
    
    logger.info("=" * 70)
    logger.info("TEST 2: AI Content Generation")
    logger.info("=" * 70)
    
    try:
        generator = AIContentGenerator()
        
        # Generate blog article
        logger.info("Generating blog article...")
        article = generator.generate_blog_article(context)
        if article:
            logger.info(f"✓ Blog article generated ({len(article)} characters)")
        else:
            logger.warning("✗ Blog article generation returned empty")
        
        # Generate LinkedIn posts
        logger.info("Generating LinkedIn posts...")
        linkedin_posts = [
            generator.generate_linkedin_post(context, "insight"),
            generator.generate_linkedin_post(context, "analysis")
        ]
        logger.info(f"✓ Generated {len(linkedin_posts)} LinkedIn posts")
        
        # Generate Twitter posts
        logger.info("Generating Twitter posts...")
        twitter_posts = generator.generate_twitter_posts(context, 3)
        logger.info(f"✓ Generated {len(twitter_posts)} Twitter posts")
        
        return True, {
            'article': article,
            'linkedin_posts': linkedin_posts,
            'twitter_posts': twitter_posts
        }
        
    except Exception as e:
        logger.error(f"✗ Content generation failed: {e}")
        return False, None


def test_image_generation(context):
    """Test image generation"""
    
    logger.info("=" * 70)
    logger.info("TEST 3: Image Generation")
    logger.info("=" * 70)
    
    try:
        image_gen = SocialMediaImageGenerator()
        
        # Generate Twitter image
        logger.info("Generating Twitter image...")
        twitter_image = image_gen.generate_twitter_image(context, "")
        logger.info(f"✓ Twitter image created: {twitter_image}")
        
        # Generate Instagram image
        logger.info("Generating Instagram image...")
        instagram_image = image_gen.generate_instagram_image(context)
        logger.info(f"✓ Instagram image created: {instagram_image}")
        
        # Generate LinkedIn image
        logger.info("Generating LinkedIn image...")
        linkedin_image = image_gen.generate_linkedin_image(context, "Bitcoin market analysis")
        logger.info(f"✓ LinkedIn image created: {linkedin_image}")
        
        return True, {
            'twitter': twitter_image,
            'instagram': instagram_image,
            'linkedin': linkedin_image
        }
        
    except Exception as e:
        logger.error(f"✗ Image generation failed: {e}")
        return False, None


def test_publishing_setup():
    """Test publishing setup"""
    
    logger.info("=" * 70)
    logger.info("TEST 4: Publishing Setup")
    logger.info("=" * 70)
    
    try:
        publisher = ContentPublisher()
        
        # Check credentials
        linkedin_configured = bool(os.getenv("LINKEDIN_ACCESS_TOKEN"))
        twitter_configured = bool(os.getenv("TWITTER_BEARER_TOKEN"))
        instagram_configured = bool(os.getenv("INSTAGRAM_ACCESS_TOKEN"))
        
        logger.info(f"LinkedIn configured: {'✓' if linkedin_configured else '✗'}")
        logger.info(f"Twitter configured: {'✓' if twitter_configured else '✗'}")
        logger.info(f"Instagram configured: {'✓' if instagram_configured else '✗'}")
        
        if not (linkedin_configured or twitter_configured or instagram_configured):
            logger.warning("⚠ No social media platforms configured")
            logger.warning("  Please set up API credentials in .env file")
        
        return True, {
            'linkedin': linkedin_configured,
            'twitter': twitter_configured,
            'instagram': instagram_configured
        }
        
    except Exception as e:
        logger.error(f"✗ Publishing setup test failed: {e}")
        return False, None


def test_file_structure():
    """Test project file structure"""
    
    logger.info("=" * 70)
    logger.info("TEST 5: Project File Structure")
    logger.info("=" * 70)
    
    required_files = [
        '/home/ubuntu/bitcoin_automation/bitcoin_content_generator.py',
        '/home/ubuntu/bitcoin_automation/social_media_publisher.py',
        '/home/ubuntu/bitcoin_automation/image_generator.py',
        '/home/ubuntu/bitcoin_automation/automation_orchestrator.py',
        '/home/ubuntu/bitcoin_automation/scheduler.py',
        '/home/ubuntu/bitcoin_automation/requirements.txt',
        '/home/ubuntu/bitcoin_automation/.env.example'
    ]
    
    all_exist = True
    for file_path in required_files:
        exists = os.path.exists(file_path)
        status = '✓' if exists else '✗'
        logger.info(f"{status} {os.path.basename(file_path)}")
        if not exists:
            all_exist = False
    
    required_dirs = [
        '/home/ubuntu/bitcoin_automation/logs',
        '/home/ubuntu/bitcoin_automation/generated_content',
        '/home/ubuntu/bitcoin_automation/generated_images'
    ]
    
    for dir_path in required_dirs:
        os.makedirs(dir_path, exist_ok=True)
        logger.info(f"✓ Directory ready: {os.path.basename(dir_path)}")
    
    return all_exist, None


def run_all_tests():
    """Run all tests"""
    
    logger.info("\n")
    logger.info("╔" + "=" * 68 + "╗")
    logger.info("║" + " " * 15 + "BITCOIN AUTOMATION SYSTEM TEST SUITE" + " " * 17 + "║")
    logger.info("╚" + "=" * 68 + "╝")
    logger.info("\n")
    
    results = {}
    
    # Test 1: File structure
    success, _ = test_file_structure()
    results['file_structure'] = success
    
    if not success:
        logger.error("✗ Project structure incomplete. Please check installation.")
        return False
    
    # Test 2: Data collection
    success, context = test_data_collection()
    results['data_collection'] = success
    
    if not success:
        logger.error("✗ Cannot proceed without Bitcoin data. Check internet connection.")
        return False
    
    # Test 3: Content generation
    success, content = test_content_generation(context)
    results['content_generation'] = success
    
    if not success:
        logger.error("✗ Content generation failed. Check OpenAI API key.")
        return False
    
    # Test 4: Image generation
    success, images = test_image_generation(context)
    results['image_generation'] = success
    
    # Test 5: Publishing setup
    success, publishing = test_publishing_setup()
    results['publishing_setup'] = success
    
    # Summary
    logger.info("\n")
    logger.info("=" * 70)
    logger.info("TEST SUMMARY")
    logger.info("=" * 70)
    
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for test_name, result in results.items():
        status = '✓ PASS' if result else '✗ FAIL'
        logger.info(f"{status}: {test_name}")
    
    logger.info(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        logger.info("\n✓ All tests passed! System is ready for deployment.")
        return True
    else:
        logger.warning(f"\n⚠ {total - passed} test(s) failed. Please review the errors above.")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
