#!/usr/bin/env python3
"""
Bitcoin Report Content Generator
Automated daily content generation with AI and real-time Bitcoin data
"""

import os
import json
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
from openai import OpenAI
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/ubuntu/bitcoin_automation/logs/content_generation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class BitcoinDataCollector:
    """Collect real-time Bitcoin data from multiple sources"""
    
    def __init__(self):
        self.coingecko_base = "https://api.coingecko.com/api/v3"
        self.newsapi_key = os.getenv("NEWSAPI_KEY", "")
        
    def get_bitcoin_price_data(self) -> Dict:
        """Fetch current Bitcoin price and market data"""
        try:
            url = f"{self.coingecko_base}/simple/price"
            params = {
                "ids": "bitcoin",
                "vs_currencies": "usd",
                "include_market_cap": "true",
                "include_24hr_vol": "true",
                "include_24hr_change": "true",
                "include_last_updated_at": "true"
            }
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()["bitcoin"]
            logger.info(f"Bitcoin price: ${data['usd']:,.2f}")
            return data
        except Exception as e:
            logger.error(f"Error fetching Bitcoin price: {e}")
            return {}
    
    def get_market_data(self) -> Dict:
        """Fetch broader market data"""
        try:
            url = f"{self.coingecko_base}/global"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            data = response.json()["data"]
            return {
                "btc_dominance": data.get("btc_dominance", 0),
                "total_market_cap": data.get("total_market_cap", {}).get("usd", 0),
                "market_cap_change_24h": data.get("market_cap_change_percentage_24h_usd", 0),
                "fear_greed_index": self.get_fear_greed_index()
            }
        except Exception as e:
            logger.error(f"Error fetching market data: {e}")
            return {}
    
    def get_fear_greed_index(self) -> float:
        """Fetch Fear & Greed Index"""
        try:
            url = "https://api.alternative.me/fng/"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            data = response.json()["data"][0]
            return float(data["value"])
        except Exception as e:
            logger.warning(f"Error fetching Fear & Greed Index: {e}")
            return 50.0
    
    def get_bitcoin_news(self, limit: int = 5) -> List[Dict]:
        """Fetch recent Bitcoin news"""
        try:
            url = "https://newsapi.org/v2/everything"
            params = {
                "q": "Bitcoin",
                "sortBy": "publishedAt",
                "language": "en",
                "pageSize": limit,
                "apiKey": self.newsapi_key
            }
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            articles = response.json().get("articles", [])
            logger.info(f"Fetched {len(articles)} Bitcoin news articles")
            return articles
        except Exception as e:
            logger.warning(f"Error fetching news: {e}")
            return []
    
    def compile_context(self) -> Dict:
        """Compile all data into context for AI generation"""
        logger.info("Compiling Bitcoin market context...")
        
        price_data = self.get_bitcoin_price_data()
        market_data = self.get_market_data()
        news = self.get_bitcoin_news()
        
        context = {
            "timestamp": datetime.now().isoformat(),
            "price": price_data.get("usd", 0),
            "market_cap": price_data.get("usd_market_cap", 0),
            "volume_24h": price_data.get("usd_24h_vol", 0),
            "price_change_24h": price_data.get("usd_24h_change", 0),
            "btc_dominance": market_data.get("btc_dominance", 0),
            "fear_greed_index": market_data.get("fear_greed_index", 50),
            "market_cap_change_24h": market_data.get("market_cap_change_24h", 0),
            "recent_news": [
                {
                    "title": article["title"],
                    "description": article["description"],
                    "source": article["source"]["name"]
                }
                for article in news[:3]
            ]
        }
        
        logger.info(f"Context compiled: BTC ${context['price']:,.2f}, "
                   f"Dominance {context['btc_dominance']:.1f}%, "
                   f"Fear/Greed {context['fear_greed_index']:.0f}")
        
        return context


class AIContentGenerator:
    """Generate content using OpenAI API"""
    
    def __init__(self):
        self.client = OpenAI()
        self.model = "gpt-4.1-mini"
        
    def generate_blog_article(self, context: Dict) -> str:
        """Generate a blog article about Bitcoin market"""
        
        prompt = self._build_article_prompt(context)
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": """You are an expert Bitcoin analyst and financial writer. 
                        Your content is divulgative but persuasive, designed to help readers understand 
                        Bitcoin market dynamics while highlighting the value of professional analysis and reports.
                        Write in clear, engaging language suitable for both beginners and experienced investors.
                        Always include a subtle call-to-action about the importance of data-driven investment decisions."""
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=1500
            )
            
            article = response.choices[0].message.content
            logger.info("Blog article generated successfully")
            return article
            
        except Exception as e:
            logger.error(f"Error generating blog article: {e}")
            return ""
    
    def generate_linkedin_post(self, context: Dict, post_type: str = "insight") -> str:
        """Generate a LinkedIn post"""
        
        prompt = self._build_linkedin_prompt(context, post_type)
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": """You are a professional financial analyst writing for LinkedIn.
                        Your posts are insightful, data-driven, and designed to engage Limited Partners and investors.
                        Use a professional tone without emojis. Keep posts self-contained and valuable.
                        Include relevant metrics or data points. Rotate between different formats:
                        - Market insights and trends
                        - Data analysis commentary
                        - Strategic perspectives on Bitcoin
                        - Thought leadership on crypto investment"""
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=500
            )
            
            post = response.choices[0].message.content.strip()
            
            # Enforce character limit for LinkedIn engagement (max 300 chars)
            max_chars = 300
            if len(post) > max_chars:
                # Truncate and add ellipsis if needed
                post = post[:max_chars-3] + "..."
                logger.warning(f"LinkedIn post truncated to {max_chars} characters")
            
            logger.info(f"LinkedIn post ({post_type}) generated: {len(post)} characters")
            return post
            
        except Exception as e:
            logger.error(f"Error generating LinkedIn post: {e}")
            return ""
    
    def generate_twitter_posts(self, context: Dict, count: int = 3) -> List[str]:
        """Generate Twitter/X posts"""
        
        posts = []
        post_themes = [
            "market_update",
            "technical_insight",
            "engagement_question"
        ]
        
        for i in range(min(count, len(post_themes))):
            prompt = self._build_twitter_prompt(context, post_themes[i])
            
            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {
                            "role": "system",
                            "content": """You are a Bitcoin market expert writing for Twitter/X.
                            Keep posts concise, engaging, and data-driven.
                            Use clear language, avoid excessive jargon.
                            Include relevant hashtags. Posts should be under 280 characters when possible.
                            Include a call-to-action or thought-provoking question where appropriate."""
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    temperature=0.7,
                    max_tokens=300
                )
                
                post = response.choices[0].message.content
                posts.append(post)
                logger.info(f"Twitter post ({post_themes[i]}) generated successfully")
                
            except Exception as e:
                logger.error(f"Error generating Twitter post {i+1}: {e}")
        
        return posts
    
    def _build_article_prompt(self, context: Dict) -> str:
        """Build prompt for blog article"""
        
        news_summary = "\n".join([
            f"- {article['title']}: {article['description'][:100]}..."
            for article in context.get("recent_news", [])
        ])
        
        return f"""Write an engaging blog article about Bitcoin market analysis based on current data:

Current Bitcoin Price: ${context['price']:,.2f}
24h Change: {context['price_change_24h']:.2f}%
Market Cap: ${context['market_cap']:,.0f}
BTC Dominance: {context['btc_dominance']:.1f}%
Fear & Greed Index: {context['fear_greed_index']:.0f}/100
Recent News:
{news_summary}

Requirements:
- Title and subtitle
- 800-1200 words
- Divulgative but persuasive tone
- Include data analysis
- Highlight importance of professional analysis
- Include subtle CTA about the value of detailed reports
- Use clear, accessible language
- Include actionable insights

Article:"""
    
    def _build_linkedin_prompt(self, context: Dict, post_type: str) -> str:
        """Build prompt for LinkedIn post"""
        
        type_guidance = {
            "insight": "Share a market insight based on current Bitcoin data and trends",
            "analysis": "Provide data-driven analysis of Bitcoin market dynamics",
            "perspective": "Share a strategic perspective on Bitcoin as an investment asset"
        }
        
        return f"""Write a professional LinkedIn post:

{type_guidance.get(post_type, type_guidance['insight'])}

Current Data:
- Bitcoin Price: ${context['price']:,.2f} ({context['price_change_24h']:+.2f}%)
- BTC Dominance: {context['btc_dominance']:.1f}%
- Fear & Greed: {context['fear_greed_index']:.0f}/100

Requirements:
- Professional tone, no emojis
- Self-contained and valuable
- Include relevant metrics
- Suitable for Limited Partners and investors
- MAXIMUM 300 CHARACTERS (this is critical for LinkedIn engagement)
- Subtle mention of data-driven decision making
- Concise and impactful

Post:"""
    
    def _build_twitter_prompt(self, context: Dict, theme: str) -> str:
        """Build prompt for Twitter post"""
        
        theme_guidance = {
            "market_update": f"Tweet about Bitcoin's current price (${context['price']:,.2f}) and market movement",
            "technical_insight": f"Share a technical insight about Bitcoin market dynamics (Dominance: {context['btc_dominance']:.1f}%)",
            "engagement_question": "Ask an engaging question about Bitcoin investment strategy or market outlook"
        }
        
        return f"""Write a Twitter/X post:

{theme_guidance.get(theme, theme_guidance['market_update'])}

Current Context:
- BTC: ${context['price']:,.2f} ({context['price_change_24h']:+.2f}%)
- Dominance: {context['btc_dominance']:.1f}%
- Fear/Greed: {context['fear_greed_index']:.0f}/100

Requirements:
- Under 280 characters
- Engaging and data-driven
- Include relevant hashtags
- Clear, accessible language
- Include CTA or thought-provoking element

Tweet:"""


class ContentPackage:
    """Package generated content for publishing"""
    
    def __init__(self, context: Dict, article: str, linkedin_posts: List[str], twitter_posts: List[str]):
        self.context = context
        self.article = article
        self.linkedin_posts = linkedin_posts
        self.twitter_posts = twitter_posts
        self.generated_at = datetime.now()
    
    def save_to_file(self, output_dir: str = "/home/ubuntu/bitcoin_automation/generated_content") -> Dict:
        """Save generated content to files"""
        
        os.makedirs(output_dir, exist_ok=True)
        
        timestamp = self.generated_at.strftime("%Y%m%d_%H%M%S")
        
        files = {}
        
        # Save article
        article_file = os.path.join(output_dir, f"article_{timestamp}.md")
        with open(article_file, 'w') as f:
            f.write(f"# Bitcoin Market Analysis - {self.generated_at.strftime('%Y-%m-%d')}\n\n")
            f.write(f"Generated: {self.generated_at.isoformat()}\n\n")
            f.write(f"**BTC Price:** ${self.context['price']:,.2f}\n")
            f.write(f"**24h Change:** {self.context['price_change_24h']:+.2f}%\n")
            f.write(f"**BTC Dominance:** {self.context['btc_dominance']:.1f}%\n")
            f.write(f"**Fear & Greed:** {self.context['fear_greed_index']:.0f}/100\n\n")
            f.write("---\n\n")
            f.write(self.article)
        files['article'] = article_file
        logger.info(f"Article saved to {article_file}")
        
        # Save LinkedIn posts
        linkedin_file = os.path.join(output_dir, f"linkedin_posts_{timestamp}.json")
        with open(linkedin_file, 'w') as f:
            json.dump({
                "generated_at": self.generated_at.isoformat(),
                "posts": self.linkedin_posts
            }, f, indent=2)
        files['linkedin'] = linkedin_file
        logger.info(f"LinkedIn posts saved to {linkedin_file}")
        
        # Save Twitter posts
        twitter_file = os.path.join(output_dir, f"twitter_posts_{timestamp}.json")
        with open(twitter_file, 'w') as f:
            json.dump({
                "generated_at": self.generated_at.isoformat(),
                "posts": self.twitter_posts
            }, f, indent=2)
        files['twitter'] = twitter_file
        logger.info(f"Twitter posts saved to {twitter_file}")
        
        # Save context
        context_file = os.path.join(output_dir, f"context_{timestamp}.json")
        with open(context_file, 'w') as f:
            json.dump(self.context, f, indent=2)
        files['context'] = context_file
        logger.info(f"Context saved to {context_file}")
        
        return files


def generate_daily_content() -> ContentPackage:
    """Main function to generate all daily content"""
    
    logger.info("=" * 60)
    logger.info("Starting daily Bitcoin content generation")
    logger.info("=" * 60)
    
    # Collect data
    collector = BitcoinDataCollector()
    context = collector.compile_context()
    
    # Generate content
    generator = AIContentGenerator()
    
    article = generator.generate_blog_article(context)
    linkedin_posts = [
        generator.generate_linkedin_post(context, "insight"),
        generator.generate_linkedin_post(context, "analysis")
    ]
    twitter_posts = generator.generate_twitter_posts(context, 3)
    
    # Package content
    package = ContentPackage(context, article, linkedin_posts, twitter_posts)
    files = package.save_to_file()
    
    logger.info("=" * 60)
    logger.info("Daily content generation completed successfully")
    logger.info("=" * 60)
    
    return package


if __name__ == "__main__":
    generate_daily_content()
