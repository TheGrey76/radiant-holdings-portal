#!/usr/bin/env python3
"""
ARIES76 Final Scheduler V4 - 4 Daily Publications
- 6:00 AM CET: Bitcoin Analysis
- 9:00 AM CET: Ethereum Analysis (NEW!)
- 6:00 PM CET: Digital Assets News
- 6:30 PM CET: Bitcoin Analysis Evening
"""

import logging
import os
import time
from datetime import datetime
import pytz
import requests

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/ubuntu/telegram_automation/logs/final_scheduler_v4.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Configuration
BOT_TOKEN = "8269982447:AAGR7PM7Dkpbslb7eT-rAimj5puKxcEfaV8"
CHANNEL_ID = "@aries76_bitcoin"
CET = pytz.timezone('Europe/Rome')

# Publication times (CET)
SCHEDULE = {
    "06:00": {"name": "Bitcoin Analysis", "type": "bitcoin"},
    "09:00": {"name": "Ethereum Analysis", "type": "ethereum"},
    "18:00": {"name": "Digital Assets News", "type": "news"},
    "18:30": {"name": "Bitcoin Analysis Evening", "type": "bitcoin_evening"}
}

def get_bitcoin_data():
    """Fetch Bitcoin data from CoinGecko"""
    try:
        response = requests.get(
            "https://api.coingecko.com/api/v3/simple/price",
            params={
                "ids": "bitcoin",
                "vs_currencies": "usd",
                "include_market_cap": "true",
                "include_24hr_vol": "true",
                "include_24hr_change": "true"
            },
            timeout=10
        )
        return response.json()["bitcoin"]
    except Exception as e:
        logger.error(f"Error fetching Bitcoin data: {e}")
        return None

def get_ethereum_data():
    """Fetch Ethereum data from CoinGecko"""
    try:
        response = requests.get(
            "https://api.coingecko.com/api/v3/simple/price",
            params={
                "ids": "ethereum",
                "vs_currencies": "usd",
                "include_market_cap": "true",
                "include_24hr_vol": "true",
                "include_24hr_change": "true"
            },
            timeout=10
        )
        return response.json()["ethereum"]
    except Exception as e:
        logger.error(f"Error fetching Ethereum data: {e}")
        return None

def get_digital_assets_news():
    """Fetch digital assets news from NewsAPI"""
    try:
        response = requests.get(
            "https://newsapi.org/v2/everything",
            params={
                "q": "cryptocurrency",
                "apiKey": "719499ece05e416b962d74fe012371e0",
                "sortBy": "publishedAt",
                "language": "en",
                "pageSize": 3
            },
            timeout=10
        )
        articles = response.json().get("articles", [])
        return articles[:3]
    except Exception as e:
        logger.error(f"Error fetching news: {e}")
        return []

def format_bitcoin_message(data):
    """Format Bitcoin analysis message"""
    if not data:
        return None
    
    price = data["usd"]
    change_24h = data["usd_24h_change"]
    market_cap = data["usd_market_cap"]
    volume_24h = data["usd_24h_vol"]
    
    resistance = price * 1.02
    support = price * 0.98
    
    if change_24h > 1:
        signal = "🟢 BUY"
    elif change_24h < -1:
        signal = "🔴 SELL"
    else:
        signal = "🟡 HOLD"
    
    message = f"""📊 **BITCOIN TECHNICAL ANALYSIS**

💰 **Price**: ${price:,.2f}
📈 **24h Change**: {change_24h:+.2f}%
💹 **Market Cap**: ${market_cap:,.0f}
📊 **24h Volume**: ${volume_24h:,.0f}

📍 **Technical Levels:**
🔺 Resistance: ${resistance:,.2f}
🔻 Support: ${support:,.2f}

🎯 **Signal**: {signal}

📖 **Full Analysis**: https://www.aries76.com/bitcoin-2026-report-preview

#Bitcoin #BTC #Crypto #Trading"""
    
    return message

def format_ethereum_message(data):
    """Format Ethereum analysis message"""
    if not data:
        return None
    
    price = data["usd"]
    change_24h = data["usd_24h_change"]
    market_cap = data["usd_market_cap"]
    volume_24h = data["usd_24h_vol"]
    
    resistance = price * 1.02
    support = price * 0.98
    
    if change_24h > 1:
        signal = "🟢 BUY"
    elif change_24h < -1:
        signal = "🔴 SELL"
    else:
        signal = "🟡 HOLD"
    
    message = f"""📊 **ETHEREUM TECHNICAL ANALYSIS**

💰 **Price**: ${price:,.2f}
📈 **24h Change**: {change_24h:+.2f}%
💹 **Market Cap**: ${market_cap:,.0f}
📊 **24h Volume**: ${volume_24h:,.0f}

📍 **Technical Levels:**
🔺 Resistance: ${resistance:,.2f}
🔻 Support: ${support:,.2f}

🎯 **Signal**: {signal}

📖 **Full Analysis**: https://www.aries76.com/bitcoin-2026-report-preview

#Ethereum #ETH #Crypto #Trading"""
    
    return message

def format_news_message(articles):
    """Format digital assets news message"""
    if not articles:
        return None
    
    message = "🌍 **DIGITAL ASSETS NEWS UPDATE**\n\n"
    
    for i, article in enumerate(articles, 1):
        title = article.get("title", "")[:60]
        source = article.get("source", {}).get("name", "News")
        message += f"{i}. {title}...\n   📰 {source}\n\n"
    
    message += f"""📖 **Full Analysis**: https://www.aries76.com/bitcoin-2026-report-preview

#Crypto #Blockchain #DigitalAssets #News"""
    
    return message

def publish_to_telegram(message):
    """Publish message to Telegram"""
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
        data = {
            "chat_id": CHANNEL_ID,
            "text": message,
            "parse_mode": "Markdown"
        }
        
        response = requests.post(url, json=data, timeout=10)
        
        if response.status_code == 200:
            logger.info("✅ Message published to Telegram")
            return True
        else:
            logger.error(f"Failed to publish: {response.text}")
            return False
    except Exception as e:
        logger.error(f"Error publishing to Telegram: {e}")
        return False

def run_scheduler():
    """Main scheduler loop"""
    logger.info("=" * 70)
    logger.info("ARIES76 FINAL SCHEDULER V4 - STARTED")
    logger.info("=" * 70)
    logger.info(f"Timezone: Europe/Rome (CET/CEST)")
    logger.info(f"Schedule:")
    for time_str, info in SCHEDULE.items():
        logger.info(f"  - {time_str}: {info['name']}")
    logger.info("=" * 70)
    logger.info("")
    
    last_published = {}
    
    while True:
        try:
            now = datetime.now(CET)
            current_time = now.strftime("%H:%M")
            
            for scheduled_time, info in SCHEDULE.items():
                if current_time == scheduled_time and scheduled_time not in last_published:
                    logger.info(f"Publishing: {info['name']} at {current_time}")
                    
                    message = None
                    
                    if info["type"] == "bitcoin":
                        data = get_bitcoin_data()
                        message = format_bitcoin_message(data)
                    elif info["type"] == "ethereum":
                        data = get_ethereum_data()
                        message = format_ethereum_message(data)
                    elif info["type"] == "news":
                        articles = get_digital_assets_news()
                        message = format_news_message(articles)
                    elif info["type"] == "bitcoin_evening":
                        data = get_bitcoin_data()
                        message = format_bitcoin_message(data)
                    
                    if message:
                        if publish_to_telegram(message):
                            last_published[scheduled_time] = True
                            logger.info(f"✅ {info['name']} published successfully")
                        else:
                            logger.error(f"❌ Failed to publish {info['name']}")
            
            # Reset published times at midnight
            if current_time == "00:00":
                last_published = {}
                logger.info("Daily reset completed")
            
            time.sleep(30)  # Check every 30 seconds
            
        except Exception as e:
            logger.error(f"Error in scheduler loop: {e}")
            time.sleep(60)

if __name__ == "__main__":
    try:
        run_scheduler()
    except KeyboardInterrupt:
        logger.info("Scheduler stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
