#!/usr/bin/env python3
"""
ARIES76 Conversion Tracker
Tracks clicks on report links and conversion metrics
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'conversion_tracker.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ConversionTracker:
    """Track conversions from Telegram to report purchases"""
    
    def __init__(self):
        """Initialize conversion tracker"""
        self.data_dir = Path('/home/ubuntu/telegram_automation/data')
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.conversions_file = self.data_dir / 'conversions.json'
        self.funnel_file = self.data_dir / 'funnel.json'
        
        # Load existing data
        self.conversions = self._load_conversions()
        self.funnel = self._load_funnel()
        
        logger.info("Conversion Tracker initialized")
    
    def _load_conversions(self):
        """Load conversions from file"""
        try:
            if self.conversions_file.exists():
                with open(self.conversions_file, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            logger.error(f"Error loading conversions: {e}")
            return []
    
    def _load_funnel(self):
        """Load funnel data from file"""
        try:
            if self.funnel_file.exists():
                with open(self.funnel_file, 'r') as f:
                    return json.load(f)
            return {
                'views': 0,
                'clicks': 0,
                'purchases': 0,
                'revenue': 0
            }
        except Exception as e:
            logger.error(f"Error loading funnel: {e}")
            return {
                'views': 0,
                'clicks': 0,
                'purchases': 0,
                'revenue': 0
            }
    
    def _save_conversions(self):
        """Save conversions to file"""
        try:
            with open(self.conversions_file, 'w') as f:
                json.dump(self.conversions, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving conversions: {e}")
    
    def _save_funnel(self):
        """Save funnel data to file"""
        try:
            with open(self.funnel_file, 'w') as f:
                json.dump(self.funnel, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving funnel: {e}")
    
    def track_message_view(self, user_id, message_id):
        """Track message view (top of funnel)"""
        try:
            conversion = {
                'user_id': user_id,
                'message_id': message_id,
                'event': 'view',
                'timestamp': datetime.now().isoformat(),
                'status': 'viewed'
            }
            
            self.conversions.append(conversion)
            self.funnel['views'] += 1
            
            self._save_conversions()
            self._save_funnel()
            
            logger.info(f"Message view tracked: user {user_id}")
            return True
        except Exception as e:
            logger.error(f"Error tracking message view: {e}")
            return False
    
    def track_report_click(self, user_id, message_id, utm_source='telegram'):
        """Track click on report link"""
        try:
            conversion = {
                'user_id': user_id,
                'message_id': message_id,
                'event': 'click',
                'timestamp': datetime.now().isoformat(),
                'utm_source': utm_source,
                'status': 'clicked'
            }
            
            self.conversions.append(conversion)
            self.funnel['clicks'] += 1
            
            self._save_conversions()
            self._save_funnel()
            
            logger.info(f"Report click tracked: user {user_id} from {utm_source}")
            return True
        except Exception as e:
            logger.error(f"Error tracking report click: {e}")
            return False
    
    def track_purchase(self, user_id, report_type, price, currency='USD'):
        """Track purchase conversion"""
        try:
            conversion = {
                'user_id': user_id,
                'event': 'purchase',
                'timestamp': datetime.now().isoformat(),
                'report_type': report_type,
                'price': price,
                'currency': currency,
                'status': 'purchased'
            }
            
            self.conversions.append(conversion)
            self.funnel['purchases'] += 1
            self.funnel['revenue'] += price
            
            self._save_conversions()
            self._save_funnel()
            
            logger.info(f"Purchase tracked: user {user_id}, {price} {currency}")
            return True
        except Exception as e:
            logger.error(f"Error tracking purchase: {e}")
            return False
    
    def get_conversion_funnel(self):
        """Get conversion funnel metrics"""
        try:
            funnel = {
                'views': self.funnel.get('views', 0),
                'clicks': self.funnel.get('clicks', 0),
                'purchases': self.funnel.get('purchases', 0),
                'revenue': self.funnel.get('revenue', 0)
            }
            
            # Calculate rates
            if funnel['views'] > 0:
                funnel['click_rate'] = (funnel['clicks'] / funnel['views']) * 100
                funnel['conversion_rate'] = (funnel['purchases'] / funnel['views']) * 100
            
            if funnel['clicks'] > 0:
                funnel['purchase_rate'] = (funnel['purchases'] / funnel['clicks']) * 100
            
            # Calculate average order value
            if funnel['purchases'] > 0:
                funnel['aov'] = funnel['revenue'] / funnel['purchases']
            
            return funnel
        except Exception as e:
            logger.error(f"Error getting conversion funnel: {e}")
            return {}
    
    def get_daily_conversions(self, days=7):
        """Get daily conversion statistics"""
        try:
            stats = defaultdict(lambda: {
                'views': 0,
                'clicks': 0,
                'purchases': 0,
                'revenue': 0
            })
            
            cutoff_date = datetime.now() - timedelta(days=days)
            
            for conversion in self.conversions:
                conv_date = datetime.fromisoformat(conversion['timestamp'])
                
                if conv_date < cutoff_date:
                    continue
                
                date_key = conv_date.strftime('%Y-%m-%d')
                event = conversion['event']
                
                if event == 'view':
                    stats[date_key]['views'] += 1
                elif event == 'click':
                    stats[date_key]['clicks'] += 1
                elif event == 'purchase':
                    stats[date_key]['purchases'] += 1
                    stats[date_key]['revenue'] += conversion.get('price', 0)
            
            # Calculate rates
            result = {}
            for date, data in stats.items():
                result[date] = {
                    'views': data['views'],
                    'clicks': data['clicks'],
                    'purchases': data['purchases'],
                    'revenue': data['revenue']
                }
                
                if data['views'] > 0:
                    result[date]['click_rate'] = (data['clicks'] / data['views']) * 100
                    result[date]['conversion_rate'] = (data['purchases'] / data['views']) * 100
            
            return result
        except Exception as e:
            logger.error(f"Error getting daily conversions: {e}")
            return {}
    
    def get_user_conversion_path(self, user_id):
        """Get conversion path for a specific user"""
        try:
            user_conversions = [c for c in self.conversions if c['user_id'] == user_id]
            
            path = {
                'user_id': user_id,
                'events': [],
                'status': 'visitor',
                'total_events': len(user_conversions)
            }
            
            for conv in user_conversions:
                path['events'].append({
                    'event': conv['event'],
                    'timestamp': conv['timestamp'],
                    'details': {k: v for k, v in conv.items() if k not in ['user_id', 'event', 'timestamp']}
                })
                
                # Update status based on latest event
                if conv['event'] == 'purchase':
                    path['status'] = 'customer'
                elif conv['event'] == 'click' and path['status'] != 'customer':
                    path['status'] = 'interested'
            
            return path
        except Exception as e:
            logger.error(f"Error getting user conversion path: {e}")
            return {}
    
    def get_top_converting_messages(self, limit=10):
        """Get top converting messages"""
        try:
            message_stats = defaultdict(lambda: {
                'views': 0,
                'clicks': 0,
                'purchases': 0
            })
            
            for conversion in self.conversions:
                msg_id = conversion.get('message_id', 'unknown')
                event = conversion['event']
                
                if event == 'view':
                    message_stats[msg_id]['views'] += 1
                elif event == 'click':
                    message_stats[msg_id]['clicks'] += 1
                elif event == 'purchase':
                    message_stats[msg_id]['purchases'] += 1
            
            # Calculate conversion rates
            for msg_id, stats in message_stats.items():
                if stats['views'] > 0:
                    stats['click_rate'] = (stats['clicks'] / stats['views']) * 100
                    stats['conversion_rate'] = (stats['purchases'] / stats['views']) * 100
            
            # Sort by conversion rate
            top_messages = sorted(
                message_stats.items(),
                key=lambda x: x[1].get('conversion_rate', 0),
                reverse=True
            )[:limit]
            
            return dict(top_messages)
        except Exception as e:
            logger.error(f"Error getting top converting messages: {e}")
            return {}
    
    def generate_conversion_report(self):
        """Generate comprehensive conversion report"""
        try:
            report = {
                'timestamp': datetime.now().isoformat(),
                'funnel': self.get_conversion_funnel(),
                'daily_stats': self.get_daily_conversions(7),
                'top_messages': self.get_top_converting_messages(5),
                'total_conversions': len(self.conversions)
            }
            
            logger.info(f"Conversion report generated")
            return report
        except Exception as e:
            logger.error(f"Error generating conversion report: {e}")
            return {}

def main():
    """Main function for testing"""
    tracker = ConversionTracker()
    
    # Track some test conversions
    tracker.track_message_view(123456, 'msg_001')
    tracker.track_message_view(123456, 'msg_001')
    tracker.track_report_click(123456, 'msg_001')
    tracker.track_purchase(123456, 'bitcoin_report', 29.99)
    
    tracker.track_message_view(234567, 'msg_001')
    tracker.track_report_click(234567, 'msg_001')
    
    # Get funnel
    funnel = tracker.get_conversion_funnel()
    print(f"\nConversion Funnel:")
    print(f"  Views: {funnel['views']}")
    print(f"  Clicks: {funnel['clicks']}")
    print(f"  Purchases: {funnel['purchases']}")
    print(f"  Revenue: ${funnel['revenue']:.2f}")
    if 'click_rate' in funnel:
        print(f"  Click Rate: {funnel['click_rate']:.1f}%")
    if 'conversion_rate' in funnel:
        print(f"  Conversion Rate: {funnel['conversion_rate']:.1f}%")
    
    # Get report
    report = tracker.generate_conversion_report()
    print(f"\nTotal Conversions Tracked: {report['total_conversions']}")

if __name__ == '__main__':
    main()
