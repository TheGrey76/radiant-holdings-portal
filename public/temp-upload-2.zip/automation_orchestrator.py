#!/usr/bin/env python3
"""
Bitcoin Content Automation Orchestrator
Main script that coordinates content generation and publishing
"""

import os
import sys
import json
import logging
from datetime import datetime, time
from pathlib import Path
from typing import Dict, List, Tuple
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Add project to path
sys.path.insert(0, '/home/ubuntu/bitcoin_automation')

from bitcoin_content_generator import generate_daily_content
from social_media_publisher import publish_content

# Configure logging
log_dir = '/home/ubuntu/bitcoin_automation/logs'
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(log_dir, 'orchestrator.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class EmailNotifier:
    """Send email notifications about content generation"""
    
    def __init__(self, smtp_server: str = "smtp.gmail.com", smtp_port: int = 587):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.sender_email = os.getenv("SENDER_EMAIL")
        self.sender_password = os.getenv("SENDER_PASSWORD")
        
    def send_notification(self, recipient: str, subject: str, 
                         content_summary: Dict, files: Dict) -> bool:
        """Send email notification with content summary"""
        
        if not self.sender_email or not self.sender_password:
            logger.warning("Email credentials not configured")
            return False
        
        try:
            # Create message
            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = self.sender_email
            message["To"] = recipient
            
            # Create HTML content
            html = self._create_html_summary(content_summary, files)
            
            # Attach HTML
            message.attach(MIMEText(html, "html"))
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.sendmail(self.sender_email, recipient, message.as_string())
            
            logger.info(f"Email notification sent to {recipient}")
            return True
            
        except Exception as e:
            logger.error(f"Error sending email: {e}")
            return False
    
    def _create_html_summary(self, content_summary: Dict, files: Dict) -> str:
        """Create HTML email summary"""
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        html = f"""
        <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                    .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                    .header {{ background-color: #f7931a; color: white; padding: 20px; border-radius: 5px; }}
                    .section {{ margin: 20px 0; padding: 15px; background-color: #f9f9f9; border-left: 4px solid #f7931a; }}
                    .metric {{ display: inline-block; margin: 10px 20px 10px 0; }}
                    .metric-value {{ font-size: 24px; font-weight: bold; color: #f7931a; }}
                    .metric-label {{ font-size: 12px; color: #666; }}
                    .file-link {{ display: inline-block; margin: 5px 10px 5px 0; padding: 8px 12px; background-color: #f7931a; color: white; text-decoration: none; border-radius: 3px; }}
                    .footer {{ text-align: center; margin-top: 30px; font-size: 12px; color: #999; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>Bitcoin Content Generation Report</h1>
                        <p>Generated: {timestamp}</p>
                    </div>
                    
                    <div class="section">
                        <h2>Market Snapshot</h2>
                        <div class="metric">
                            <div class="metric-value">${content_summary.get('price', 0):,.2f}</div>
                            <div class="metric-label">BTC Price</div>
                        </div>
                        <div class="metric">
                            <div class="metric-value">{content_summary.get('price_change_24h', 0):+.2f}%</div>
                            <div class="metric-label">24h Change</div>
                        </div>
                        <div class="metric">
                            <div class="metric-value">{content_summary.get('btc_dominance', 0):.1f}%</div>
                            <div class="metric-label">BTC Dominance</div>
                        </div>
                        <div class="metric">
                            <div class="metric-value">{content_summary.get('fear_greed_index', 0):.0f}/100</div>
                            <div class="metric-label">Fear & Greed</div>
                        </div>
                    </div>
                    
                    <div class="section">
                        <h2>Content Generated</h2>
                        <ul>
                            <li>1 Blog Article (800-1200 words)</li>
                            <li>2 LinkedIn Posts</li>
                            <li>3 Twitter Posts</li>
                        </ul>
                    </div>
                    
                    <div class="section">
                        <h2>Generated Files</h2>
        """
        
        for file_type, file_path in files.items():
            if file_path and os.path.exists(file_path):
                filename = os.path.basename(file_path)
                html += f'<a href="file:///{file_path}" class="file-link">{filename}</a>\n'
        
        html += """
                    </div>
                    
                    <div class="footer">
                        <p>Bitcoin Report Content Automation System</p>
                        <p>This is an automated email. Please do not reply.</p>
                    </div>
                </div>
            </body>
        </html>
        """
        
        return html


class AutomationOrchestrator:
    """Main orchestrator for the automation system"""
    
    def __init__(self):
        self.notifier = EmailNotifier()
        self.notification_email = os.getenv("NOTIFICATION_EMAIL", "egrigione@gmail.com")
        
    def run_daily_automation(self) -> Dict:
        """Execute the complete daily automation workflow"""
        
        logger.info("=" * 70)
        logger.info("STARTING DAILY BITCOIN CONTENT AUTOMATION")
        logger.info("=" * 70)
        
        execution_log = {
            "timestamp": datetime.now().isoformat(),
            "steps": {}
        }
        
        try:
            # Step 1: Generate content
            logger.info("STEP 1: Generating content...")
            package = generate_daily_content()
            files = package.save_to_file()
            execution_log["steps"]["content_generation"] = {
                "status": "success",
                "files": files
            }
            
            # Step 2: Publish content
            logger.info("STEP 2: Publishing content...")
            publishing_results = publish_content(files)
            execution_log["steps"]["publishing"] = {
                "status": "success",
                "results": publishing_results
            }
            
            # Step 3: Send notification
            logger.info("STEP 3: Sending notification...")
            self.notifier.send_notification(
                self.notification_email,
                f"Bitcoin Content Generated - {datetime.now().strftime('%Y-%m-%d')}",
                package.context,
                files
            )
            execution_log["steps"]["notification"] = {
                "status": "success"
            }
            
            execution_log["overall_status"] = "success"
            
        except Exception as e:
            logger.error(f"Error during automation: {e}", exc_info=True)
            execution_log["overall_status"] = "failed"
            execution_log["error"] = str(e)
        
        # Save execution log
        self._save_execution_log(execution_log)
        
        logger.info("=" * 70)
        logger.info(f"AUTOMATION COMPLETED - Status: {execution_log['overall_status']}")
        logger.info("=" * 70)
        
        return execution_log
    
    def _save_execution_log(self, log: Dict) -> None:
        """Save execution log to file"""
        
        log_file = '/home/ubuntu/bitcoin_automation/logs/execution_logs.jsonl'
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        with open(log_file, 'a') as f:
            f.write(json.dumps(log) + "\n")
        
        logger.info(f"Execution log saved to {log_file}")


def main():
    """Main entry point"""
    
    orchestrator = AutomationOrchestrator()
    result = orchestrator.run_daily_automation()
    
    # Exit with appropriate code
    sys.exit(0 if result["overall_status"] == "success" else 1)


if __name__ == "__main__":
    main()
