import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

serve(async (req) => {
  const { symbol, correlation_assets } = await req.json()

  const command = new Deno.Command('python3', {
    args: [
      'advanced_content_generator.py',
      '--symbol', symbol,
      '--correlation_assets', correlation_assets.join(',')
    ]
  })

  const { code, stdout, stderr } = await command.output()

  if (code !== 0) {
    return new Response(JSON.stringify({ error: new TextDecoder().decode(stderr) }), { status: 500 })
  }

  return new Response(
    JSON.stringify({ message: new TextDecoder().decode(stdout) }),
    { headers: { 'Content-Type': 'application/json' } },
  )
})
