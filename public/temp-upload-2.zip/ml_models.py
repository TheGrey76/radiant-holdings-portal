'''Machine learning models for price prediction and regime detection.'''

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.mixture import GaussianMixture
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import xgboost as xgb

class PricePredictor:
    "Predicts future asset prices using LSTM and XGBoost."

    def __init__(self, data):
        self.data = data
        self.scaler = MinMaxScaler(feature_range=(0, 1))
        self.scaled_data = self.scaler.fit_transform(data["Close"].values.reshape(-1, 1))

    def create_lstm_model(self, look_back=60):
        model = Sequential()
        model.add(LSTM(units=50, return_sequences=True, input_shape=(look_back, 1)))
        model.add(Dropout(0.2))
        model.add(LSTM(units=50, return_sequences=False))
        model.add(Dropout(0.2))
        model.add(Dense(units=25))
        model.add(Dense(units=1))
        model.compile(optimizer='adam', loss='mean_squared_error')
        return model

    def train_lstm(self, look_back=60, epochs=1, batch_size=1):
        x_train, y_train = [], []
        for i in range(look_back, len(self.scaled_data)):
            x_train.append(self.scaled_data[i-look_back:i, 0])
            y_train.append(self.scaled_data[i, 0])
        x_train, y_train = np.array(x_train), np.array(y_train)
        x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))

        model = self.create_lstm_model(look_back)
        model.fit(x_train, y_train, epochs=epochs, batch_size=batch_size, verbose=0)
        return model

    def predict_lstm(self, model, look_back=60):
        last_60_days = self.scaled_data[-look_back:]
        x_test = np.array([last_60_days])
        x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1))
        predicted_price = model.predict(x_test)
        predicted_price = self.scaler.inverse_transform(predicted_price)
        return predicted_price[0][0]

    def train_xgboost(self, features, target):
        model = xgb.XGBRegressor(objective='reg:squarederror', n_estimators=1000)
        model.fit(features, target, verbose=False)
        return model

class RegimeDetector:
    "Detects market regimes using Gaussian Mixture Models."

    def __init__(self, returns, n_regimes=3):
        self.returns = returns.values.reshape(-1, 1)
        self.n_regimes = n_regimes
        self.model = GaussianMixture(n_components=n_regimes, covariance_type="full", random_state=42)

    def fit(self):
        self.model.fit(self.returns)

    def predict(self):
        return self.model.predict(self.returns)

if __name__ == '__main__':
    # Example usage
    data = {
        'Close': [50000 + i*100 - 50*i*i + 10*i*i*i for i in range(300)]
    }
    prices_df = pd.DataFrame(data, index=pd.to_datetime(pd.date_range('2023-01-01', periods=300)))

    # Price Prediction
    predictor = PricePredictor(prices_df)
    lstm_model = predictor.train_lstm()
    predicted_price = predictor.predict_lstm(lstm_model)
    print(f"Predicted Next Day Price (LSTM): {predicted_price:.2f}")

    # Regime Detection
    returns = prices_df['Close'].pct_change().dropna()
    detector = RegimeDetector(returns)
    detector.fit()
    regimes = detector.predict()
    print(f"Current Market Regime: {regimes[-1]}")
