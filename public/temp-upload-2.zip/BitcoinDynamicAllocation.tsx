'use client'

import React, { useState, useEffect } from 'react'
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart, Area, AreaChart } from 'recharts'

interface PortfolioMetrics {
  sharpeRatio: number
  sortinoRatio: number
  maxDrawdown: number
  volatility: number
  expectedReturn: number
  var95: number
  cvar95: number
}

interface SentimentData {
  fearGreedIndex: number
  mvrv_zscore: number
  activeAddresses: number
  exchangeFlows: number
  interpretation: string
}

interface AllocationData {
  name: string
  value: number
}

export default function BitcoinDynamicAllocation() {
  const [metrics, setMetrics] = useState<PortfolioMetrics | null>(null)
  const [sentiment, setSentiment] = useState<SentimentData | null>(null)
  const [allocation, setAllocation] = useState<AllocationData[]>([
    { name: 'Bitcoin', value: 40 },
    { name: 'Ethereum', value: 30 },
    { name: 'Traditional Assets', value: 20 },
    { name: 'Stablecoins', value: 10 },
  ])
  const [loading, setLoading] = useState(true)

  const colors = ['#FF6B35', '#004E89', '#F7931A', '#1652F0']

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch portfolio metrics
        const metricsResponse = await fetch('/api/portfolio-analysis', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            assets: ['BTC', 'ETH', 'SPY', 'GLD'],
            weights: [0.4, 0.3, 0.2, 0.1],
            timeframe: '1m',
          }),
        })
        const metricsData = await metricsResponse.json()
        setMetrics(metricsData)

        // Fetch sentiment data
        const sentimentResponse = await fetch('/api/sentiment-data')
        const sentimentData = await sentimentResponse.json()
        setSentiment(sentimentData)
      } catch (error) {
        console.error('Error fetching data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
    const interval = setInterval(fetchData, 3600000) // Update every hour
    return () => clearInterval(interval)
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-white text-lg">Loading Portfolio Analysis...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Bitcoin Dynamic Allocation</h1>
          <p className="text-slate-300">Institutional-Grade Portfolio Management</p>
        </div>

        {/* Key Metrics Grid */}
        {metrics && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg p-6 text-white">
              <p className="text-sm font-semibold text-blue-100 mb-2">Sharpe Ratio</p>
              <p className="text-3xl font-bold">{metrics.sharpeRatio.toFixed(2)}</p>
              <p className="text-xs text-blue-200 mt-2">Risk-adjusted returns</p>
            </div>

            <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-lg p-6 text-white">
              <p className="text-sm font-semibold text-green-100 mb-2">Sortino Ratio</p>
              <p className="text-3xl font-bold">{metrics.sortinoRatio.toFixed(2)}</p>
              <p className="text-xs text-green-200 mt-2">Downside risk-adjusted</p>
            </div>

            <div className="bg-gradient-to-br from-red-600 to-red-700 rounded-lg p-6 text-white">
              <p className="text-sm font-semibold text-red-100 mb-2">Max Drawdown</p>
              <p className="text-3xl font-bold">{(metrics.maxDrawdown * 100).toFixed(2)}%</p>
              <p className="text-xs text-red-200 mt-2">Largest peak-to-trough</p>
            </div>

            <div className="bg-gradient-to-br from-orange-600 to-orange-700 rounded-lg p-6 text-white">
              <p className="text-sm font-semibold text-orange-100 mb-2">Volatility</p>
              <p className="text-3xl font-bold">{(metrics.volatility * 100).toFixed(2)}%</p>
              <p className="text-xs text-orange-200 mt-2">Annual volatility</p>
            </div>
          </div>
        )}

        {/* Sentiment & Risk Metrics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Fear & Greed Index */}
          {sentiment && (
            <div className="bg-slate-700 rounded-lg p-6 border border-slate-600">
              <h3 className="text-xl font-bold text-white mb-4">Market Sentiment</h3>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-slate-300 text-sm mb-1">Fear & Greed Index</p>
                  <p className="text-4xl font-bold text-orange-500">{sentiment.fearGreedIndex}</p>
                </div>
                <div className="text-right">
                  <p className={`text-lg font-semibold ${
                    sentiment.fearGreedIndex < 25 ? 'text-red-500' :
                    sentiment.fearGreedIndex < 45 ? 'text-orange-500' :
                    sentiment.fearGreedIndex < 55 ? 'text-yellow-500' :
                    sentiment.fearGreedIndex < 75 ? 'text-green-500' :
                    'text-red-500'
                  }`}>
                    {sentiment.interpretation}
                  </p>
                </div>
              </div>
              <div className="w-full bg-slate-600 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-red-500 via-yellow-500 to-red-500 h-2 rounded-full"
                  style={{ width: `${sentiment.fearGreedIndex}%` }}
                ></div>
              </div>
            </div>
          )}

          {/* Risk Metrics */}
          {metrics && (
            <div className="bg-slate-700 rounded-lg p-6 border border-slate-600">
              <h3 className="text-xl font-bold text-white mb-4">Risk Metrics</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-slate-300">Value at Risk (95%)</span>
                  <span className="text-red-400 font-semibold">{(metrics.var95 * 100).toFixed(2)}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-300">Conditional VaR (95%)</span>
                  <span className="text-red-500 font-semibold">{(metrics.cvar95 * 100).toFixed(2)}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-300">Expected Return</span>
                  <span className="text-green-400 font-semibold">{(metrics.expectedReturn * 100).toFixed(2)}%</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Allocation Pie Chart */}
        <div className="bg-slate-700 rounded-lg p-6 border border-slate-600 mb-8">
          <h3 className="text-xl font-bold text-white mb-4">Current Allocation</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={allocation}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {allocation.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => `${value}%`} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Additional Metrics */}
        {metrics && (
          <div className="bg-slate-700 rounded-lg p-6 border border-slate-600">
            <h3 className="text-xl font-bold text-white mb-4">Performance Summary</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <p className="text-slate-400 text-sm mb-1">Sharpe Ratio</p>
                <p className="text-2xl font-bold text-blue-400">{metrics.sharpeRatio.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm mb-1">Sortino Ratio</p>
                <p className="text-2xl font-bold text-green-400">{metrics.sortinoRatio.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm mb-1">Max Drawdown</p>
                <p className="text-2xl font-bold text-red-400">{(metrics.maxDrawdown * 100).toFixed(2)}%</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm mb-1">Volatility</p>
                <p className="text-2xl font-bold text-orange-400">{(metrics.volatility * 100).toFixed(2)}%</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm mb-1">Expected Return</p>
                <p className="text-2xl font-bold text-emerald-400">{(metrics.expectedReturn * 100).toFixed(2)}%</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm mb-1">VaR (95%)</p>
                <p className="text-2xl font-bold text-pink-400">{(metrics.var95 * 100).toFixed(2)}%</p>
              </div>
            </div>
          </div>
        )}

        {/* Footer Note */}
        <div className="mt-8 text-center text-slate-400 text-sm">
          <p>Data updated daily at 6:00 AM CET | Last update: {new Date().toLocaleString()}</p>
        </div>
      </div>
    </div>
  )
}
