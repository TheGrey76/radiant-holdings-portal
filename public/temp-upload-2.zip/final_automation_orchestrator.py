"""
Final Bitcoin Content Automation Orchestrator
Generates content daily and publishes to LinkedIn automatically
"""

import os
import json
import logging
import schedule
import time
from datetime import datetime
from typing import List, Dict
from dotenv import load_dotenv

# Import our modules
from bitcoin_content_generator import BitcoinDataCollector, AIContentGenerator
from social_media_publisher import LinkedInPublisher

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/ubuntu/bitcoin_automation/logs/final_orchestrator.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

load_dotenv('/home/ubuntu/bitcoin_automation/.env')


class FinalAutomationOrchestrator:
    """Main orchestrator for Bitcoin content automation"""
    
    def __init__(self):
        self.data_collector = BitcoinDataCollector()
        self.ai_generator = AIContentGenerator()
        self.linkedin_publisher = LinkedInPublisher()
        self.generated_files = {}
        
    def generate_daily_content(self) -> bool:
        """Generate all daily content"""
        try:
            logger.info("=" * 70)
            logger.info("STARTING DAILY CONTENT GENERATION")
            logger.info("=" * 70)
            
            # Generate content
            logger.info("Generating Bitcoin content...")
            
            # Collect data
            bitcoin_data = self.data_collector.collect_data()
            
            # Generate content
            content = self.ai_generator.generate_content(bitcoin_data)
            
            if not content:
                logger.error("Failed to generate content")
                return False
            
            logger.info("✓ Content generated successfully")
            
            # Save files
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            content_dir = '/home/ubuntu/bitcoin_automation/generated_content'
            os.makedirs(content_dir, exist_ok=True)
            
            # Save article
            article_file = os.path.join(content_dir, f'article_{timestamp}.md')
            with open(article_file, 'w') as f:
                f.write(content.get('article', ''))
            logger.info(f"✓ Article saved: {article_file}")
            
            # Save LinkedIn posts
            linkedin_file = os.path.join(content_dir, f'linkedin_posts_{timestamp}.json')
            with open(linkedin_file, 'w') as f:
                json.dump({'posts': content.get('linkedin_posts', [])}, f, indent=2)
            logger.info(f"✓ LinkedIn posts saved: {linkedin_file}")
            
            # Save Twitter posts
            twitter_file = os.path.join(content_dir, f'twitter_posts_{timestamp}.json')
            with open(twitter_file, 'w') as f:
                json.dump({'posts': content.get('twitter_posts', [])}, f, indent=2)
            logger.info(f"✓ Twitter posts saved: {twitter_file}")
            
            self.generated_files = {
                'article': article_file,
                'linkedin': linkedin_file,
                'twitter': twitter_file,
                'timestamp': timestamp
            }
            
            return True
            
        except Exception as e:
            logger.error(f"Error generating content: {e}")
            return False
    
    def publish_to_linkedin(self) -> bool:
        """Publish generated posts to LinkedIn"""
        try:
            if not self.generated_files.get('linkedin'):
                logger.warning("No LinkedIn posts file found")
                return False
            
            logger.info("Publishing to LinkedIn...")
            
            # Load posts
            with open(self.generated_files['linkedin'], 'r') as f:
                data = json.load(f)
            
            posts = data.get('posts', [])
            
            if not posts:
                logger.warning("No posts to publish")
                return False
            
            # Publish each post
            results = []
            for i, post in enumerate(posts):
                post_text = post.get('text', '')
                logger.info(f"Publishing post {i+1}/{len(posts)}: {post_text[:50]}...")
                
                result = self.linkedin_publisher.publish_post(post_text)
                results.append(result)
                
                # Wait between posts
                if i < len(posts) - 1:
                    time.sleep(5)
            
            success_count = sum(results)
            logger.info(f"✓ Published {success_count}/{len(posts)} posts to LinkedIn")
            
            return success_count > 0
            
        except Exception as e:
            logger.error(f"Error publishing to LinkedIn: {e}")
            return False
    
    def run_daily_automation(self):
        """Run the complete daily automation"""
        try:
            logger.info("\n" + "=" * 70)
            logger.info("DAILY AUTOMATION STARTED")
            logger.info(f"Timestamp: {datetime.now()}")
            logger.info("=" * 70)
            
            # Step 1: Generate content
            if not self.generate_daily_content():
                logger.error("Content generation failed")
                return False
            
            # Step 2: Publish to LinkedIn
            if not self.publish_to_linkedin():
                logger.warning("LinkedIn publishing had issues, but content was generated")
            
            logger.info("=" * 70)
            logger.info("DAILY AUTOMATION COMPLETED")
            logger.info("=" * 70 + "\n")
            
            return True
            
        except Exception as e:
            logger.error(f"Error in daily automation: {e}")
            return False
    
    def schedule_automation(self, hour: int = 6, minute: int = 0):
        """Schedule the automation to run daily at specified time"""
        
        time_str = f"{hour:02d}:{minute:02d}"
        
        logger.info(f"Scheduling automation for {time_str} CET daily...")
        
        schedule.every().day.at(time_str).do(self.run_daily_automation)
        
        logger.info(f"✓ Automation scheduled for {time_str} CET")
        
        # Keep scheduler running
        while True:
            schedule.run_pending()
            time.sleep(60)


def main():
    """Main entry point"""
    
    logger.info("Bitcoin Content Automation System Starting...")
    
    orchestrator = FinalAutomationOrchestrator()
    
    # Run once immediately for testing
    logger.info("Running initial automation test...")
    orchestrator.run_daily_automation()
    
    # Schedule for daily execution at 6:00 AM CET
    logger.info("\nScheduling daily automation...")
    orchestrator.schedule_automation(hour=6, minute=0)


if __name__ == '__main__':
    main()
