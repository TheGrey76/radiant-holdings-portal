#!/usr/bin/env python3
"""
ARIES76 Telegram Automation - Test Suite
Comprehensive testing for all system components
"""

import sys
import asyncio
import logging
from datetime import datetime
from pathlib import Path

# Add paths
sys.path.insert(0, '/home/ubuntu/bitcoin_automation')
sys.path.insert(0, '/home/ubuntu/telegram_automation')

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'test_suite.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class TestSuite:
    """Comprehensive test suite for ARIES76 Telegram automation"""
    
    def __init__(self):
        """Initialize test suite"""
        self.results = []
        logger.info("Test Suite initialized")
    
    def test_bot_connection(self):
        """Test 1: Bot connection"""
        try:
            logger.info("\n" + "="*60)
            logger.info("TEST 1: Bot Connection")
            logger.info("="*60)
            
            import asyncio
            from telegram_bot import ARIES76TelegramBot
            
            async def test():
                bot = ARIES76TelegramBot()
                result = await bot.test_connection()
                return result
            
            result = asyncio.run(test())
            
            if result:
                logger.info("✓ PASS: Bot connection successful")
                self.results.append(('Bot Connection', 'PASS'))
                return True
            else:
                logger.error("✗ FAIL: Bot connection failed")
                self.results.append(('Bot Connection', 'FAIL'))
                return False
        except Exception as e:
            logger.error(f"✗ ERROR: {e}")
            self.results.append(('Bot Connection', 'ERROR'))
            return False
    
    def test_content_loading(self):
        """Test 2: Content loading"""
        try:
            logger.info("\n" + "="*60)
            logger.info("TEST 2: Content Loading")
            logger.info("="*60)
            
            from telegram_bot import ARIES76TelegramBot
            
            bot = ARIES76TelegramBot()
            content = bot.load_latest_content()
            
            if content:
                logger.info("✓ PASS: Content loaded successfully")
                logger.info(f"  Article: {len(content.get('article', ''))} chars")
                logger.info(f"  Posts: {len(content.get('posts', []))} posts")
                self.results.append(('Content Loading', 'PASS'))
                return True
            else:
                logger.warning("⚠ WARNING: No content found (expected if first run)")
                self.results.append(('Content Loading', 'WARNING'))
                return True
        except Exception as e:
            logger.error(f"✗ ERROR: {e}")
            self.results.append(('Content Loading', 'ERROR'))
            return False
    
    def test_message_formatting(self):
        """Test 3: Message formatting"""
        try:
            logger.info("\n" + "="*60)
            logger.info("TEST 3: Message Formatting")
            logger.info("="*60)
            
            from telegram_bot import ARIES76TelegramBot
            
            bot = ARIES76TelegramBot()
            
            test_content = {
                'article': '# Test Article\n\nThis is a test article.',
                'posts': []
            }
            
            message = bot.format_channel_message(test_content)
            
            if message and len(message) > 0:
                logger.info("✓ PASS: Message formatted successfully")
                logger.info(f"  Message length: {len(message)} chars")
                self.results.append(('Message Formatting', 'PASS'))
                return True
            else:
                logger.error("✗ FAIL: Message formatting failed")
                self.results.append(('Message Formatting', 'FAIL'))
                return False
        except Exception as e:
            logger.error(f"✗ ERROR: {e}")
            self.results.append(('Message Formatting', 'ERROR'))
            return False
    
    def test_premium_tier_manager(self):
        """Test 4: Premium tier manager"""
        try:
            logger.info("\n" + "="*60)
            logger.info("TEST 4: Premium Tier Manager")
            logger.info("="*60)
            
            from premium_tier_manager import PremiumTierManager, SubscriptionTier
            
            manager = PremiumTierManager()
            
            # Test add user
            manager.add_user(999999, "test_user", "test@example.com", SubscriptionTier.FREE)
            
            # Test upgrade
            manager.upgrade_to_premium(999999, 30)
            
            # Test get tier
            tier = manager.get_user_tier(999999)
            
            if tier == SubscriptionTier.PREMIUM:
                logger.info("✓ PASS: Premium tier manager working")
                self.results.append(('Premium Tier Manager', 'PASS'))
                return True
            else:
                logger.error("✗ FAIL: Premium tier manager failed")
                self.results.append(('Premium Tier Manager', 'FAIL'))
                return False
        except Exception as e:
            logger.error(f"✗ ERROR: {e}")
            self.results.append(('Premium Tier Manager', 'ERROR'))
            return False
    
    def test_user_engagement(self):
        """Test 5: User engagement tracking"""
        try:
            logger.info("\n" + "="*60)
            logger.info("TEST 5: User Engagement Tracking")
            logger.info("="*60)
            
            from user_engagement import UserEngagement
            
            engagement = UserEngagement()
            
            # Track test events
            engagement.track_message_view(999999, 'test_msg')
            engagement.track_click(999999, 'https://test.com')
            
            # Get engagement
            user_engagement = engagement.get_user_engagement(999999)
            
            if user_engagement.get('total_events', 0) >= 2:
                logger.info("✓ PASS: User engagement tracking working")
                logger.info(f"  Total events: {user_engagement['total_events']}")
                self.results.append(('User Engagement', 'PASS'))
                return True
            else:
                logger.error("✗ FAIL: User engagement tracking failed")
                self.results.append(('User Engagement', 'FAIL'))
                return False
        except Exception as e:
            logger.error(f"✗ ERROR: {e}")
            self.results.append(('User Engagement', 'ERROR'))
            return False
    
    def test_system_monitor(self):
        """Test 6: System monitor"""
        try:
            logger.info("\n" + "="*60)
            logger.info("TEST 6: System Monitor")
            logger.info("="*60)
            
            from system_monitor import SystemMonitor
            
            monitor = SystemMonitor()
            report = monitor.generate_report()
            
            if report and 'timestamp' in report:
                logger.info("✓ PASS: System monitor working")
                logger.info(f"  Bitcoin Generator: {report['bitcoin_generator'].get('status', 'N/A')}")
                logger.info(f"  Telegram Scheduler: {report['telegram_scheduler'].get('status', 'N/A')}")
                logger.info(f"  Bot Connection: {report['bot_connection'].get('status', 'N/A')}")
                self.results.append(('System Monitor', 'PASS'))
                return True
            else:
                logger.error("✗ FAIL: System monitor failed")
                self.results.append(('System Monitor', 'FAIL'))
                return False
        except Exception as e:
            logger.error(f"✗ ERROR: {e}")
            self.results.append(('System Monitor', 'ERROR'))
            return False
    
    def test_file_permissions(self):
        """Test 7: File permissions"""
        try:
            logger.info("\n" + "="*60)
            logger.info("TEST 7: File Permissions")
            logger.info("="*60)
            
            import os
            
            # Check key directories
            dirs = [
                '/home/ubuntu/telegram_automation/logs',
                '/home/ubuntu/telegram_automation/data',
                '/home/ubuntu/bitcoin_automation/generated_content'
            ]
            
            all_ok = True
            for dir_path in dirs:
                path = Path(dir_path)
                if path.exists():
                    logger.info(f"✓ {dir_path}: exists")
                else:
                    logger.warning(f"⚠ {dir_path}: does not exist")
                    all_ok = False
            
            if all_ok:
                logger.info("✓ PASS: All directories exist")
                self.results.append(('File Permissions', 'PASS'))
                return True
            else:
                logger.warning("⚠ WARNING: Some directories missing")
                self.results.append(('File Permissions', 'WARNING'))
                return True
        except Exception as e:
            logger.error(f"✗ ERROR: {e}")
            self.results.append(('File Permissions', 'ERROR'))
            return False
    
    def test_disk_space(self):
        """Test 8: Disk space"""
        try:
            logger.info("\n" + "="*60)
            logger.info("TEST 8: Disk Space")
            logger.info("="*60)
            
            import shutil
            
            total, used, free = shutil.disk_usage('/')
            
            free_gb = free / (1024**3)
            used_percent = (used / total) * 100
            
            logger.info(f"  Total: {total / (1024**3):.1f} GB")
            logger.info(f"  Used: {used / (1024**3):.1f} GB ({used_percent:.1f}%)")
            logger.info(f"  Free: {free_gb:.1f} GB")
            
            if free_gb > 1:  # At least 1 GB free
                logger.info("✓ PASS: Sufficient disk space")
                self.results.append(('Disk Space', 'PASS'))
                return True
            else:
                logger.error("✗ FAIL: Insufficient disk space")
                self.results.append(('Disk Space', 'FAIL'))
                return False
        except Exception as e:
            logger.error(f"✗ ERROR: {e}")
            self.results.append(('Disk Space', 'ERROR'))
            return False
    
    def run_all_tests(self):
        """Run all tests"""
        logger.info("\n\n" + "#"*60)
        logger.info("# ARIES76 TELEGRAM AUTOMATION - TEST SUITE")
        logger.info("#"*60)
        logger.info(f"Start time: {datetime.now().isoformat()}\n")
        
        tests = [
            self.test_bot_connection,
            self.test_content_loading,
            self.test_message_formatting,
            self.test_premium_tier_manager,
            self.test_user_engagement,
            self.test_system_monitor,
            self.test_file_permissions,
            self.test_disk_space
        ]
        
        for test in tests:
            try:
                test()
            except Exception as e:
                logger.error(f"Test execution error: {e}")
        
        self.print_summary()
    
    def print_summary(self):
        """Print test summary"""
        logger.info("\n\n" + "="*60)
        logger.info("TEST SUMMARY")
        logger.info("="*60)
        
        passed = sum(1 for _, result in self.results if result == 'PASS')
        failed = sum(1 for _, result in self.results if result == 'FAIL')
        errors = sum(1 for _, result in self.results if result == 'ERROR')
        warnings = sum(1 for _, result in self.results if result == 'WARNING')
        
        logger.info(f"\nResults:")
        for test_name, result in self.results:
            status_symbol = '✓' if result == 'PASS' else '✗' if result == 'FAIL' else '⚠' if result == 'WARNING' else '!'
            logger.info(f"  {status_symbol} {test_name}: {result}")
        
        logger.info(f"\nSummary:")
        logger.info(f"  Passed: {passed}")
        logger.info(f"  Failed: {failed}")
        logger.info(f"  Errors: {errors}")
        logger.info(f"  Warnings: {warnings}")
        logger.info(f"  Total: {len(self.results)}")
        
        pass_rate = (passed / len(self.results) * 100) if self.results else 0
        logger.info(f"\n  Pass Rate: {pass_rate:.1f}%")
        
        logger.info(f"\nEnd time: {datetime.now().isoformat()}")
        logger.info("="*60 + "\n")

def main():
    """Main function"""
    suite = TestSuite()
    suite.run_all_tests()

if __name__ == '__main__':
    main()
