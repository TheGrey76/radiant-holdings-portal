#!/usr/bin/env python3
"""
ARIES76 Enhanced Content Generator
Generates Bitcoin analysis with real-time trend news
"""

import logging
from datetime import datetime
from pathlib import Path

logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'enhanced_content_generator.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class EnhancedContentGenerator:
    """Generate Bitcoin analysis with trend news"""
    
    def __init__(self, newsapi_key=None):
        try:
            from bitcoin_data_fetcher import BitcoinDataFetcher
            self.fetcher = BitcoinDataFetcher(newsapi_key)
            logger.info("Enhanced Content Generator initialized")
        except ImportError:
            logger.error("bitcoin_data_fetcher module not found")
            self.fetcher = None
    
    def generate_telegram_message_with_news(self):
        """Generate Telegram message with price levels and trend news"""
        try:
            if not self.fetcher:
                return None
                
            logger.info("Generating enhanced Telegram message with news...")
            
            price_data = self.fetcher.get_bitcoin_price()
            sentiment = self.fetcher.get_market_sentiment()
            levels = self.fetcher.get_resistance_support()
            news = self.fetcher.get_bitcoin_news(3)
            
            if not price_data or not sentiment or not levels:
                logger.error("Failed to fetch required data")
                return None
            
            message = f"""<b>📊 Bitcoin Market Analysis - Real-time Update</b>

<b>💰 Current Market Status</b>
Price: <b>${price_data['price']:,.2f}</b>
24h Change: <b>{price_data['change_24h']:+.2f}%</b>
Market Cap: <b>${price_data['market_cap']/1e12:.2f}T</b>
Volume 24h: <b>${price_data['volume_24h']/1e9:.2f}B</b>

<b>🎯 Technical Levels</b>
Resistance: <b>${levels['resistance']:,.2f}</b>
Support: <b>${levels['support']:,.2f}</b>
Current: <b>${levels['current']:,.2f}</b>

<b>💭 Market Sentiment</b>
{sentiment['emoji']} <b>{sentiment['sentiment']}</b>

<b>📈 Trading Signals</b>
Signal: <b>{"BUY 🟢" if price_data['change_24h'] > 0 else "SELL 🔴"}</b>
Entry: <b>${price_data['price']:,.2f}</b>
Target: <b>${levels['resistance']:,.2f}</b>
Stop Loss: <b>${levels['support']:,.2f}</b>

<b>📰 TRENDING NEWS</b>
"""
            
            for i, article in enumerate(news, 1):
                title = article['title'][:70]
                source = article['source'][:20]
                message += f"\n{i}. <b>{title}...</b>\n   <i>Source: {source}</i>"
            
            message += f"""

<b>👉 Get Full Analysis & Report:</b>
https://www.aries76.com/bitcoin-2026-report-preview

<b>🔔 Subscribe for daily updates</b>"""
            
            logger.info("✓ Enhanced message with news generated")
            return message.strip()
        except Exception as e:
            logger.error(f"Error generating message: {e}")
            return None
    
    def generate_news_focused_post(self):
        """Generate post focused on trending news"""
        try:
            if not self.fetcher:
                return None
                
            logger.info("Generating news-focused post...")
            
            price_data = self.fetcher.get_bitcoin_price()
            news = self.fetcher.get_bitcoin_news(3)
            
            if not price_data or not news:
                return None
            
            message = f"""<b>📰 Bitcoin Trending News & Market Update</b>

<b>Current Price</b>
💰 <b>${price_data['price']:,.2f}</b> ({price_data['change_24h']:+.2f}%)

<b>🔥 TOP TRENDING NEWS</b>
"""
            
            for i, article in enumerate(news, 1):
                title = article['title'][:60]
                source = article['source'][:20]
                message += f"\n{i}. <b>{title}</b>\n   <i>{source}</i>"
            
            message += f"""

<b>What's Moving the Market?</b>
Stay updated with latest Bitcoin news and market insights.

<b>👉 Full Analysis & Trading Signals:</b>
https://www.aries76.com/bitcoin-2026-report-preview

<b>🔔 Subscribe for daily updates</b>"""
            
            logger.info("✓ News-focused post generated")
            return message.strip()
        except Exception as e:
            logger.error(f"Error generating news post: {e}")
            return None

def main():
    generator = EnhancedContentGenerator()
    
    print("\n" + "=" * 70)
    print("ENHANCED CONTENT GENERATOR - TEST")
    print("=" * 70)
    
    print("\n📱 TELEGRAM MESSAGE WITH NEWS:")
    print("-" * 70)
    message = generator.generate_telegram_message_with_news()
    if message:
        print(message)
    else:
        print("Could not generate message")
    
    print("\n\n📰 NEWS-FOCUSED POST:")
    print("-" * 70)
    news_post = generator.generate_news_focused_post()
    if news_post:
        print(news_post)
    else:
        print("Could not generate news post")
    
    print("\n" + "=" * 70 + "\n")

if __name__ == '__main__':
    main()
