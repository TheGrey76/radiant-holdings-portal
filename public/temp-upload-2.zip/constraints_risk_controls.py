"""Implements sophisticated constraints and risk controls for portfolios."""

from pypfopt import EfficientFrontier

class ConstraintsRiskControls:
    """Applies advanced constraints and risk controls to portfolio optimization."""

    def __init__(self, mu, S, prices_df):
        self.mu = mu
        self.S = S
        self.prices_df = prices_df
        self.ef = EfficientFrontier(self.mu, self.S)

    def add_turnover_constraint(self, max_turnover=0.1):
        """Adds a turnover constraint to the portfolio."""
        self.ef.add_constraint(lambda w: w.sum() <= 1 + max_turnover)
        self.ef.add_constraint(lambda w: w.sum() >= 1 - max_turnover)

    def add_sector_constraints(self, sector_mapper, sector_lower, sector_upper):
        """Adds sector exposure constraints."""
        self.ef.add_sector_constraints(sector_mapper, sector_lower, sector_upper)

    def add_liquidity_constraint(self, min_liquidity=1e6):
        """Adds a liquidity constraint based on average daily volume."""
        avg_daily_volume = self.prices_df.iloc[-20:].mean() * self.prices_df.iloc[-20:].mean()
        self.ef.add_constraint(lambda w: (w * avg_daily_volume).sum() >= min_liquidity)

    def optimize_with_constraints(self):
        """Optimizes the portfolio with all added constraints."""
        self.ef.max_sharpe()
        return self.ef.clean_weights()

if __name__ == '__main__':
    # Example usage
    import pandas as pd

    data = {
        'BTC-USD': [50000 + i*100 for i in range(300)],
        'ETH-USD': [3000 + i*50 for i in range(300)],
        'TECH_STOCK': [200 + i*5 for i in range(300)],
        'FIN_STOCK': [100 + i*2 for i in range(300)]
    }
    prices_df = pd.DataFrame(data, index=pd.to_datetime(pd.date_range('2023-01-01', periods=300)))

    mu = prices_df.pct_change().mean() * 252
    S = prices_df.pct_change().cov() * 252

    constraints_model = ConstraintsRiskControls(mu, S, prices_df)

    # Sector mapping
    sector_mapper = {
        'BTC-USD': 'Crypto',
        'ETH-USD': 'Crypto',
        'TECH_STOCK': 'Tech',
        'FIN_STOCK': 'Financials'
    }
    sector_lower = {'Crypto': 0.2, 'Tech': 0.1}
    sector_upper = {'Crypto': 0.8, 'Financials': 0.3}

    constraints_model.add_sector_constraints(sector_mapper, sector_lower, sector_upper)
    constraints_model.add_turnover_constraint()

    print("Portfolio with Constraints:")
    print(constraints_model.optimize_with_constraints())
