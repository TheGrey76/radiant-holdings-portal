import React, { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

interface AllocationData {
  model: string;
  allocation: { [key: string]: number };
  timestamp: string;
}

interface PortfolioAllocationProps {
  modelName: 'conservative' | 'balanced' | 'aggressive';
}

const COLORS = ['#FF6B35', '#004E89', '#F7B801', '#1A535C'];

export const PortfolioAllocation: React.FC<PortfolioAllocationProps> = ({ modelName }) => {
  const [allocationData, setAllocationData] = useState<AllocationData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAllocationData();
  }, [modelName]);

  const fetchAllocationData = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/portfolio-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: modelName, action: 'allocation' })
      });
      const data = await response.json();
      setAllocationData(data);
    } catch (error) {
      console.error('Error fetching allocation data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>;
  }

  if (!allocationData) {
    return <div className="text-red-500">Failed to load allocation data</div>;
  }

  const chartData = Object.entries(allocationData.allocation).map(([name, value]) => ({
    name: name.replace('-USD', '').replace('^', ''),
    value: value * 100
  }));

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold mb-4 capitalize">{modelName} Allocation Model</h2>
      <ResponsiveContainer width="100%" height={400}>
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={({ name, value }) => `${name}: ${value.toFixed(1)}%`}
            outerRadius={120}
            fill="#8884d8"
            dataKey="value"
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(value: number) => `${value.toFixed(2)}%`} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
      <div className="mt-4 text-sm text-gray-500">
        Last updated: {new Date(allocationData.timestamp).toLocaleString()}
      </div>
    </div>
  );
};
