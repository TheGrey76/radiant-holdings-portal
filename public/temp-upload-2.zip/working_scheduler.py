#!/usr/bin/env python3
"""
ARIES76 Working Scheduler
Automated Bitcoin analysis publishing with trending news
Schedule: 6:00 AM + 6:30 PM CET
"""

import asyncio
import logging
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from enhanced_content_generator import EnhancedContentGenerator
import httpx

logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'working_scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class WorkingScheduler:
    """Working scheduler with proper logging"""
    
    def __init__(self):
        self.generator = EnhancedContentGenerator()
        self.token = "8269982447:AAGR7PM7Dkpbslb7eT-rAimj5puKxcEfaV8"
        self.channel = "@aries76_bitcoin"
        self.last_morning = None
        self.last_evening = None
        logger.info("Working Scheduler initialized")
        logger.info("Schedule: 6:00 AM + 6:30 PM CET")
    
    def get_cet_time(self):
        """Get current time in CET (UTC+1)"""
        cet_offset = timedelta(hours=1)
        now_utc = datetime.now(timezone.utc)
        now_cet = now_utc + cet_offset
        return now_cet
    
    async def publish(self, message):
        """Publish message to Telegram"""
        try:
            logger.info("Publishing message to Telegram...")
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"https://api.telegram.org/bot{self.token}/sendMessage",
                    json={
                        "chat_id": self.channel,
                        "text": message,
                        "parse_mode": "HTML"
                    },
                    timeout=30
                )
                
                if response.status_code == 200:
                    logger.info("✓ Message published successfully")
                    return True
                else:
                    logger.error(f"Telegram error: {response.text}")
                    return False
        except Exception as e:
            logger.error(f"Error publishing: {e}")
            return False
    
    async def run_morning(self):
        """Run morning analysis"""
        try:
            logger.info("=" * 70)
            logger.info("📤 MORNING ANALYSIS - GENERATING & PUBLISHING")
            logger.info("=" * 70)
            
            message = self.generator.generate_telegram_message_with_news()
            
            if not message:
                logger.error("Failed to generate morning message")
                return False
            
            result = await self.publish(message)
            
            if result:
                logger.info("✅ Morning analysis published")
                self.last_morning = self.get_cet_time()
            
            return result
        except Exception as e:
            logger.error(f"Error in morning analysis: {e}")
            return False
    
    async def run_evening(self):
        """Run evening analysis"""
        try:
            logger.info("=" * 70)
            logger.info("📤 EVENING ANALYSIS - GENERATING & PUBLISHING")
            logger.info("=" * 70)
            
            message = self.generator.generate_news_focused_post()
            
            if not message:
                logger.error("Failed to generate evening message")
                return False
            
            result = await self.publish(message)
            
            if result:
                logger.info("✅ Evening analysis published")
                self.last_evening = self.get_cet_time()
            
            return result
        except Exception as e:
            logger.error(f"Error in evening analysis: {e}")
            return False
    
    def should_run_morning(self):
        """Check if morning task should run (6:00 AM CET)"""
        now = self.get_cet_time()
        
        # Run at 6:00 AM CET (hour=6, minute=0-4)
        if now.hour == 6 and now.minute < 5:
            if self.last_morning is None or (now - self.last_morning).total_seconds() > 3600:
                logger.info(f"Morning window detected: {now.strftime('%H:%M:%S')}")
                return True
        
        return False
    
    def should_run_evening(self):
        """Check if evening task should run (6:30 PM CET)"""
        now = self.get_cet_time()
        
        # Run at 6:30 PM CET (hour=18, minute=30-34)
        if now.hour == 18 and 30 <= now.minute < 35:
            if self.last_evening is None or (now - self.last_evening).total_seconds() > 3600:
                logger.info(f"Evening window detected: {now.strftime('%H:%M:%S')}")
                return True
        
        return False
    
    def run(self):
        """Main scheduler loop"""
        logger.info("=" * 70)
        logger.info("ARIES76 WORKING SCHEDULER - STARTED")
        logger.info("=" * 70)
        logger.info("Press Ctrl+C to stop")
        logger.info("")
        logger.info("Timezone: CET (UTC+1)")
        logger.info("Schedule:")
        logger.info("  - 6:00 AM CET: Morning analysis with trending news")
        logger.info("  - 6:30 PM CET: Evening analysis with trending news")
        logger.info("")
        logger.info("=" * 70)
        
        check_count = 0
        
        try:
            while True:
                now_cet = self.get_cet_time()
                check_count += 1
                
                # Log every 10 checks (every 5 minutes)
                if check_count % 10 == 0:
                    logger.info(f"[CHECK #{check_count}] Current time: {now_cet.strftime('%Y-%m-%d %H:%M:%S CET')}")
                
                # Check morning task
                if self.should_run_morning():
                    logger.info(f"Running morning task at {now_cet.strftime('%Y-%m-%d %H:%M:%S CET')}")
                    asyncio.run(self.run_morning())
                    time.sleep(60)  # Wait 1 minute to avoid duplicate runs
                
                # Check evening task
                if self.should_run_evening():
                    logger.info(f"Running evening task at {now_cet.strftime('%Y-%m-%d %H:%M:%S CET')}")
                    asyncio.run(self.run_evening())
                    time.sleep(60)  # Wait 1 minute to avoid duplicate runs
                
                time.sleep(30)
        except KeyboardInterrupt:
            logger.info("Scheduler stopped by user")
        except Exception as e:
            logger.error(f"Fatal error: {e}")

def main():
    """Main entry point"""
    scheduler = WorkingScheduler()
    scheduler.run()

if __name__ == '__main__':
    main()
