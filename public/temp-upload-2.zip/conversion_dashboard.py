#!/usr/bin/env python3
"""
ARIES76 Conversion Dashboard
Real-time analytics and reporting for sales funnel
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from conversion_tracker import ConversionTracker

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'conversion_dashboard.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ConversionDashboard:
    """Real-time conversion analytics dashboard"""
    
    def __init__(self):
        """Initialize dashboard"""
        self.tracker = ConversionTracker()
        logger.info("Conversion Dashboard initialized")
    
    def print_header(self, title):
        """Print formatted header"""
        print("\n" + "=" * 70)
        print(f"  {title}")
        print("=" * 70)
    
    def print_metric(self, label, value, unit="", decimals=2):
        """Print formatted metric"""
        if isinstance(value, float):
            formatted_value = f"{value:.{decimals}f}{unit}"
        else:
            formatted_value = f"{value}{unit}"
        print(f"  {label:<30} {formatted_value:>20}")
    
    def display_funnel(self):
        """Display conversion funnel"""
        self.print_header("📊 CONVERSION FUNNEL")
        
        funnel = self.tracker.get_conversion_funnel()
        
        self.print_metric("Views", funnel.get('views', 0))
        self.print_metric("Clicks", funnel.get('clicks', 0))
        self.print_metric("Purchases", funnel.get('purchases', 0))
        
        print()
        self.print_metric("Click Rate", funnel.get('click_rate', 0), "%", 1)
        self.print_metric("Conversion Rate", funnel.get('conversion_rate', 0), "%", 1)
        self.print_metric("Purchase Rate", funnel.get('purchase_rate', 0), "%", 1)
        
        print()
        self.print_metric("Total Revenue", funnel.get('revenue', 0), " USD", 2)
        self.print_metric("Average Order Value", funnel.get('aov', 0), " USD", 2)
    
    def display_daily_stats(self, days=7):
        """Display daily statistics"""
        self.print_header(f"📈 DAILY STATISTICS (Last {days} days)")
        
        daily = self.tracker.get_daily_conversions(days)
        
        if not daily:
            print("  No data available")
            return
        
        # Print header
        print(f"  {'Date':<12} {'Views':>8} {'Clicks':>8} {'Purchases':>10} {'Revenue':>12} {'Conv %':>8}")
        print("  " + "-" * 65)
        
        # Print daily data
        for date in sorted(daily.keys()):
            data = daily[date]
            conv_rate = data.get('conversion_rate', 0)
            print(f"  {date:<12} {data['views']:>8} {data['clicks']:>8} {data['purchases']:>10} ${data['revenue']:>11.2f} {conv_rate:>7.1f}%")
    
    def display_top_messages(self):
        """Display top converting messages"""
        self.print_header("🏆 TOP CONVERTING MESSAGES")
        
        top_messages = self.tracker.get_top_converting_messages(5)
        
        if not top_messages:
            print("  No message data available")
            return
        
        # Print header
        print(f"  {'Message ID':<20} {'Views':>8} {'Clicks':>8} {'Conv %':>8}")
        print("  " + "-" * 50)
        
        # Print messages
        for msg_id, stats in top_messages.items():
            conv_rate = stats.get('conversion_rate', 0)
            print(f"  {msg_id:<20} {stats['views']:>8} {stats['clicks']:>8} {conv_rate:>7.1f}%")
    
    def display_performance_summary(self):
        """Display overall performance summary"""
        self.print_header("📊 PERFORMANCE SUMMARY")
        
        funnel = self.tracker.get_conversion_funnel()
        daily = self.tracker.get_daily_conversions(1)
        
        # Overall metrics
        print("\n  OVERALL PERFORMANCE:")
        self.print_metric("Total Views", funnel.get('views', 0))
        self.print_metric("Total Clicks", funnel.get('clicks', 0))
        self.print_metric("Total Purchases", funnel.get('purchases', 0))
        self.print_metric("Total Revenue", funnel.get('revenue', 0), " USD", 2)
        
        # Today's metrics
        print("\n  TODAY'S PERFORMANCE:")
        today = datetime.now().strftime('%Y-%m-%d')
        today_data = daily.get(today, {
            'views': 0,
            'clicks': 0,
            'purchases': 0,
            'revenue': 0
        })
        
        self.print_metric("Today's Views", today_data.get('views', 0))
        self.print_metric("Today's Clicks", today_data.get('clicks', 0))
        self.print_metric("Today's Purchases", today_data.get('purchases', 0))
        self.print_metric("Today's Revenue", today_data.get('revenue', 0), " USD", 2)
        
        # Efficiency metrics
        print("\n  EFFICIENCY METRICS:")
        self.print_metric("Click Rate", funnel.get('click_rate', 0), "%", 1)
        self.print_metric("Conversion Rate", funnel.get('conversion_rate', 0), "%", 1)
        self.print_metric("Avg Order Value", funnel.get('aov', 0), " USD", 2)
    
    def display_user_journey(self, user_id):
        """Display user journey"""
        self.print_header(f"👤 USER JOURNEY (ID: {user_id})")
        
        path = self.tracker.get_user_conversion_path(user_id)
        
        if not path['events']:
            print("  No events found for this user")
            return
        
        print(f"  Status: {path['status'].upper()}")
        print(f"  Total Events: {path['total_events']}")
        print()
        
        print("  EVENT TIMELINE:")
        print("  " + "-" * 65)
        
        for i, event in enumerate(path['events'], 1):
            timestamp = event['timestamp']
            event_type = event['event'].upper()
            print(f"  {i}. [{timestamp}] {event_type}")
            
            # Print event details
            for key, value in event['details'].items():
                print(f"     • {key}: {value}")
    
    def display_full_dashboard(self):
        """Display complete dashboard"""
        print("\n" * 2)
        print("╔" + "=" * 68 + "╗")
        print("║" + " " * 15 + "ARIES76 CONVERSION DASHBOARD" + " " * 25 + "║")
        print("╚" + "=" * 68 + "╝")
        
        self.display_performance_summary()
        self.display_funnel()
        self.display_daily_stats(7)
        self.display_top_messages()
        
        print("\n" + "=" * 70)
        print(f"  Dashboard generated: {datetime.now().isoformat()}")
        print("=" * 70 + "\n")
    
    def export_report(self, filename=None):
        """Export report to JSON"""
        try:
            if not filename:
                filename = f"conversion_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            report = {
                'timestamp': datetime.now().isoformat(),
                'funnel': self.tracker.get_conversion_funnel(),
                'daily_stats': self.tracker.get_daily_conversions(30),
                'top_messages': self.tracker.get_top_converting_messages(10),
                'total_conversions': len(self.tracker.conversions)
            }
            
            filepath = Path('/home/ubuntu/telegram_automation/data') / filename
            with open(filepath, 'w') as f:
                json.dump(report, f, indent=2)
            
            logger.info(f"Report exported to {filepath}")
            print(f"\n✓ Report exported to: {filepath}")
            return True
        except Exception as e:
            logger.error(f"Error exporting report: {e}")
            return False

def main():
    """Main function"""
    dashboard = ConversionDashboard()
    
    # Display full dashboard
    dashboard.display_full_dashboard()
    
    # Export report
    dashboard.export_report()

if __name__ == '__main__':
    main()
