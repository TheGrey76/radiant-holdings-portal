#!/usr/bin/env python3
"""
Dynamic allocation algorithms for the portfolio management system.
"""

import pandas as pd
from pypfopt import EfficientFrontier, risk_models, expected_returns
from pypfopt.black_litterman import BlackLittermanModel
from pypfopt import black_litterman
from pypfopt.hierarchical_portfolio import HRPOpt

class DynamicAllocation:
    def __init__(self, prices_df):
        self.prices_df = prices_df
        self.returns = self.prices_df.pct_change().dropna()

    def get_mean_variance_allocation(self, target_volatility=0.20):
        """Calculates the mean-variance optimal portfolio allocation."""
        mu = expected_returns.mean_historical_return(self.prices_df)
        S = risk_models.sample_cov(self.prices_df)

        ef = EfficientFrontier(mu, S)
        ef.efficient_risk(target_volatility=target_volatility)
        weights = ef.clean_weights()
        return weights

    def get_hrp_allocation(self):
        """Calculates the Hierarchical Risk Parity portfolio allocation."""
        hrp = HRPOpt(self.returns)
        hrp.optimize()
        weights = hrp.clean_weights()
        return weights

    def get_black_litterman_allocation(self, market_caps, view_dict, risk_aversion):
        """Calculates the Black-Litterman portfolio allocation."""
        S = risk_models.sample_cov(self.prices_df)
        # Use the provided risk_aversion parameter. A common value is 2.5
        delta = risk_aversion
        market_prior = black_litterman.market_implied_prior_returns(market_caps, delta, S)

        bl = BlackLittermanModel(S, pi=market_prior, absolute_views=view_dict)
        ret_bl = bl.bl_returns()
        S_bl = bl.bl_cov()

        ef = EfficientFrontier(ret_bl, S_bl)
        ef.max_sharpe()
        weights = ef.clean_weights()
        return weights

if __name__ == '__main__':
    # Example usage with dummy data
    data = {
        'BTC': [50000, 51000, 52000, 51500, 53000, 54000, 53500],
        'ETH': [3000, 3100, 3050, 3200, 3150, 3250, 3300],
        'SPY': [400, 401, 402, 403, 404, 405, 406],
        'GLD': [170, 171, 170, 172, 171, 173, 172]
    }
    prices_df = pd.DataFrame(data)

    allocation_model = DynamicAllocation(prices_df)

    print("Mean-Variance Allocation:")
    print(allocation_model.get_mean_variance_allocation())

    print("\nHierarchical Risk Parity Allocation:")
    print(allocation_model.get_hrp_allocation())

    # Black-Litterman example
    market_caps = {"BTC": 1e12, "ETH": 4e11, "SPY": 4e11, "GLD": 1e11}
    view_dict = {
        "BTC": 0.10, # 10% expected return for BTC
        "ETH": 0.15  # 15% expected return for ETH
    }
    print("\nBlack-Litterman Allocation:")
    # Using a risk_aversion of 2.5, a common value
    print(allocation_model.get_black_litterman_allocation(market_caps, view_dict, risk_aversion=2.5))
