#!/usr/bin/env python3
"""
ARIES76 Telegram Integration
Integrates Bitcoin content generation with Telegram publishing
"""

import sys
import os
import json
import logging
from datetime import datetime
from pathlib import Path
import asyncio

# Add paths
sys.path.insert(0, '/home/ubuntu/bitcoin_automation')
sys.path.insert(0, '/home/ubuntu/telegram_automation')

from telegram_bot import ARIES76TelegramBot
from telegram_group_manager import TelegramGroupManager

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'integration.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class TelegramIntegration:
    """Integrate Bitcoin content with Telegram"""
    
    def __init__(self):
        """Initialize integration"""
        self.bot = ARIES76TelegramBot()
        self.group_manager = TelegramGroupManager()
        self.content_dir = Path('/home/ubuntu/bitcoin_automation/generated_content')
        
        logger.info("Telegram Integration initialized")
    
    async def publish_daily_content(self):
        """Publish daily content to all channels"""
        try:
            logger.info("Publishing daily content to Telegram")
            
            # Load content
            content = self.bot.load_latest_content()
            if not content:
                logger.warning("No content available")
                return False
            
            # Publish to public channel
            logger.info("Publishing to public channel...")
            channel_success = await self.bot.publish_daily_analysis()
            
            # Publish to premium group if configured
            premium_group_id = os.getenv('TELEGRAM_PREMIUM_GROUP_ID')
            if premium_group_id:
                logger.info(f"Publishing to premium group {premium_group_id}...")
                
                # Format premium message
                article = content.get('article', '')
                premium_message = f"""
<b>🔐 Premium Analysis</b>

{article[:800]}...

<b>Full Premium Report:</b> https://www.aries76.com/premium

<i>Exclusive to ARIES76 Premium Members</i>
"""
                await self.group_manager.send_to_group(premium_group_id, premium_message)
            
            return channel_success
        except Exception as e:
            logger.error(f"Error publishing daily content: {e}")
            return False
    
    async def publish_market_update(self, market_data):
        """Publish market update"""
        try:
            logger.info("Publishing market update")
            
            message = f"""
<b>📈 Market Update</b>

<b>Bitcoin Price:</b> ${market_data.get('price', 'N/A')}
<b>24h Change:</b> {market_data.get('change_24h', 'N/A')}%
<b>Market Cap:</b> ${market_data.get('market_cap', 'N/A')}

<b>Analysis:</b>
{market_data.get('analysis', 'Check ARIES76 for full analysis')}

<b>Get detailed analysis:</b> https://www.aries76.com/funnel-bitcoin-report
"""
            return await self.bot.send_to_channel(message)
        except Exception as e:
            logger.error(f"Error publishing market update: {e}")
            return False
    
    async def publish_trading_signal(self, signal_data):
        """Publish trading signal to all channels"""
        try:
            logger.info("Publishing trading signal")
            
            # Publish to public channel
            await self.bot.send_trading_signal(signal_data)
            
            # Publish to premium group
            premium_group_id = os.getenv('TELEGRAM_PREMIUM_GROUP_ID')
            if premium_group_id:
                await self.group_manager.send_premium_alert(premium_group_id, signal_data)
            
            return True
        except Exception as e:
            logger.error(f"Error publishing trading signal: {e}")
            return False
    
    async def send_notification(self, title, message):
        """Send notification to channel"""
        try:
            full_message = f"<b>{title}</b>\n\n{message}"
            return await self.bot.send_to_channel(full_message)
        except Exception as e:
            logger.error(f"Error sending notification: {e}")
            return False
    
    def get_publication_stats(self):
        """Get publication statistics"""
        try:
            logs_file = logs_dir / 'publications.log'
            if not logs_file.exists():
                return {
                    'total_publications': 0,
                    'last_publication': None,
                    'publications_this_week': 0
                }
            
            with open(logs_file, 'r') as f:
                lines = f.readlines()
            
            return {
                'total_publications': len(lines),
                'last_publication': lines[-1].strip() if lines else None,
                'publications_this_week': len([l for l in lines if 'week' in l.lower()])
            }
        except Exception as e:
            logger.error(f"Error getting stats: {e}")
            return {}

async def main():
    """Main function for testing"""
    integration = TelegramIntegration()
    
    # Test connection
    if not await integration.bot.test_connection():
        logger.error("Failed to connect")
        return
    
    # Publish daily content
    await integration.publish_daily_content()
    
    # Get stats
    stats = integration.get_publication_stats()
    logger.info(f"Publication stats: {stats}")

if __name__ == '__main__':
    asyncio.run(main())
