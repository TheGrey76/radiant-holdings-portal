"""Implements multi-timeframe asset allocation strategies."""

import pandas as pd
from dynamic_allocation import AdvancedDynamicAllocation

class MultiTimeframeAllocation:
    """Combines strategic and tactical asset allocation."""

    def __init__(self, prices_df_long_term, prices_df_short_term):
        self.prices_df_long_term = prices_df_long_term
        self.prices_df_short_term = prices_df_short_term
        self.saa_model = AdvancedDynamicAllocation(prices_df_long_term)
        self.taa_model = AdvancedDynamicAllocation(prices_df_short_term)

    def get_strategic_allocation(self):
        """Calculates the long-term strategic asset allocation (SAA)."""
        # Using a robust allocation method for the strategic view
        return self.saa_model.get_hrp_allocation()

    def get_tactical_allocation(self, momentum_window=20):
        """Calculates the short-term tactical asset allocation (TAA)."""
        # Using a momentum-based tactical tilt
        momentum = self.prices_df_short_term.pct_change(momentum_window).iloc[-1]
        tactical_weights = momentum / momentum.sum()
        return tactical_weights

    def get_combined_allocation(self, saa_weight=0.7, taa_weight=0.3):
        """Combines SAA and TAA into a final allocation."""
        saa = self.get_strategic_allocation()
        taa = self.get_tactical_allocation()

        # Ensure both Series have the same index
        saa = pd.Series(saa)
        combined_index = saa.index.union(taa.index)
        saa = saa.reindex(combined_index, fill_value=0)
        taa = taa.reindex(combined_index, fill_value=0)

        combined_weights = saa * saa_weight + taa * taa_weight
        return combined_weights / combined_weights.sum()

if __name__ == '__main__':
    # Example usage
    data_long_term = {
        'BTC-USD': [50000 + i*100 for i in range(1000)],
        'ETH-USD': [3000 + i*50 for i in range(1000)],
        '^GSPC': [4000 + i*10 for i in range(1000)],
        'GLD': [180 + i*0.1 for i in range(1000)]
    }
    prices_df_long_term = pd.DataFrame(data_long_term, index=pd.to_datetime(pd.date_range('2021-01-01', periods=1000)))

    data_short_term = {
        'BTC-USD': [70000 + i*200 for i in range(100)],
        'ETH-USD': [4000 + i*100 for i in range(100)],
        '^GSPC': [5000 + i*20 for i in range(100)],
        'GLD': [200 + i*0.2 for i in range(100)]
    }
    prices_df_short_term = pd.DataFrame(data_short_term, index=pd.to_datetime(pd.date_range('2024-01-01', periods=100)))

    multi_timeframe_model = MultiTimeframeAllocation(prices_df_long_term, prices_df_short_term)

    print("Strategic Allocation (SAA):")
    print(multi_timeframe_model.get_strategic_allocation())

    print("\nTactical Allocation (TAA):")
    print(multi_timeframe_model.get_tactical_allocation())

    print("\nCombined Allocation:")
    print(multi_timeframe_model.get_combined_allocation())
