#!/usr/bin/env python3
"""
ARIES76 Unified Automation Orchestrator V2
Coordinates Bitcoin content generation and Telegram publishing
- Multiple daily posts (morning + evening)
- Conversion tracking to report
- Premium tier system ready
"""

import sys
import os
import schedule
import time
import logging
import asyncio
from datetime import datetime
from pathlib import Path

# Add paths
sys.path.insert(0, '/home/ubuntu/bitcoin_automation')
sys.path.insert(0, '/home/ubuntu/telegram_automation')

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'orchestrator_v2.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class UnifiedOrchestratorV2:
    """Orchestrate Bitcoin content generation and multi-channel Telegram publishing"""
    
    def __init__(self):
        """Initialize orchestrator"""
        self.bitcoin_dir = Path('/home/ubuntu/bitcoin_automation')
        self.telegram_dir = Path('/home/ubuntu/telegram_automation')
        self.content_dir = self.bitcoin_dir / 'generated_content'
        
        # Import modules
        from telegram_integration import TelegramIntegration
        from user_engagement import UserEngagement
        
        self.integration = TelegramIntegration()
        self.engagement = UserEngagement()
        
        logger.info("Unified Orchestrator V2 initialized")
    
    def job_generate_content(self):
        """Job: Generate Bitcoin content (once daily)"""
        try:
            logger.info("=" * 60)
            logger.info("STARTING: Bitcoin Content Generation")
            logger.info("=" * 60)
            
            try:
                from bitcoin_automation.bitcoin_content_generator import BitcoinContentGenerator
                
                generator = BitcoinContentGenerator()
                result = generator.generate_daily_content()
                
                if result:
                    logger.info("✓ Bitcoin content generated successfully")
                    logger.info(f"  Article: {result.get('article_file', 'N/A')}")
                    logger.info(f"  Posts: {result.get('posts_file', 'N/A')}")
                    return True
                else:
                    logger.error("✗ Bitcoin content generation failed")
                    return False
            except ImportError:
                logger.warning("Bitcoin generator module not found, skipping generation")
                return False
        except Exception as e:
            logger.error(f"Error in generate_content job: {e}")
            return False
    
    async def job_publish_morning(self):
        """Job: Publish morning analysis (6:00 AM CET)"""
        try:
            logger.info("\n" + "=" * 60)
            logger.info("STARTING: Morning Publication (6:00 AM CET)")
            logger.info("=" * 60)
            
            # Check if content exists
            articles = sorted(self.content_dir.glob('article_*.md'))
            if not articles:
                logger.warning("No content found to publish")
                return False
            
            latest_article = articles[-1]
            logger.info(f"Publishing: {latest_article.name}")
            
            # Publish to Telegram
            result = await self.integration.publish_daily_content()
            
            if result:
                logger.info("✓ Morning content published successfully")
                # Track publication event
                self.engagement.track_event(0, 'publication', {
                    'type': 'morning',
                    'timestamp': datetime.now().isoformat()
                })
                return True
            else:
                logger.error("✗ Morning publishing failed")
                return False
        except Exception as e:
            logger.error(f"Error in morning publication: {e}")
            return False
    
    async def job_publish_evening(self):
        """Job: Publish evening analysis (6:00 PM CET)"""
        try:
            logger.info("\n" + "=" * 60)
            logger.info("STARTING: Evening Publication (6:00 PM CET)")
            logger.info("=" * 60)
            
            # Load latest content
            content = self.integration.bot.load_latest_content()
            if not content:
                logger.warning("No content found for evening publication")
                return False
            
            # Create evening-specific message
            article = content.get('article', '')
            lines = article.split('\n')
            title = lines[0].replace('#', '').strip() if lines else "Bitcoin Analysis"
            
            evening_message = f"""
<b>📊 Evening Market Update - {title}</b>

<b>Bitcoin Evening Analysis</b>

{article[:400]}...

<b>📈 Key Levels:</b>
• Resistance: Check full analysis
• Support: Check full analysis

<b>Read full analysis:</b> https://www.aries76.com/funnel-bitcoin-report

<b>🔔 Subscribe for daily updates</b>
"""
            
            result = await self.integration.bot.send_to_channel(evening_message.strip())
            
            if result:
                logger.info("✓ Evening content published successfully")
                # Track publication event
                self.engagement.track_event(0, 'publication', {
                    'type': 'evening',
                    'timestamp': datetime.now().isoformat()
                })
                return True
            else:
                logger.error("✗ Evening publishing failed")
                return False
        except Exception as e:
            logger.error(f"Error in evening publication: {e}")
            return False
    
    def job_combined_workflow(self):
        """Combined job: Generate and publish morning content"""
        try:
            logger.info("\n" + "=" * 60)
            logger.info("STARTING: Combined Workflow (Generate + Publish)")
            logger.info("=" * 60)
            
            # Step 1: Generate content
            logger.info("\nStep 1: Generating Bitcoin content...")
            gen_result = self.job_generate_content()
            
            if not gen_result:
                logger.error("Content generation failed, skipping publishing")
                return False
            
            # Wait for file to be written
            time.sleep(2)
            
            # Step 2: Publish morning content
            logger.info("\nStep 2: Publishing morning analysis...")
            pub_result = asyncio.run(self.job_publish_morning())
            
            if pub_result:
                logger.info("\n✓ Morning workflow completed successfully")
                logger.info("=" * 60 + "\n")
                return True
            else:
                logger.error("\n✗ Workflow failed at publishing stage")
                logger.info("=" * 60 + "\n")
                return False
        except Exception as e:
            logger.error(f"Error in combined workflow: {e}")
            return False
    
    def schedule_jobs(self):
        """Schedule all jobs"""
        logger.info("Scheduling jobs...")
        
        # Morning: Generate + Publish at 6:00 AM CET
        schedule.every().day.at("06:00").do(self.job_combined_workflow)
        
        # Evening: Publish only at 6:00 PM CET (18:00)
        schedule.every().day.at("18:00").do(lambda: asyncio.run(self.job_publish_evening()))
        
        logger.info("✓ Jobs scheduled:")
        logger.info("  - Combined workflow (Generate + Publish) at 06:00 CET")
        logger.info("  - Evening publication at 18:00 CET")
    
    def run(self):
        """Run the orchestrator"""
        self.schedule_jobs()
        
        logger.info("\n" + "=" * 60)
        logger.info("ARIES76 UNIFIED ORCHESTRATOR V2 STARTED")
        logger.info("=" * 60)
        logger.info(f"Start time: {datetime.now().isoformat()}")
        logger.info("Schedule:")
        logger.info("  - 6:00 AM CET: Generate + Publish morning analysis")
        logger.info("  - 6:00 PM CET: Publish evening analysis")
        logger.info("Monitoring for scheduled jobs...")
        logger.info("Press Ctrl+C to stop\n")
        
        try:
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
        except KeyboardInterrupt:
            logger.info("\n" + "=" * 60)
            logger.info("ORCHESTRATOR STOPPED")
            logger.info("=" * 60)

def main():
    """Main function"""
    orchestrator = UnifiedOrchestratorV2()
    orchestrator.run()

if __name__ == '__main__':
    main()
