import React, { useState } from 'react';
import { PortfolioAllocation } from './PortfolioAllocation';
import { RiskMetrics } from './RiskMetrics';

type ModelType = 'conservative' | 'balanced' | 'aggressive';

export const PortfolioDashboard: React.FC = () => {
  const [selectedModel, setSelectedModel] = useState<ModelType>('balanced');

  const models: { value: ModelType; label: string; description: string; color: string }[] = [
    {
      value: 'conservative',
      label: 'Conservative',
      description: 'Low risk, stable returns',
      color: 'bg-green-500'
    },
    {
      value: 'balanced',
      label: 'Balanced',
      description: 'Moderate risk, balanced growth',
      color: 'bg-blue-500'
    },
    {
      value: 'aggressive',
      label: 'Aggressive',
      description: 'High risk, maximum growth',
      color: 'bg-red-500'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            ARIES76 Portfolio Management
          </h1>
          <p className="text-gray-600">
            Advanced dynamic asset allocation with institutional-grade risk management
          </p>
        </div>

        {/* Model Selection */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {models.map((model) => (
            <button
              key={model.value}
              onClick={() => setSelectedModel(model.value)}
              className={`p-6 rounded-lg border-2 transition-all ${
                selectedModel === model.value
                  ? 'border-gray-900 shadow-lg scale-105'
                  : 'border-gray-200 hover:border-gray-400'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xl font-bold">{model.label}</h3>
                <div className={`w-4 h-4 rounded-full ${model.color}`} />
              </div>
              <p className="text-sm text-gray-600">{model.description}</p>
              {selectedModel === model.value && (
                <div className="mt-3 text-sm font-semibold text-gray-900">
                  ✓ Currently Selected
                </div>
              )}
            </button>
          ))}
        </div>

        {/* Dashboard Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <PortfolioAllocation modelName={selectedModel} />
          <RiskMetrics modelName={selectedModel} />
        </div>

        {/* Additional Info */}
        <div className="mt-8 bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-xl font-bold mb-4">Model Methodology</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-semibold text-green-600 mb-2">Conservative</h4>
              <p className="text-sm text-gray-600">
                Uses Hierarchical Risk Parity (HRP) to balance risk contribution across all assets.
                Ideal for capital preservation with steady growth.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-blue-600 mb-2">Balanced</h4>
              <p className="text-sm text-gray-600">
                Mean-Variance Optimization targeting moderate volatility.
                Balances risk and return for consistent performance.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-red-600 mb-2">Aggressive</h4>
              <p className="text-sm text-gray-600">
                Black-Litterman model incorporating market views for maximum growth potential.
                Suitable for high risk tolerance investors.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
