#!/usr/bin/env python3
"""
Image Generator for Social Media
Creates visual content for Twitter, Instagram, and LinkedIn posts
"""

import os
import json
import logging
from typing import Dict, Optional
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont
import requests
from io import BytesIO

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/ubuntu/bitcoin_automation/logs/image_generation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class BitcoinChartGenerator:
    """Generate Bitcoin market charts and visualizations"""
    
    def __init__(self, output_dir: str = "/home/ubuntu/bitcoin_automation/generated_images"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # Colors
        self.bitcoin_orange = "#F7931A"
        self.dark_bg = "#1a1a1a"
        self.light_text = "#ffffff"
        self.positive_green = "#00d4aa"
        self.negative_red = "#ff4444"
    
    def create_price_card(self, price: float, change_24h: float, 
                         timestamp: str = None) -> str:
        """Create a Bitcoin price card image"""
        
        timestamp = timestamp or datetime.now().strftime("%Y-%m-%d %H:%M UTC")
        
        # Create image
        img = Image.new('RGB', (1200, 630), color=self.dark_bg)
        draw = ImageDraw.Draw(img)
        
        try:
            # Load fonts
            title_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 80)
            label_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 40)
            small_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 30)
        except:
            title_font = ImageFont.load_default()
            label_font = ImageFont.load_default()
            small_font = ImageFont.load_default()
        
        # Draw Bitcoin logo background
        draw.rectangle([(0, 0), (1200, 630)], fill=self.dark_bg)
        
        # Draw header
        draw.rectangle([(0, 0), (1200, 150)], fill=self.bitcoin_orange)
        draw.text((50, 40), "BITCOIN MARKET UPDATE", font=title_font, fill=self.dark_bg)
        
        # Draw price
        price_text = f"${price:,.0f}"
        draw.text((50, 200), price_text, font=title_font, fill=self.bitcoin_orange)
        
        # Draw 24h change
        change_color = self.positive_green if change_24h >= 0 else self.negative_red
        change_text = f"{change_24h:+.2f}%"
        draw.text((50, 320), change_text, font=label_font, fill=change_color)
        
        # Draw timestamp
        draw.text((50, 450), f"Updated: {timestamp}", font=small_font, fill=self.light_text)
        
        # Draw branding
        draw.text((50, 550), "ARIES76 Bitcoin Report", font=label_font, fill=self.bitcoin_orange)
        
        # Save image
        filename = f"price_card_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        filepath = os.path.join(self.output_dir, filename)
        img.save(filepath)
        
        logger.info(f"Price card created: {filepath}")
        return filepath
    
    def create_market_metrics_card(self, context: Dict) -> str:
        """Create a card with market metrics"""
        
        # Create image
        img = Image.new('RGB', (1200, 630), color=self.dark_bg)
        draw = ImageDraw.Draw(img)
        
        try:
            title_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 60)
            metric_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 50)
            label_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 30)
        except:
            title_font = ImageFont.load_default()
            metric_font = ImageFont.load_default()
            label_font = ImageFont.load_default()
        
        # Draw background
        draw.rectangle([(0, 0), (1200, 630)], fill=self.dark_bg)
        
        # Draw header
        draw.rectangle([(0, 0), (1200, 100)], fill=self.bitcoin_orange)
        draw.text((50, 30), "MARKET METRICS", font=title_font, fill=self.dark_bg)
        
        # Draw metrics
        metrics = [
            ("BTC Dominance", f"{context.get('btc_dominance', 0):.1f}%", self.bitcoin_orange),
            ("Fear & Greed", f"{context.get('fear_greed_index', 0):.0f}/100", self.positive_green),
            ("24h Volume", f"${context.get('volume_24h', 0)/1e9:.1f}B", self.light_text)
        ]
        
        y_pos = 180
        for label, value, color in metrics:
            draw.text((50, y_pos), label, font=label_font, fill=self.light_text)
            draw.text((50, y_pos + 50), value, font=metric_font, fill=color)
            y_pos += 150
        
        # Save image
        filename = f"metrics_card_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        filepath = os.path.join(self.output_dir, filename)
        img.save(filepath)
        
        logger.info(f"Metrics card created: {filepath}")
        return filepath
    
    def create_analysis_card(self, title: str, insight: str) -> str:
        """Create an analysis/insight card"""
        
        # Create image
        img = Image.new('RGB', (1200, 630), color=self.dark_bg)
        draw = ImageDraw.Draw(img)
        
        try:
            title_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 50)
            text_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 35)
        except:
            title_font = ImageFont.load_default()
            text_font = ImageFont.load_default()
        
        # Draw background
        draw.rectangle([(0, 0), (1200, 630)], fill=self.dark_bg)
        
        # Draw accent bar
        draw.rectangle([(0, 0), (10, 630)], fill=self.bitcoin_orange)
        
        # Draw title
        draw.text((50, 50), title, font=title_font, fill=self.bitcoin_orange)
        
        # Draw insight text (with word wrapping)
        y_pos = 180
        max_width = 1100
        words = insight.split()
        line = ""
        
        for word in words:
            test_line = line + word + " "
            bbox = draw.textbbox((0, 0), test_line, font=text_font)
            if bbox[2] - bbox[0] > max_width:
                if line:
                    draw.text((50, y_pos), line, font=text_font, fill=self.light_text)
                    y_pos += 60
                line = word + " "
            else:
                line = test_line
        
        if line:
            draw.text((50, y_pos), line, font=text_font, fill=self.light_text)
        
        # Save image
        filename = f"analysis_card_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        filepath = os.path.join(self.output_dir, filename)
        img.save(filepath)
        
        logger.info(f"Analysis card created: {filepath}")
        return filepath


class SocialMediaImageGenerator:
    """Generate optimized images for different social media platforms"""
    
    def __init__(self):
        self.chart_gen = BitcoinChartGenerator()
    
    def generate_twitter_image(self, context: Dict, tweet_text: str) -> str:
        """Generate image optimized for Twitter (1200x675)"""
        
        # Use the price card as Twitter image
        return self.chart_gen.create_price_card(
            context['price'],
            context['price_change_24h']
        )
    
    def generate_instagram_image(self, context: Dict) -> str:
        """Generate image optimized for Instagram (1080x1080)"""
        
        return self.chart_gen.create_market_metrics_card(context)
    
    def generate_linkedin_image(self, context: Dict, insight: str) -> str:
        """Generate image optimized for LinkedIn (1200x627)"""
        
        return self.chart_gen.create_analysis_card(
            "Bitcoin Market Analysis",
            insight[:100] + "..." if len(insight) > 100 else insight
        )


def generate_content_images(context: Dict, content_files: Dict) -> Dict:
    """Generate all images for content"""
    
    logger.info("Generating social media images...")
    
    image_gen = SocialMediaImageGenerator()
    image_files = {}
    
    try:
        # Generate Twitter images
        twitter_image = image_gen.generate_twitter_image(context, "")
        image_files['twitter'] = twitter_image
        
        # Generate Instagram image
        instagram_image = image_gen.generate_instagram_image(context)
        image_files['instagram'] = instagram_image
        
        # Generate LinkedIn image
        linkedin_image = image_gen.generate_linkedin_image(context, "Bitcoin market analysis")
        image_files['linkedin'] = linkedin_image
        
        logger.info(f"Generated {len(image_files)} images")
        
    except Exception as e:
        logger.error(f"Error generating images: {e}")
    
    return image_files


if __name__ == "__main__":
    # Example usage
    context = {
        "price": 42500.00,
        "price_change_24h": 2.35,
        "btc_dominance": 52.5,
        "fear_greed_index": 65,
        "volume_24h": 25e9
    }
    
    image_files = generate_content_images(context, {})
    print(f"Generated images: {image_files}")
