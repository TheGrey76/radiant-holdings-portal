"""Backtesting engine for the portfolio management system."""

import pandas as pd
from backtesting import Backtest, Strategy
from backtesting.lib import crossover

class SimpleMomentumStrategy(Strategy):
    def init(self):
        self.sma50 = self.I(lambda x: pd.Series(x).rolling(50).mean(), self.data.Close)
        self.sma200 = self.I(lambda x: pd.Series(x).rolling(200).mean(), self.data.Close)

    def next(self):
        if crossover(self.sma50, self.sma200):
            self.buy()
        elif crossover(self.sma200, self.sma50):
            self.sell()

if __name__ == '__main__':
    # Example usage with dummy data
    data = {
        'Open': [50000 + i*100 - 50*i*i + 10*i*i*i for i in range(300)],
        'High': [50100 + i*100 - 50*i*i + 10*i*i*i for i in range(300)],
        'Low': [49900 + i*100 - 50*i*i + 10*i*i*i for i in range(300)],
        'Close': [50050 + i*100 - 50*i*i + 10*i*i*i for i in range(300)],
        'Volume': [100 for i in range(300)]
    }
    prices_df = pd.DataFrame(data, index=pd.to_datetime(pd.date_range('2023-01-01', periods=300)))

    bt = Backtest(prices_df, SimpleMomentumStrategy, cash=100000, commission=.002)
    stats = bt.run()
    print(stats)
    bt.plot()
