#!/usr/bin/env python3
"""
Data fetching module for advanced analysis.

This module will contain functions to fetch all the necessary data for the advanced analysis, including:
- Historical price and volume data for BTC and ETH.
- Historical price data for other assets for correlation analysis.
- Order book data for liquidity analysis.
"""

import sys
sys.path.append("/opt/.manus/.sandbox-runtime")
from data_api import ApiClient
import json
import requests

class AdvancedDataFetcher:
    def __init__(self):
        self.client = ApiClient()
        self.coinbase_api_url = "https://api.exchange.coinbase.com"

    def get_historical_data(self, symbol, interval="1d", range="3mo"):
        """Fetches historical data for a given symbol."""
        try:
            response = self.client.call_api("YahooFinance/get_stock_chart", query={
                "symbol": symbol,
                "interval": interval,
                "range": range,
            })
            return response
        except Exception as e:
            print(f"Error fetching historical data for {symbol}: {e}")
            return None

    def get_order_book(self, product_id, level=2):
        """Fetches order book data from Coinbase."""
        try:
            response = requests.get(f"{self.coinbase_api_url}/products/{product_id}/book", params={
                "level": level
            })
            response.raise_for_status()  # Raise an exception for bad status codes
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error fetching order book data for {product_id}: {e}")
            return None

if __name__ == "__main__":
    fetcher = AdvancedDataFetcher()

    # Example: Fetch data for BTC-USD
    btc_data = fetcher.get_historical_data("BTC-USD")
    if btc_data:
        print("Successfully fetched BTC-USD data.")

    # Example: Fetch data for ETH-USD
    eth_data = fetcher.get_historical_data("ETH-USD")
    if eth_data:
        print("Successfully fetched ETH-USD data.")

    # Example: Fetch data for correlation assets
    spy_data = fetcher.get_historical_data("SPY")
    if spy_data:
        print("Successfully fetched SPY data.")

    gld_data = fetcher.get_historical_data("GLD")
    if gld_data:
        print("Successfully fetched GLD data.")

    # Example: Fetch order book for BTC-USD from Coinbase
    order_book = fetcher.get_order_book("BTC-USD")
    if order_book:
        print("Successfully fetched BTC-USD order book from Coinbase.")
