"""
LinkedIn Scheduler Automation
Uses Playwright to automate LinkedIn post scheduling
"""

import os
import json
import logging
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict
from dotenv import load_dotenv

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/ubuntu/bitcoin_automation/logs/linkedin_scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

load_dotenv('/home/ubuntu/bitcoin_automation/.env')


class LinkedInSchedulerAutomation:
    """Automate LinkedIn post scheduling using Playwright"""
    
    def __init__(self):
        self.email = os.getenv('LINKEDIN_EMAIL')
        self.password = os.getenv('LINKEDIN_PASSWORD')
        self.browser = None
        self.page = None
        
    async def init_browser(self):
        """Initialize Playwright browser"""
        try:
            from playwright.async_api import async_playwright
            
            playwright = await async_playwright().start()
            self.browser = await playwright.chromium.launch(headless=True)
            self.page = await self.browser.new_page()
            
            logger.info("✓ Browser initialized")
            return True
            
        except Exception as e:
            logger.error(f"Error initializing browser: {e}")
            return False
    
    async def login(self) -> bool:
        """Login to LinkedIn"""
        try:
            logger.info("Logging in to LinkedIn...")
            
            await self.page.goto('https://www.linkedin.com/login')
            await self.page.wait_for_load_state('networkidle')
            
            # Fill email
            await self.page.fill('#username', self.email)
            await self.page.fill('#password', self.password)
            
            # Click login
            await self.page.click('button[aria-label="Sign in"]')
            await self.page.wait_for_load_state('networkidle')
            
            logger.info("✓ Successfully logged in")
            return True
            
        except Exception as e:
            logger.error(f"Login failed: {e}")
            return False
    
    async def schedule_post(self, content: str, schedule_time: datetime = None) -> bool:
        """Schedule a post on LinkedIn"""
        try:
            if not schedule_time:
                # Default: schedule for tomorrow at 8:30 AM
                schedule_time = datetime.now() + timedelta(days=1)
                schedule_time = schedule_time.replace(hour=8, minute=30, second=0)
            
            logger.info(f"Scheduling post for {schedule_time}...")
            
            # Navigate to home
            await self.page.goto('https://www.linkedin.com/feed/')
            await self.page.wait_for_load_state('networkidle')
            
            # Click on post composer
            try:
                await self.page.click('button:has-text("Start a post")')
            except:
                await self.page.click('div[role="button"]:has-text("Start a post")')
            
            await self.page.wait_for_timeout(1000)
            
            # Find and fill text area
            text_areas = await self.page.query_selector_all('div[role="textbox"]')
            if text_areas:
                await text_areas[0].click()
                await self.page.keyboard.type(content)
            
            await self.page.wait_for_timeout(1000)
            
            # Look for schedule button
            try:
                # Try to find schedule option
                schedule_button = await self.page.query_selector('button:has-text("Schedule")')
                if schedule_button:
                    await schedule_button.click()
                    await self.page.wait_for_timeout(1000)
                    
                    # Set date and time
                    date_input = await self.page.query_selector('input[type="date"]')
                    if date_input:
                        await date_input.fill(schedule_time.strftime('%Y-%m-%d'))
                    
                    time_input = await self.page.query_selector('input[type="time"]')
                    if time_input:
                        await time_input.fill(schedule_time.strftime('%H:%M'))
                    
                    # Click confirm
                    confirm_button = await self.page.query_selector('button:has-text("Schedule")')
                    if confirm_button:
                        await confirm_button.click()
                        await self.page.wait_for_timeout(2000)
                        
                        logger.info(f"✓ Post scheduled for {schedule_time}")
                        return True
            except:
                pass
            
            # Fallback: Just publish immediately
            publish_button = await self.page.query_selector('button:has-text("Post")')
            if publish_button:
                await publish_button.click()
                await self.page.wait_for_timeout(2000)
                logger.info("✓ Post published immediately")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error scheduling post: {e}")
            return False
    
    async def schedule_multiple_posts(self, posts: List[str]) -> Dict[int, bool]:
        """Schedule multiple posts"""
        results = {}
        
        for i, post in enumerate(posts):
            # Schedule posts at different times
            schedule_time = datetime.now() + timedelta(days=1)
            schedule_time = schedule_time.replace(hour=8 + (i * 4), minute=30, second=0)
            
            logger.info(f"Scheduling post {i+1}/{len(posts)}")
            result = await self.schedule_post(post, schedule_time)
            results[i] = result
            
            if i < len(posts) - 1:
                await self.page.wait_for_timeout(5000)
        
        return results
    
    async def close(self):
        """Close the browser"""
        if self.page:
            await self.page.close()
        if self.browser:
            await self.browser.close()
        logger.info("Browser closed")


async def schedule_posts_from_file(json_file: str) -> bool:
    """Load posts from JSON file and schedule them"""
    
    try:
        with open(json_file, 'r') as f:
            data = json.load(f)
        
        posts_data = data.get('posts', [])
        posts = []
        
        for post in posts_data:
            if isinstance(post, dict):
                posts.append(post.get('text', post))
            else:
                posts.append(str(post))
        
        if not posts:
            logger.error("No posts found in file")
            return False
        
        automation = LinkedInSchedulerAutomation()
        
        if not await automation.init_browser():
            return False
        
        if not await automation.login():
            await automation.close()
            return False
        
        results = await automation.schedule_multiple_posts(posts)
        await automation.close()
        
        logger.info(f"Scheduling complete. Results: {results}")
        return all(results.values())
        
    except Exception as e:
        logger.error(f"Error in schedule_posts_from_file: {e}")
        return False


async def main():
    """Main entry point"""
    
    # Find the latest posts file
    posts_dir = '/home/ubuntu/bitcoin_automation/generated_content'
    
    try:
        latest_file = max(
            [f for f in os.listdir(posts_dir) if f.startswith('linkedin_posts')],
            key=lambda f: os.path.getctime(os.path.join(posts_dir, f))
        )
        
        json_file = os.path.join(posts_dir, latest_file)
        await schedule_posts_from_file(json_file)
        
    except Exception as e:
        logger.error(f"Error: {e}")


if __name__ == '__main__':
    asyncio.run(main())
