#!/usr/bin/env python3
"""
ARIES76 Bitcoin Data Fetcher
Fetches real-time Bitcoin data from CoinGecko and NewsAPI
"""

import requests
import logging
import time
from datetime import datetime
from pathlib import Path

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'bitcoin_data_fetcher.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class BitcoinDataFetcher:
    """Fetch real-time Bitcoin data from APIs"""
    
    def __init__(self, newsapi_key=None):
        """Initialize data fetcher"""
        self.coingecko_url = "https://api.coingecko.com/api/v3"
        self.newsapi_key = newsapi_key or "719499ece05e416b962d74fe012371e0"
        self.newsapi_url = "https://newsapi.org/v2"
        
        # Caching
        self.cache = {}
        self.cache_ttl = 60
        self.last_request = {}
        
        logger.info("Bitcoin Data Fetcher initialized")
    
    def get_bitcoin_price(self):
        """Get current Bitcoin price and market data"""
        try:
            # Check cache
            if 'price' in self.cache and time.time() - self.cache['price'][1] < self.cache_ttl:
                logger.info("Using cached Bitcoin price")
                return self.cache['price'][0]
            
            logger.info("Fetching Bitcoin price from CoinGecko...")
            time.sleep(1)  # Rate limiting
            
            url = f"{self.coingecko_url}/simple/price"
            params = {
                'ids': 'bitcoin',
                'vs_currencies': 'usd',
                'include_market_cap': 'true',
                'include_24hr_vol': 'true',
                'include_24hr_change': 'true'
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            bitcoin = data.get('bitcoin', {})
            
            result = {
                'price': bitcoin.get('usd', 0),
                'market_cap': bitcoin.get('usd_market_cap', 0),
                'volume_24h': bitcoin.get('usd_24h_vol', 0),
                'change_24h': bitcoin.get('usd_24h_change', 0),
                'timestamp': datetime.now().isoformat()
            }
            
            self.cache['price'] = (result, time.time())
            logger.info(f"✓ Bitcoin price fetched: ${result['price']:.2f}")
            return result
        except Exception as e:
            logger.error(f"Error fetching Bitcoin price: {e}")
            return None
    
    def get_bitcoin_news(self, limit=5):
        """Get latest Bitcoin news"""
        try:
            logger.info(f"Fetching Bitcoin news from NewsAPI...")
            time.sleep(1)  # Rate limiting
            
            url = f"{self.newsapi_url}/everything"
            params = {
                'q': 'bitcoin',
                'sortBy': 'publishedAt',
                'language': 'en',
                'pageSize': limit,
                'apiKey': self.newsapi_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if data.get('status') != 'ok':
                logger.error(f"NewsAPI error: {data.get('message', 'Unknown error')}")
                return []
            
            articles = data.get('articles', [])
            
            news = []
            for article in articles[:limit]:
                news.append({
                    'title': article.get('title', ''),
                    'description': article.get('description', ''),
                    'url': article.get('url', ''),
                    'source': article.get('source', {}).get('name', ''),
                    'published_at': article.get('publishedAt', '')
                })
            
            logger.info(f"✓ Fetched {len(news)} Bitcoin news articles")
            return news
        except Exception as e:
            logger.error(f"Error fetching Bitcoin news: {e}")
            return []
    
    def get_market_sentiment(self):
        """Get market sentiment indicators"""
        try:
            logger.info("Calculating market sentiment...")
            
            price_data = self.get_bitcoin_price()
            if not price_data:
                return None
            
            change_24h = price_data.get('change_24h', 0)
            
            if change_24h > 5:
                sentiment = "VERY BULLISH"
                emoji = "🟢🟢"
            elif change_24h > 2:
                sentiment = "BULLISH"
                emoji = "🟢"
            elif change_24h > -2:
                sentiment = "NEUTRAL"
                emoji = "🟡"
            elif change_24h > -5:
                sentiment = "BEARISH"
                emoji = "🔴"
            else:
                sentiment = "VERY BEARISH"
                emoji = "🔴🔴"
            
            result = {
                'sentiment': sentiment,
                'emoji': emoji,
                'change_24h': change_24h,
                'timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"✓ Market sentiment: {sentiment}")
            return result
        except Exception as e:
            logger.error(f"Error calculating sentiment: {e}")
            return None
    
    def get_resistance_support(self):
        """Calculate resistance and support levels"""
        try:
            logger.info("Calculating resistance and support levels...")
            
            price_data = self.get_bitcoin_price()
            if not price_data:
                return None
            
            current = price_data.get('price', 0)
            
            # Simple calculation based on current price
            resistance = current * 1.02
            support = current * 0.98
            
            result = {
                'current': current,
                'resistance': resistance,
                'support': support,
                'timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"✓ Resistance: ${resistance:.2f}, Support: ${support:.2f}")
            return result
        except Exception as e:
            logger.error(f"Error calculating levels: {e}")
            return None
    
    def get_complete_analysis(self):
        """Get complete Bitcoin analysis"""
        try:
            logger.info("Generating complete Bitcoin analysis...")
            
            analysis = {
                'timestamp': datetime.now().isoformat(),
                'price': self.get_bitcoin_price(),
                'sentiment': self.get_market_sentiment(),
                'levels': self.get_resistance_support(),
                'news': self.get_bitcoin_news(3)
            }
            
            logger.info("✓ Complete analysis generated")
            return analysis
        except Exception as e:
            logger.error(f"Error generating analysis: {e}")
            return None

def main():
    """Main function for testing"""
    fetcher = BitcoinDataFetcher()
    
    print("\n" + "=" * 70)
    print("BITCOIN DATA FETCHER - TEST")
    print("=" * 70)
    
    # Get price
    print("\n📊 BITCOIN PRICE:")
    price = fetcher.get_bitcoin_price()
    if price:
        print(f"  Price: ${price['price']:.2f}")
        print(f"  Change 24h: {price['change_24h']:.2f}%")
        print(f"  Market Cap: ${price['market_cap']:,.0f}")
    
    # Get sentiment
    print("\n💭 MARKET SENTIMENT:")
    sentiment = fetcher.get_market_sentiment()
    if sentiment:
        print(f"  Sentiment: {sentiment['emoji']} {sentiment['sentiment']}")
    
    # Get levels
    print("\n🎯 RESISTANCE & SUPPORT:")
    levels = fetcher.get_resistance_support()
    if levels:
        print(f"  Resistance: ${levels['resistance']:.2f}")
        print(f"  Support: ${levels['support']:.2f}")
    
    # Get news
    print("\n📰 LATEST NEWS:")
    news = fetcher.get_bitcoin_news(3)
    for i, article in enumerate(news, 1):
        print(f"  {i}. {article['title'][:60]}...")
    
    print("\n" + "=" * 70 + "\n")

if __name__ == '__main__':
    main()
