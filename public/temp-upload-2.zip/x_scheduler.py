#!/usr/bin/env python3
"""
X (Twitter) Scheduler
Automated Bitcoin and Digital Assets content publishing to X
Schedule: 6:00 AM + 12:00 PM + 6:30 PM CET
"""

import asyncio
import logging
import time
import os
from datetime import datetime
from pathlib import Path
from x_content_formatter import XContentFormatter
from x_twitter_publisher import XTwitterPublisher

# Set timezone to Europe/Rome (CET/CEST)
os.environ['TZ'] = 'Europe/Rome'
time.tzset()

logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'x_scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class XScheduler:
    """X (Twitter) Scheduler"""
    
    def __init__(self):
        self.formatter = XContentFormatter()
        self.publisher = XTwitterPublisher()
        self.last_morning = None
        self.last_noon = None
        self.last_evening = None
        logger.info("X Scheduler initialized")
        logger.info("Timezone: Europe/Rome (CET/CEST)")
        logger.info("Schedule: 6:00 AM + 12:00 PM + 6:30 PM")
        
        if not self.publisher.client:
            logger.warning("X credentials not configured. Please set environment variables:")
            logger.warning("  - X_API_KEY")
            logger.warning("  - X_API_SECRET")
            logger.warning("  - X_ACCESS_TOKEN")
            logger.warning("  - X_ACCESS_TOKEN_SECRET")
            logger.warning("  - X_BEARER_TOKEN")
    
    def run_morning(self):
        """Run morning Bitcoin analysis"""
        try:
            logger.info("=" * 70)
            logger.info("📤 MORNING ANALYSIS - GENERATING & PUBLISHING TO X")
            logger.info("=" * 70)
            
            tweet = self.formatter.format_bitcoin_morning_tweet()
            
            if not tweet:
                logger.error("Failed to generate morning tweet")
                return False
            
            if self.publisher.client:
                result = self.publisher.publish_tweet(tweet)
                if result:
                    logger.info("✅ Morning tweet published successfully")
                    self.last_morning = datetime.now()
                return result
            else:
                logger.warning("X client not initialized. Skipping publication.")
                logger.info(f"Tweet would be: {tweet}")
                return False
        
        except Exception as e:
            logger.error(f"Error in morning analysis: {e}")
            return False
    
    def run_noon(self):
        """Run noon digital assets news"""
        try:
            logger.info("=" * 70)
            logger.info("📤 NOON NEWS UPDATE - GENERATING & PUBLISHING TO X")
            logger.info("=" * 70)
            
            tweet = self.formatter.format_digital_assets_news_tweet()
            
            if not tweet:
                logger.error("Failed to generate noon tweet")
                return False
            
            if self.publisher.client:
                result = self.publisher.publish_tweet(tweet)
                if result:
                    logger.info("✅ Noon tweet published successfully")
                    self.last_noon = datetime.now()
                return result
            else:
                logger.warning("X client not initialized. Skipping publication.")
                logger.info(f"Tweet would be: {tweet}")
                return False
        
        except Exception as e:
            logger.error(f"Error in noon news: {e}")
            return False
    
    def run_evening(self):
        """Run evening Bitcoin analysis"""
        try:
            logger.info("=" * 70)
            logger.info("📤 EVENING ANALYSIS - GENERATING & PUBLISHING TO X")
            logger.info("=" * 70)
            
            tweet = self.formatter.format_bitcoin_evening_tweet()
            
            if not tweet:
                logger.error("Failed to generate evening tweet")
                return False
            
            if self.publisher.client:
                result = self.publisher.publish_tweet(tweet)
                if result:
                    logger.info("✅ Evening tweet published successfully")
                    self.last_evening = datetime.now()
                return result
            else:
                logger.warning("X client not initialized. Skipping publication.")
                logger.info(f"Tweet would be: {tweet}")
                return False
        
        except Exception as e:
            logger.error(f"Error in evening analysis: {e}")
            return False
    
    def should_run_morning(self):
        """Check if morning task should run (6:00 AM)"""
        now = datetime.now()
        
        # Run at 6:00 AM (hour=6, minute=0-4)
        if now.hour == 6 and now.minute < 5:
            if self.last_morning is None or (now - self.last_morning).total_seconds() > 3600:
                return True
        
        return False
    
    def should_run_noon(self):
        """Check if noon task should run (12:00 PM)"""
        now = datetime.now()
        
        # Run at 12:00 PM (hour=12, minute=0-4)
        if now.hour == 12 and now.minute < 5:
            if self.last_noon is None or (now - self.last_noon).total_seconds() > 3600:
                return True
        
        return False
    
    def should_run_evening(self):
        """Check if evening task should run (6:30 PM)"""
        now = datetime.now()
        
        # Run at 6:30 PM (hour=18, minute=30-34)
        if now.hour == 18 and 30 <= now.minute < 35:
            if self.last_evening is None or (now - self.last_evening).total_seconds() > 3600:
                return True
        
        return False
    
    def run(self):
        """Main scheduler loop"""
        logger.info("=" * 70)
        logger.info("ARIES76 X (TWITTER) SCHEDULER - STARTED")
        logger.info("=" * 70)
        logger.info("Press Ctrl+C to stop")
        logger.info("")
        logger.info("Timezone: Europe/Rome (CET/CEST)")
        logger.info("Schedule:")
        logger.info("  - 6:00 AM: Morning Bitcoin analysis tweet")
        logger.info("  - 12:00 PM: Digital Assets news update tweet")
        logger.info("  - 6:30 PM: Evening Bitcoin analysis tweet")
        logger.info("")
        logger.info("=" * 70)
        
        check_count = 0
        
        try:
            while True:
                now = datetime.now()
                check_count += 1
                
                # Log every 20 checks (every 10 minutes)
                if check_count % 20 == 0:
                    logger.info(f"[CHECK #{check_count}] Current time: {now.strftime('%Y-%m-%d %H:%M:%S')}")
                
                # Check morning task
                if self.should_run_morning():
                    logger.info(f"🌅 MORNING WINDOW DETECTED at {now.strftime('%Y-%m-%d %H:%M:%S')}")
                    self.run_morning()
                    time.sleep(60)  # Wait 1 minute to avoid duplicate runs
                
                # Check noon task
                if self.should_run_noon():
                    logger.info(f"☀️ NOON WINDOW DETECTED at {now.strftime('%Y-%m-%d %H:%M:%S')}")
                    self.run_noon()
                    time.sleep(60)  # Wait 1 minute to avoid duplicate runs
                
                # Check evening task
                if self.should_run_evening():
                    logger.info(f"🌆 EVENING WINDOW DETECTED at {now.strftime('%Y-%m-%d %H:%M:%S')}")
                    self.run_evening()
                    time.sleep(60)  # Wait 1 minute to avoid duplicate runs
                
                time.sleep(30)
        except KeyboardInterrupt:
            logger.info("Scheduler stopped by user")
        except Exception as e:
            logger.error(f"Fatal error: {e}")
            import traceback
            logger.error(traceback.format_exc())

def main():
    """Main entry point"""
    scheduler = XScheduler()
    scheduler.run()

if __name__ == '__main__':
    main()
