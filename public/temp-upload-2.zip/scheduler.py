#!/usr/bin/env python3
"""
Scheduler for Bitcoin Content Automation
Configures and manages daily content generation and publishing
"""

import os
import sys
import logging
from datetime import datetime, time
import schedule
import time as time_module

# Add project to path
sys.path.insert(0, '/home/ubuntu/bitcoin_automation')

from automation_orchestrator import AutomationOrchestrator

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/ubuntu/bitcoin_automation/logs/scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class ContentScheduler:
    """Manage scheduled content generation and publishing"""
    
    def __init__(self, schedule_time: str = "06:00"):
        """
        Initialize scheduler
        
        Args:
            schedule_time: Time in HH:MM format (24-hour) for daily execution
        """
        self.schedule_time = schedule_time
        self.orchestrator = AutomationOrchestrator()
        self.is_running = False
        
    def schedule_daily_content(self) -> None:
        """Schedule daily content generation and publishing"""
        
        logger.info(f"Scheduling daily automation at {self.schedule_time} CET")
        
        # Schedule the job
        schedule.every().day.at(self.schedule_time).do(self.run_automation)
        
        logger.info("Daily automation scheduled successfully")
    
    def run_automation(self) -> None:
        """Execute the automation workflow"""
        
        logger.info(f"Running scheduled automation at {datetime.now()}")
        
        try:
            result = self.orchestrator.run_daily_automation()
            
            if result["overall_status"] == "success":
                logger.info("Automation completed successfully")
            else:
                logger.error(f"Automation failed: {result.get('error', 'Unknown error')}")
                
        except Exception as e:
            logger.error(f"Error running automation: {e}", exc_info=True)
    
    def start(self) -> None:
        """Start the scheduler"""
        
        logger.info("=" * 70)
        logger.info("STARTING BITCOIN CONTENT SCHEDULER")
        logger.info("=" * 70)
        
        self.schedule_daily_content()
        self.is_running = True
        
        logger.info("Scheduler started. Waiting for scheduled time...")
        
        # Keep scheduler running
        while self.is_running:
            try:
                schedule.run_pending()
                time_module.sleep(60)  # Check every minute
            except KeyboardInterrupt:
                logger.info("Scheduler interrupted by user")
                self.stop()
            except Exception as e:
                logger.error(f"Error in scheduler loop: {e}", exc_info=True)
                time_module.sleep(60)
    
    def stop(self) -> None:
        """Stop the scheduler"""
        
        logger.info("Stopping scheduler...")
        self.is_running = False
        schedule.clear()
        logger.info("Scheduler stopped")


def setup_cron_job() -> str:
    """
    Create a cron job for daily automation
    Returns the cron job setup instructions
    """
    
    cron_schedule = "0 6 * * *"  # 6:00 AM every day
    python_script = "/home/ubuntu/bitcoin_automation/run_automation.py"
    
    cron_entry = f"{cron_schedule} /usr/bin/python3 {python_script} >> /home/ubuntu/bitcoin_automation/logs/cron.log 2>&1"
    
    instructions = f"""
    To set up automatic daily execution, add this line to your crontab:
    
    {cron_entry}
    
    To add it, run:
    crontab -e
    
    And paste the line above.
    
    This will run the automation every day at 6:00 AM CET.
    
    To verify the cron job is installed:
    crontab -l
    
    To remove the cron job:
    crontab -r
    """
    
    return instructions


def create_systemd_service() -> str:
    """
    Create a systemd service for the scheduler
    Returns the service file content
    """
    
    service_content = """[Unit]
Description=Bitcoin Content Automation Scheduler
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/bitcoin_automation
ExecStart=/usr/bin/python3 /home/ubuntu/bitcoin_automation/scheduler.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""
    
    instructions = f"""
    To set up the scheduler as a systemd service:
    
    1. Create the service file:
    sudo tee /etc/systemd/system/bitcoin-automation.service > /dev/null << 'EOF'
{service_content}EOF
    
    2. Reload systemd:
    sudo systemctl daemon-reload
    
    3. Enable the service:
    sudo systemctl enable bitcoin-automation.service
    
    4. Start the service:
    sudo systemctl start bitcoin-automation.service
    
    5. Check status:
    sudo systemctl status bitcoin-automation.service
    
    6. View logs:
    sudo journalctl -u bitcoin-automation.service -f
    """
    
    return instructions


def main():
    """Main entry point for scheduler"""
    
    # Get schedule time from environment or use default
    schedule_time = os.getenv("AUTOMATION_SCHEDULE_TIME", "06:00")
    
    # Create and start scheduler
    scheduler = ContentScheduler(schedule_time)
    scheduler.start()


if __name__ == "__main__":
    main()
