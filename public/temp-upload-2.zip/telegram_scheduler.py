#!/usr/bin/env python3
"""
ARIES76 Telegram Scheduler
Schedules daily Bitcoin analysis publication to Telegram
"""

import schedule
import time
import logging
import asyncio
from datetime import datetime
from pathlib import Path

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

from telegram_bot import ARIES76TelegramBot

class TelegramScheduler:
    """Scheduler for Telegram automation"""
    
    def __init__(self):
        """Initialize scheduler"""
        self.bot = ARIES76TelegramBot()
        logger.info("Telegram Scheduler initialized")
    
    def job_publish_analysis(self):
        """Job: Publish daily analysis"""
        try:
            logger.info("Running job: publish_analysis")
            asyncio.run(self.bot.publish_daily_analysis())
        except Exception as e:
            logger.error(f"Error in publish_analysis job: {e}")
    
    def schedule_jobs(self):
        """Schedule all jobs"""
        # Publish daily analysis at 6:00 AM CET (5:00 AM UTC in winter)
        schedule.every().day.at("06:00").do(self.job_publish_analysis)
        
        logger.info("Jobs scheduled:")
        logger.info("  - Daily analysis at 06:00 CET")
    
    def run(self):
        """Run the scheduler"""
        self.schedule_jobs()
        
        logger.info("Telegram Scheduler started")
        logger.info("Press Ctrl+C to stop")
        
        try:
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
        except KeyboardInterrupt:
            logger.info("Scheduler stopped")

if __name__ == '__main__':
    scheduler = TelegramScheduler()
    scheduler.run()
