#!/usr/bin/env python3
"""
X (Twitter) Publisher
Automated content publishing to X (Twitter)
"""

import logging
from pathlib import Path
import tweepy
import os

logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'x_twitter_publisher.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class XTwitterPublisher:
    """Publisher for X (Twitter)"""
    
    def __init__(self, api_key=None, api_secret=None, access_token=None, access_token_secret=None, bearer_token=None):
        """
        Initialize X Publisher
        
        Args:
            api_key: X API Key
            api_secret: X API Secret Key
            access_token: X Access Token
            access_token_secret: X Access Token Secret
            bearer_token: X Bearer Token
        """
        self.api_key = api_key or os.getenv('X_API_KEY')
        self.api_secret = api_secret or os.getenv('X_API_SECRET')
        self.access_token = access_token or os.getenv('X_ACCESS_TOKEN')
        self.access_token_secret = access_token_secret or os.getenv('X_ACCESS_TOKEN_SECRET')
        self.bearer_token = bearer_token or os.getenv('X_BEARER_TOKEN')
        
        self.client = None
        self.auth = None
        
        logger.info("X Twitter Publisher initialized")
        
        if self.api_key and self.api_secret and self.access_token and self.access_token_secret:
            self._initialize_client()
        else:
            logger.warning("X credentials not provided. Please set environment variables or pass credentials.")
    
    def _initialize_client(self):
        """Initialize Tweepy client"""
        try:
            # Initialize with OAuth 1.0a (for v1.1 API)
            self.auth = tweepy.OAuthHandler(self.api_key, self.api_secret)
            self.auth.set_access_token(self.access_token, self.access_token_secret)
            
            # Initialize with v2 API (for newer endpoints)
            self.client = tweepy.Client(
                consumer_key=self.api_key,
                consumer_secret=self.api_secret,
                access_token=self.access_token,
                access_token_secret=self.access_token_secret,
                bearer_token=self.bearer_token
            )
            
            logger.info("✓ X Twitter client initialized successfully")
            return True
        except Exception as e:
            logger.error(f"Error initializing X client: {e}")
            return False
    
    def publish_tweet(self, text):
        """
        Publish a tweet
        
        Args:
            text: Tweet text (max 280 characters)
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.client:
            logger.error("X client not initialized. Please provide credentials.")
            return False
        
        try:
            # Truncate if too long
            if len(text) > 280:
                text = text[:277] + "..."
            
            logger.info(f"Publishing tweet: {text[:50]}...")
            
            response = self.client.create_tweet(text=text)
            
            if response and response.data:
                tweet_id = response.data.get('id')
                logger.info(f"✓ Tweet published successfully (ID: {tweet_id})")
                return True
            else:
                logger.error("Failed to publish tweet")
                return False
        
        except Exception as e:
            logger.error(f"Error publishing tweet: {e}")
            return False
    
    def publish_tweet_with_media(self, text, media_paths):
        """
        Publish a tweet with media
        
        Args:
            text: Tweet text
            media_paths: List of media file paths
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.client:
            logger.error("X client not initialized. Please provide credentials.")
            return False
        
        try:
            # Truncate text if too long
            if len(text) > 280:
                text = text[:277] + "..."
            
            logger.info(f"Publishing tweet with media: {text[:50]}...")
            
            # Upload media
            media_ids = []
            for media_path in media_paths:
                try:
                    media = self.client.upload_media(filename=media_path)
                    media_ids.append(media.data['media_id'])
                except Exception as e:
                    logger.error(f"Error uploading media {media_path}: {e}")
            
            # Publish tweet
            if media_ids:
                response = self.client.create_tweet(text=text, media_ids=media_ids)
            else:
                response = self.client.create_tweet(text=text)
            
            if response and response.data:
                tweet_id = response.data.get('id')
                logger.info(f"✓ Tweet with media published successfully (ID: {tweet_id})")
                return True
            else:
                logger.error("Failed to publish tweet with media")
                return False
        
        except Exception as e:
            logger.error(f"Error publishing tweet with media: {e}")
            return False
    
    def publish_thread(self, tweets):
        """
        Publish a thread of tweets
        
        Args:
            tweets: List of tweet texts
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.client:
            logger.error("X client not initialized. Please provide credentials.")
            return False
        
        try:
            logger.info(f"Publishing thread with {len(tweets)} tweets...")
            
            reply_to_id = None
            
            for i, tweet_text in enumerate(tweets):
                # Truncate if too long
                if len(tweet_text) > 280:
                    tweet_text = tweet_text[:277] + "..."
                
                try:
                    if reply_to_id:
                        response = self.client.create_tweet(text=tweet_text, reply_settings="everyone", in_reply_to_tweet_id=reply_to_id)
                    else:
                        response = self.client.create_tweet(text=tweet_text)
                    
                    if response and response.data:
                        reply_to_id = response.data.get('id')
                        logger.info(f"✓ Tweet {i+1}/{len(tweets)} published")
                    else:
                        logger.error(f"Failed to publish tweet {i+1}/{len(tweets)}")
                        return False
                
                except Exception as e:
                    logger.error(f"Error publishing tweet {i+1}: {e}")
                    return False
            
            logger.info(f"✓ Thread published successfully ({len(tweets)} tweets)")
            return True
        
        except Exception as e:
            logger.error(f"Error publishing thread: {e}")
            return False
    
    def get_account_info(self):
        """Get account information"""
        if not self.client:
            logger.error("X client not initialized. Please provide credentials.")
            return None
        
        try:
            me = self.client.get_me()
            logger.info(f"Account: {me.data}")
            return me.data
        except Exception as e:
            logger.error(f"Error getting account info: {e}")
            return None

def main():
    """Test the publisher"""
    # Initialize with environment variables or credentials
    publisher = XTwitterPublisher()
    
    # Test tweet
    test_tweet = "🚀 Testing X Publisher - Automated Bitcoin Analysis System #Bitcoin #Crypto"
    
    if publisher.client:
        publisher.publish_tweet(test_tweet)
    else:
        print("X credentials not configured. Please set environment variables:")
        print("  - X_API_KEY")
        print("  - X_API_SECRET")
        print("  - X_ACCESS_TOKEN")
        print("  - X_ACCESS_TOKEN_SECRET")
        print("  - X_BEARER_TOKEN")

if __name__ == '__main__':
    main()
