#!/usr/bin/env python3
"""
ARIES76 User Engagement & Analytics
Tracks user engagement and provides analytics
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'engagement.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class UserEngagement:
    """Track and analyze user engagement"""
    
    def __init__(self):
        """Initialize engagement tracker"""
        self.data_dir = Path('/home/ubuntu/telegram_automation/data')
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.events_file = self.data_dir / 'events.json'
        self.engagement_file = self.data_dir / 'engagement.json'
        
        # Load existing data
        self.events = self._load_events()
        self.engagement = self._load_engagement()
        
        logger.info("User Engagement tracker initialized")
    
    def _load_events(self):
        """Load events from file"""
        try:
            if self.events_file.exists():
                with open(self.events_file, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            logger.error(f"Error loading events: {e}")
            return []
    
    def _load_engagement(self):
        """Load engagement data from file"""
        try:
            if self.engagement_file.exists():
                with open(self.engagement_file, 'r') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            logger.error(f"Error loading engagement: {e}")
            return {}
    
    def _save_events(self):
        """Save events to file"""
        try:
            with open(self.events_file, 'w') as f:
                json.dump(self.events, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving events: {e}")
    
    def _save_engagement(self):
        """Save engagement data to file"""
        try:
            with open(self.engagement_file, 'w') as f:
                json.dump(self.engagement, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving engagement: {e}")
    
    def track_event(self, user_id, event_type, event_data=None):
        """Track a user event"""
        try:
            event = {
                'user_id': user_id,
                'event_type': event_type,
                'timestamp': datetime.now().isoformat(),
                'data': event_data or {}
            }
            
            self.events.append(event)
            self._save_events()
            
            logger.info(f"Event tracked: {event_type} for user {user_id}")
            return True
        except Exception as e:
            logger.error(f"Error tracking event: {e}")
            return False
    
    def track_message_view(self, user_id, message_id):
        """Track message view"""
        return self.track_event(user_id, 'message_view', {'message_id': message_id})
    
    def track_click(self, user_id, link):
        """Track link click"""
        return self.track_event(user_id, 'link_click', {'link': link})
    
    def track_subscription(self, user_id, tier):
        """Track subscription"""
        return self.track_event(user_id, 'subscription', {'tier': tier})
    
    def track_unsubscribe(self, user_id):
        """Track unsubscribe"""
        return self.track_event(user_id, 'unsubscribe', {})
    
    def get_user_engagement(self, user_id):
        """Get engagement metrics for a user"""
        try:
            user_events = [e for e in self.events if e['user_id'] == user_id]
            
            engagement = {
                'user_id': user_id,
                'total_events': len(user_events),
                'message_views': len([e for e in user_events if e['event_type'] == 'message_view']),
                'clicks': len([e for e in user_events if e['event_type'] == 'link_click']),
                'first_event': user_events[0]['timestamp'] if user_events else None,
                'last_event': user_events[-1]['timestamp'] if user_events else None
            }
            
            return engagement
        except Exception as e:
            logger.error(f"Error getting user engagement: {e}")
            return {}
    
    def get_engagement_rate(self, user_id):
        """Calculate engagement rate for a user"""
        try:
            engagement = self.get_user_engagement(user_id)
            
            total_events = engagement.get('total_events', 0)
            clicks = engagement.get('clicks', 0)
            
            if total_events == 0:
                return 0
            
            rate = (clicks / total_events) * 100
            return rate
        except Exception as e:
            logger.error(f"Error calculating engagement rate: {e}")
            return 0
    
    def get_top_users(self, limit=10):
        """Get top engaged users"""
        try:
            user_engagement = {}
            
            for event in self.events:
                user_id = event['user_id']
                if user_id not in user_engagement:
                    user_engagement[user_id] = 0
                user_engagement[user_id] += 1
            
            # Sort by engagement
            top_users = sorted(
                user_engagement.items(),
                key=lambda x: x[1],
                reverse=True
            )[:limit]
            
            return top_users
        except Exception as e:
            logger.error(f"Error getting top users: {e}")
            return []
    
    def get_daily_stats(self, days=7):
        """Get daily engagement statistics"""
        try:
            stats = defaultdict(lambda: {
                'events': 0,
                'unique_users': set(),
                'clicks': 0,
                'views': 0
            })
            
            cutoff_date = datetime.now() - timedelta(days=days)
            
            for event in self.events:
                event_date = datetime.fromisoformat(event['timestamp'])
                
                if event_date < cutoff_date:
                    continue
                
                date_key = event_date.strftime('%Y-%m-%d')
                
                stats[date_key]['events'] += 1
                stats[date_key]['unique_users'].add(event['user_id'])
                
                if event['event_type'] == 'link_click':
                    stats[date_key]['clicks'] += 1
                elif event['event_type'] == 'message_view':
                    stats[date_key]['views'] += 1
            
            # Convert sets to counts
            result = {}
            for date, data in stats.items():
                result[date] = {
                    'events': data['events'],
                    'unique_users': len(data['unique_users']),
                    'clicks': data['clicks'],
                    'views': data['views']
                }
            
            return result
        except Exception as e:
            logger.error(f"Error getting daily stats: {e}")
            return {}
    
    def get_content_performance(self):
        """Get performance metrics for content"""
        try:
            content_stats = defaultdict(lambda: {
                'views': 0,
                'clicks': 0,
                'engagement_rate': 0
            })
            
            for event in self.events:
                if event['event_type'] == 'message_view':
                    msg_id = event['data'].get('message_id', 'unknown')
                    content_stats[msg_id]['views'] += 1
                elif event['event_type'] == 'link_click':
                    msg_id = event['data'].get('message_id', 'unknown')
                    content_stats[msg_id]['clicks'] += 1
            
            # Calculate engagement rates
            for msg_id, stats in content_stats.items():
                if stats['views'] > 0:
                    stats['engagement_rate'] = (stats['clicks'] / stats['views']) * 100
            
            return dict(content_stats)
        except Exception as e:
            logger.error(f"Error getting content performance: {e}")
            return {}
    
    def generate_engagement_report(self):
        """Generate comprehensive engagement report"""
        try:
            report = {
                'timestamp': datetime.now().isoformat(),
                'total_events': len(self.events),
                'unique_users': len(set(e['user_id'] for e in self.events)),
                'daily_stats': self.get_daily_stats(7),
                'top_users': self.get_top_users(5),
                'content_performance': self.get_content_performance()
            }
            
            logger.info(f"Engagement report generated: {report['total_events']} events")
            return report
        except Exception as e:
            logger.error(f"Error generating report: {e}")
            return {}
    
    def get_conversion_funnel(self):
        """Get conversion funnel metrics"""
        try:
            # Track user journey
            funnel = {
                'total_views': 0,
                'total_clicks': 0,
                'total_subscriptions': 0,
                'conversion_rate': 0
            }
            
            for event in self.events:
                if event['event_type'] == 'message_view':
                    funnel['total_views'] += 1
                elif event['event_type'] == 'link_click':
                    funnel['total_clicks'] += 1
                elif event['event_type'] == 'subscription':
                    funnel['total_subscriptions'] += 1
            
            # Calculate conversion rates
            if funnel['total_views'] > 0:
                funnel['view_to_click'] = (funnel['total_clicks'] / funnel['total_views']) * 100
                funnel['view_to_subscription'] = (funnel['total_subscriptions'] / funnel['total_views']) * 100
            
            if funnel['total_clicks'] > 0:
                funnel['click_to_subscription'] = (funnel['total_subscriptions'] / funnel['total_clicks']) * 100
            
            return funnel
        except Exception as e:
            logger.error(f"Error getting conversion funnel: {e}")
            return {}

def main():
    """Main function for testing"""
    engagement = UserEngagement()
    
    # Track some test events
    engagement.track_message_view(123456, 'msg_001')
    engagement.track_message_view(123456, 'msg_001')
    engagement.track_click(123456, 'https://aries76.com')
    engagement.track_subscription(123456, 'premium')
    
    engagement.track_message_view(234567, 'msg_001')
    engagement.track_click(234567, 'https://aries76.com')
    
    # Get engagement report
    report = engagement.generate_engagement_report()
    print(f"\nEngagement Report:")
    print(f"  Total events: {report['total_events']}")
    print(f"  Unique users: {report['unique_users']}")
    
    # Get conversion funnel
    funnel = engagement.get_conversion_funnel()
    print(f"\nConversion Funnel:")
    print(f"  Total views: {funnel['total_views']}")
    print(f"  Total clicks: {funnel['total_clicks']}")
    print(f"  Total subscriptions: {funnel['total_subscriptions']}")
    if 'view_to_click' in funnel:
        print(f"  View to click: {funnel['view_to_click']:.1f}%")

if __name__ == '__main__':
    main()
