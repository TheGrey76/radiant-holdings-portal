#!/usr/bin/env python3
"""
Digital Assets News Generator
Generates news updates about digital assets from around the world
"""

import logging
from pathlib import Path
import httpx

logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'digital_assets_news.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class DigitalAssetsNewsGenerator:
    """Generate digital assets news updates"""
    
    def __init__(self):
        self.api_key = "719499ece05e416b962d74fe012371e0"
        logger.info("Digital Assets News Generator initialized")
    
    def fetch_digital_assets_news(self):
        """Fetch digital assets news from NewsAPI"""
        try:
            logger.info("Fetching digital assets news...")
            
            # Search for digital assets, crypto, blockchain news
            queries = [
                "digital assets",
                "cryptocurrency",
                "blockchain",
                "Web3",
                "NFT",
                "DeFi"
            ]
            
            all_articles = []
            
            for query in queries:
                try:
                    url = "https://newsapi.org/v2/everything"
                    params = {
                        "q": query,
                        "apiKey": self.api_key,
                        "sortBy": "publishedAt",
                        "language": "en",
                        "pageSize": 5
                    }
                    
                    response = httpx.get(url, params=params, timeout=10)
                    
                    if response.status_code == 200:
                        data = response.json()
                        articles = data.get("articles", [])
                        all_articles.extend(articles)
                        logger.info(f"✓ Fetched {len(articles)} articles for '{query}'")
                except Exception as e:
                    logger.error(f"Error fetching news for '{query}': {e}")
            
            # Remove duplicates and sort by date
            seen_urls = set()
            unique_articles = []
            for article in all_articles:
                url = article.get("url")
                if url not in seen_urls:
                    seen_urls.add(url)
                    unique_articles.append(article)
            
            # Sort by published date
            unique_articles.sort(key=lambda x: x.get("publishedAt", ""), reverse=True)
            
            logger.info(f"✓ Total unique articles: {len(unique_articles)}")
            return unique_articles[:10]  # Return top 10
        
        except Exception as e:
            logger.error(f"Error fetching digital assets news: {e}")
            return []
    
    def generate_news_update(self):
        """Generate formatted news update message"""
        try:
            logger.info("Generating digital assets news update...")
            
            articles = self.fetch_digital_assets_news()
            
            if not articles:
                logger.warning("No articles found")
                return None
            
            # Build message
            message = """<b>🌍 DIGITAL ASSETS NEWS UPDATE</b>
<b>Most Relevant News Worldwide</b>

"""
            
            # Add top 5 news
            for i, article in enumerate(articles[:5], 1):
                title = article.get("title", "No title")
                source = article.get("source", {}).get("name", "Unknown")
                url = article.get("url", "")
                
                # Truncate title if too long
                if len(title) > 80:
                    title = title[:77] + "..."
                
                message += f"""<b>{i}. {title}</b>
📰 Source: {source}

"""
            
            # Add footer
            message += """<b>📊 Categories Covered:</b>
• Digital Assets
• Cryptocurrency
• Blockchain
• Web3
• NFT
• DeFi

<b>🔗 Full Report:</b>
<a href="https://www.aries76.com/bitcoin-2026-report-preview">Get Complete Analysis</a>

#DigitalAssets #Crypto #Blockchain #Web3"""
            
            logger.info("✓ Digital assets news update generated")
            return message
        
        except Exception as e:
            logger.error(f"Error generating news update: {e}")
            return None

def main():
    """Test the generator"""
    generator = DigitalAssetsNewsGenerator()
    message = generator.generate_news_update()
    
    if message:
        print("=" * 70)
        print("GENERATED MESSAGE:")
        print("=" * 70)
        print(message)
    else:
        print("Failed to generate message")

if __name__ == '__main__':
    main()
