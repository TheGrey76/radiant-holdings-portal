#!/usr/bin/env python3
"""
Social Media Publisher
Automated publishing of Bitcoin content to social media platforms
"""

import os
import json
import logging
from typing import List, Dict
from datetime import datetime
import requests

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/ubuntu/bitcoin_automation/logs/publishing.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class LinkedInPublisher:
    """Publish content to LinkedIn"""
    
    def __init__(self, access_token: str = None):
        self.access_token = access_token or os.getenv("LINKEDIN_ACCESS_TOKEN")
        self.api_base = "https://api.linkedin.com/v2"
        
    def publish_post(self, content: str, schedule_time: str = None) -> bool:
        """Publish a post to LinkedIn using Advertising API"""
        
        if not self.access_token:
            logger.warning("LinkedIn access token not configured")
            return False
        
        try:
            headers = {
                "Authorization": f"Bearer {self.access_token}",
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest"
            }
            
            # Create post using UGC Posts API (works with personal profiles)
            post_data = {
                "author": "urn:li:person:edoardogrigione",  # Using username-based URN
                "lifecycleState": "PUBLISHED",
                "specificContent": {
                    "com.linkedin.ugc.ShareContent": {
                        "shareCommentary": {
                            "text": content
                        },
                        "shareMediaCategory": "NONE"
                    }
                },
                "visibility": {
                    "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"
                }
            }
            
            response = requests.post(
                f"{self.api_base}/ugcPosts",
                headers=headers,
                json=post_data,
                timeout=10
            )
            
            if response.status_code in [200, 201]:
                logger.info(f"LinkedIn post published successfully")
                return True
            else:
                logger.error(f"LinkedIn API error: {response.status_code} - {response.text}")
                return False
            
        except Exception as e:
            logger.error(f"Error publishing to LinkedIn: {e}")
            logger.error(f"Full error details: {str(e)}")
            return False
    
    def schedule_posts(self, posts: List[str], times: List[str]) -> Dict[str, bool]:
        """Schedule multiple posts"""
        
        results = {}
        for i, (post, time) in enumerate(zip(posts, times)):
            results[f"post_{i+1}"] = self.publish_post(post, time)
        
        return results


class TwitterPublisher:
    """Publish content to Twitter/X"""
    
    def __init__(self, api_key: str = None, api_secret: str = None, 
                 access_token: str = None, access_secret: str = None):
        self.api_key = api_key or os.getenv("TWITTER_API_KEY")
        self.api_secret = api_secret or os.getenv("TWITTER_API_SECRET")
        self.access_token = access_token or os.getenv("TWITTER_ACCESS_TOKEN")
        self.access_secret = access_secret or os.getenv("TWITTER_ACCESS_SECRET")
        self.bearer_token = os.getenv("TWITTER_BEARER_TOKEN")
        
    def publish_tweet(self, text: str, image_path: str = None, 
                     reply_to_id: str = None) -> bool:
        """Publish a tweet"""
        
        if not self.bearer_token:
            logger.warning("Twitter bearer token not configured")
            return False
        
        try:
            headers = {
                "Authorization": f"Bearer {self.bearer_token}",
                "Content-Type": "application/json"
            }
            
            # Prepare tweet data
            tweet_data = {"text": text}
            
            # Add image if provided
            if image_path and os.path.exists(image_path):
                media_id = self._upload_media(image_path)
                if media_id:
                    tweet_data["media"] = {
                        "media_ids": [media_id]
                    }
            
            # Add reply reference if provided
            if reply_to_id:
                tweet_data["reply"] = {
                    "in_reply_to_tweet_id": reply_to_id
                }
            
            response = requests.post(
                "https://api.twitter.com/2/tweets",
                headers=headers,
                json=tweet_data,
                timeout=10
            )
            response.raise_for_status()
            
            logger.info(f"Tweet published successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error publishing tweet: {e}")
            return False
    
    def _upload_media(self, image_path: str) -> str:
        """Upload media to Twitter"""
        
        try:
            headers = {
                "Authorization": f"Bearer {self.bearer_token}"
            }
            
            with open(image_path, 'rb') as f:
                files = {'media_data': f}
                response = requests.post(
                    "https://upload.twitter.com/1.1/media/upload.json",
                    headers=headers,
                    files=files,
                    timeout=10
                )
            response.raise_for_status()
            
            media_id = response.json()["media_id_string"]
            logger.info(f"Media uploaded successfully: {media_id}")
            return media_id
            
        except Exception as e:
            logger.error(f"Error uploading media: {e}")
            return None
    
    def publish_thread(self, tweets: List[str]) -> bool:
        """Publish a thread of tweets"""
        
        reply_id = None
        for i, tweet in enumerate(tweets):
            success = self.publish_tweet(tweet, reply_to_id=reply_id)
            if not success:
                logger.error(f"Failed to publish tweet {i+1} in thread")
                return False
            # Note: In real implementation, would need to capture the tweet ID
        
        logger.info(f"Thread of {len(tweets)} tweets published successfully")
        return True


class InstagramPublisher:
    """Publish content to Instagram"""
    
    def __init__(self, access_token: str = None):
        self.access_token = access_token or os.getenv("INSTAGRAM_ACCESS_TOKEN")
        self.api_base = "https://graph.instagram.com"
        
    def publish_post(self, image_path: str, caption: str) -> bool:
        """Publish a post to Instagram"""
        
        if not self.access_token:
            logger.warning("Instagram access token not configured")
            return False
        
        try:
            # Get user ID
            user_response = requests.get(
                f"{self.api_base}/me",
                params={"access_token": self.access_token},
                timeout=10
            )
            user_response.raise_for_status()
            user_id = user_response.json()["id"]
            
            # Upload image
            with open(image_path, 'rb') as f:
                files = {'image': f}
                data = {
                    'caption': caption,
                    'access_token': self.access_token
                }
                
                response = requests.post(
                    f"{self.api_base}/{user_id}/media",
                    files=files,
                    data=data,
                    timeout=30
                )
            response.raise_for_status()
            
            logger.info(f"Instagram post published successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error publishing to Instagram: {e}")
            return False


class ContentPublisher:
    """Orchestrate publishing across all platforms"""
    
    def __init__(self):
        self.linkedin = LinkedInPublisher()
        self.twitter = TwitterPublisher()
        self.instagram = InstagramPublisher()
        
    def publish_daily_content(self, content_files: Dict[str, str]) -> Dict:
        """Publish generated content to all platforms"""
        
        logger.info("=" * 60)
        logger.info("Starting content publishing")
        logger.info("=" * 60)
        
        results = {
            "timestamp": datetime.now().isoformat(),
            "platforms": {}
        }
        
        # Load content files
        linkedin_posts = self._load_json(content_files.get('linkedin'))
        twitter_posts = self._load_json(content_files.get('twitter'))
        
        # Publish to LinkedIn
        if linkedin_posts:
            logger.info("Publishing to LinkedIn...")
            linkedin_results = self.linkedin.schedule_posts(
                linkedin_posts.get('posts', []),
                ["08:30", "13:00"]  # Schedule times
            )
            results["platforms"]["linkedin"] = linkedin_results
        
        # Publish to Twitter
        if twitter_posts:
            logger.info("Publishing to Twitter...")
            twitter_results = {}
            for i, post in enumerate(twitter_posts.get('posts', [])):
                success = self.twitter.publish_tweet(post)
                twitter_results[f"tweet_{i+1}"] = success
            results["platforms"]["twitter"] = twitter_results
        
        # Save publishing results
        results_file = "/home/ubuntu/bitcoin_automation/logs/publishing_results.json"
        os.makedirs(os.path.dirname(results_file), exist_ok=True)
        with open(results_file, 'a') as f:
            f.write(json.dumps(results) + "\n")
        
        logger.info("=" * 60)
        logger.info("Content publishing completed")
        logger.info("=" * 60)
        
        return results
    
    def _load_json(self, file_path: str) -> Dict:
        """Load JSON content file"""
        
        if not file_path or not os.path.exists(file_path):
            return {}
        
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading {file_path}: {e}")
            return {}


def publish_content(content_files: Dict[str, str]) -> Dict:
    """Main function to publish content"""
    
    publisher = ContentPublisher()
    return publisher.publish_daily_content(content_files)


if __name__ == "__main__":
    # Example usage
    content_files = {
        'linkedin': '/home/ubuntu/bitcoin_automation/generated_content/linkedin_posts_20240108_060000.json',
        'twitter': '/home/ubuntu/bitcoin_automation/generated_content/twitter_posts_20240108_060000.json'
    }
    
    publish_content(content_files)
