#!/usr/bin/env python3
"""
ARIES76 Triple Scheduler
Automated Bitcoin analysis + Digital Assets news publishing
Schedule: 6:00 AM + 12:00 PM + 6:30 PM CET
"""

import asyncio
import logging
import time
import os
from datetime import datetime
from pathlib import Path
from enhanced_content_generator import EnhancedContentGenerator
from digital_assets_news_generator import DigitalAssetsNewsGenerator
import httpx

# Set timezone to Europe/Rome (CET/CEST)
os.environ['TZ'] = 'Europe/Rome'
time.tzset()

logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'triple_scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class TripleScheduler:
    """Triple scheduler with 3x daily publications"""
    
    def __init__(self):
        self.bitcoin_generator = EnhancedContentGenerator()
        self.news_generator = DigitalAssetsNewsGenerator()
        self.token = "8269982447:AAGR7PM7Dkpbslb7eT-rAimj5puKxcEfaV8"
        self.channel = "@aries76_bitcoin"
        self.last_morning = None
        self.last_noon = None
        self.last_evening = None
        logger.info("Triple Scheduler initialized")
        logger.info("Timezone: Europe/Rome (CET/CEST)")
        logger.info("Schedule: 6:00 AM + 12:00 PM + 6:30 PM")
    
    async def publish(self, message):
        """Publish message to Telegram"""
        try:
            logger.info("Publishing message to Telegram...")
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"https://api.telegram.org/bot{self.token}/sendMessage",
                    json={
                        "chat_id": self.channel,
                        "text": message,
                        "parse_mode": "HTML"
                    },
                    timeout=30
                )
                
                if response.status_code == 200:
                    logger.info("✓ Message published successfully")
                    return True
                else:
                    logger.error(f"Telegram error: {response.text}")
                    return False
        except Exception as e:
            logger.error(f"Error publishing: {e}")
            return False
    
    async def run_morning(self):
        """Run morning Bitcoin analysis"""
        try:
            logger.info("=" * 70)
            logger.info("📤 MORNING ANALYSIS - GENERATING & PUBLISHING")
            logger.info("=" * 70)
            
            message = self.bitcoin_generator.generate_telegram_message_with_news()
            
            if not message:
                logger.error("Failed to generate morning message")
                return False
            
            result = await self.publish(message)
            
            if result:
                logger.info("✅ Morning analysis published successfully")
                self.last_morning = datetime.now()
            
            return result
        except Exception as e:
            logger.error(f"Error in morning analysis: {e}")
            return False
    
    async def run_noon(self):
        """Run noon digital assets news"""
        try:
            logger.info("=" * 70)
            logger.info("📤 NOON NEWS UPDATE - GENERATING & PUBLISHING")
            logger.info("=" * 70)
            
            message = self.news_generator.generate_news_update()
            
            if not message:
                logger.error("Failed to generate noon news message")
                return False
            
            result = await self.publish(message)
            
            if result:
                logger.info("✅ Noon news update published successfully")
                self.last_noon = datetime.now()
            
            return result
        except Exception as e:
            logger.error(f"Error in noon news: {e}")
            return False
    
    async def run_evening(self):
        """Run evening Bitcoin analysis"""
        try:
            logger.info("=" * 70)
            logger.info("📤 EVENING ANALYSIS - GENERATING & PUBLISHING")
            logger.info("=" * 70)
            
            message = self.bitcoin_generator.generate_news_focused_post()
            
            if not message:
                logger.error("Failed to generate evening message")
                return False
            
            result = await self.publish(message)
            
            if result:
                logger.info("✅ Evening analysis published successfully")
                self.last_evening = datetime.now()
            
            return result
        except Exception as e:
            logger.error(f"Error in evening analysis: {e}")
            return False
    
    def should_run_morning(self):
        """Check if morning task should run (6:00 AM)"""
        now = datetime.now()
        
        # Run at 6:00 AM (hour=6, minute=0-4)
        if now.hour == 6 and now.minute < 5:
            if self.last_morning is None or (now - self.last_morning).total_seconds() > 3600:
                return True
        
        return False
    
    def should_run_noon(self):
        """Check if noon task should run (12:00 PM)"""
        now = datetime.now()
        
        # Run at 12:00 PM (hour=12, minute=0-4)
        if now.hour == 12 and now.minute < 5:
            if self.last_noon is None or (now - self.last_noon).total_seconds() > 3600:
                return True
        
        return False
    
    def should_run_evening(self):
        """Check if evening task should run (6:30 PM)"""
        now = datetime.now()
        
        # Run at 6:30 PM (hour=18, minute=30-34)
        if now.hour == 18 and 30 <= now.minute < 35:
            if self.last_evening is None or (now - self.last_evening).total_seconds() > 3600:
                return True
        
        return False
    
    def run(self):
        """Main scheduler loop"""
        logger.info("=" * 70)
        logger.info("ARIES76 TRIPLE SCHEDULER - STARTED")
        logger.info("=" * 70)
        logger.info("Press Ctrl+C to stop")
        logger.info("")
        logger.info("Timezone: Europe/Rome (CET/CEST)")
        logger.info("Schedule:")
        logger.info("  - 6:00 AM: Morning Bitcoin analysis with trending news")
        logger.info("  - 12:00 PM: Digital Assets news update")
        logger.info("  - 6:30 PM: Evening Bitcoin analysis with trending news")
        logger.info("")
        logger.info("=" * 70)
        
        check_count = 0
        
        try:
            while True:
                now = datetime.now()
                check_count += 1
                
                # Log every 20 checks (every 10 minutes)
                if check_count % 20 == 0:
                    logger.info(f"[CHECK #{check_count}] Current time: {now.strftime('%Y-%m-%d %H:%M:%S')}")
                
                # Check morning task
                if self.should_run_morning():
                    logger.info(f"🌅 MORNING WINDOW DETECTED at {now.strftime('%Y-%m-%d %H:%M:%S')}")
                    await_result = asyncio.run(self.run_morning())
                    if await_result:
                        logger.info("✅ Morning task completed successfully")
                    time.sleep(60)  # Wait 1 minute to avoid duplicate runs
                
                # Check noon task
                if self.should_run_noon():
                    logger.info(f"☀️ NOON WINDOW DETECTED at {now.strftime('%Y-%m-%d %H:%M:%S')}")
                    await_result = asyncio.run(self.run_noon())
                    if await_result:
                        logger.info("✅ Noon task completed successfully")
                    time.sleep(60)  # Wait 1 minute to avoid duplicate runs
                
                # Check evening task
                if self.should_run_evening():
                    logger.info(f"🌆 EVENING WINDOW DETECTED at {now.strftime('%Y-%m-%d %H:%M:%S')}")
                    await_result = asyncio.run(self.run_evening())
                    if await_result:
                        logger.info("✅ Evening task completed successfully")
                    time.sleep(60)  # Wait 1 minute to avoid duplicate runs
                
                time.sleep(30)
        except KeyboardInterrupt:
            logger.info("Scheduler stopped by user")
        except Exception as e:
            logger.error(f"Fatal error: {e}")
            import traceback
            logger.error(traceback.format_exc())

def main():
    """Main entry point"""
    scheduler = TripleScheduler()
    scheduler.run()

if __name__ == '__main__':
    main()
