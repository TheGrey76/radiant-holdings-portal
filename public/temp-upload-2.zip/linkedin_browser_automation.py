"""
LinkedIn Browser Automation for Automatic Post Publishing
Uses Selenium to automate LinkedIn posting without API limitations
"""

import os
import json
import time
import logging
from datetime import datetime
from typing import List, Dict
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/ubuntu/bitcoin_automation/logs/linkedin_automation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class LinkedInBrowserAutomation:
    """Automate LinkedIn posting using Selenium"""
    
    def __init__(self):
        self.driver = None
        self.wait = None
        
    def setup_driver(self):
        """Initialize Chrome driver with options"""
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        
        self.driver = webdriver.Chrome(options=chrome_options)
        self.wait = WebDriverWait(self.driver, 10)
        
        logger.info("Chrome driver initialized")
        
    def login_linkedin(self, email: str, password: str) -> bool:
        """Login to LinkedIn"""
        try:
            logger.info("Navigating to LinkedIn...")
            self.driver.get('https://www.linkedin.com/login')
            time.sleep(2)
            
            # Enter email
            email_input = self.wait.until(EC.presence_of_element_located((By.ID, 'username')))
            email_input.send_keys(email)
            
            # Enter password
            password_input = self.driver.find_element(By.ID, 'password')
            password_input.send_keys(password)
            
            # Click login
            login_button = self.driver.find_element(By.XPATH, '//button[@aria-label="Sign in"]')
            login_button.click()
            
            time.sleep(5)
            logger.info("✓ Successfully logged in to LinkedIn")
            return True
            
        except Exception as e:
            logger.error(f"Login failed: {e}")
            return False
    
    def publish_post(self, content: str) -> bool:
        """Publish a post to LinkedIn"""
        try:
            logger.info(f"Publishing post: {content[:50]}...")
            
            # Navigate to home
            self.driver.get('https://www.linkedin.com/feed/')
            time.sleep(2)
            
            # Click on post composer
            try:
                post_button = self.wait.until(
                    EC.element_to_be_clickable((By.XPATH, '//button[contains(text(), "Start a post")]'))
                )
                post_button.click()
            except:
                # Alternative selector
                post_button = self.wait.until(
                    EC.element_to_be_clickable((By.XPATH, '//div[@role="button" and contains(., "Start a post")]'))
                )
                post_button.click()
            
            time.sleep(2)
            
            # Find and fill the text area
            text_area = self.wait.until(
                EC.presence_of_element_located((By.XPATH, '//div[@role="textbox"]'))
            )
            text_area.click()
            time.sleep(1)
            
            # Type the content
            text_area.send_keys(content)
            time.sleep(1)
            
            # Click publish button
            publish_button = self.wait.until(
                EC.element_to_be_clickable((By.XPATH, '//button[contains(text(), "Post")]'))
            )
            publish_button.click()
            
            time.sleep(3)
            logger.info("✓ Post published successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error publishing post: {e}")
            return False
    
    def publish_multiple_posts(self, posts: List[str]) -> Dict[int, bool]:
        """Publish multiple posts"""
        results = {}
        
        for i, post in enumerate(posts):
            logger.info(f"Publishing post {i+1}/{len(posts)}")
            result = self.publish_post(post)
            results[i] = result
            
            if i < len(posts) - 1:
                time.sleep(5)  # Wait between posts
        
        return results
    
    def close(self):
        """Close the browser"""
        if self.driver:
            self.driver.quit()
            logger.info("Browser closed")


def publish_posts_from_file(json_file: str, email: str, password: str) -> bool:
    """Load posts from JSON file and publish them"""
    
    try:
        with open(json_file, 'r') as f:
            data = json.load(f)
        
        posts = [post['text'] for post in data['posts']]
        
        automation = LinkedInBrowserAutomation()
        automation.setup_driver()
        
        if not automation.login_linkedin(email, password):
            automation.close()
            return False
        
        results = automation.publish_multiple_posts(posts)
        automation.close()
        
        logger.info(f"Publishing complete. Results: {results}")
        return all(results.values())
        
    except Exception as e:
        logger.error(f"Error in publish_posts_from_file: {e}")
        return False


if __name__ == '__main__':
    # Example usage
    email = os.getenv('LINKEDIN_EMAIL')
    password = os.getenv('LINKEDIN_PASSWORD')
    
    if not email or not password:
        logger.error("LinkedIn credentials not found in environment variables")
        logger.info("Set LINKEDIN_EMAIL and LINKEDIN_PASSWORD environment variables")
    else:
        # Find the latest posts file
        posts_dir = '/home/ubuntu/bitcoin_automation/generated_content'
        latest_file = max(
            [f for f in os.listdir(posts_dir) if f.startswith('linkedin_posts')],
            key=lambda f: os.path.getctime(os.path.join(posts_dir, f))
        )
        
        json_file = os.path.join(posts_dir, latest_file)
        publish_posts_from_file(json_file, email, password)
