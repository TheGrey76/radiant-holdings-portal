#!/usr/bin/env python3
"""
ARIES76 Telegram Bot Automation
Publishes daily Bitcoin analysis to Telegram channel and group
"""

import os
import sys
import json
import logging
from datetime import datetime
from pathlib import Path

# Add bitcoin_automation to path
sys.path.insert(0, '/home/ubuntu/bitcoin_automation')

from telegram import Bot
from telegram.error import TelegramError
import asyncio

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/ubuntu/telegram_automation/logs/telegram_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ARIES76TelegramBot:
    """Telegram bot for ARIES76 Bitcoin analysis automation"""
    
    def __init__(self):
        """Initialize the bot"""
        self.bot_token = "8269982447:AAGR7PM7Dkpbslb7eT-rAimj5puKxcEfaV8"
        self.channel_username = "@aries76_bitcoin"
        self.bot = Bot(token=self.bot_token)
        
        # Paths
        self.content_dir = Path('/home/ubuntu/bitcoin_automation/generated_content')
        self.logs_dir = Path('/home/ubuntu/telegram_automation/logs')
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info("ARIES76 Telegram Bot initialized")
        logger.info(f"Channel: {self.channel_username}")
    
    def load_latest_content(self):
        """Load the latest generated Bitcoin content"""
        try:
            # Find the latest article
            articles = sorted(self.content_dir.glob('article_*.md'))
            if not articles:
                logger.warning("No articles found")
                return None
            
            latest_article = articles[-1]
            with open(latest_article, 'r', encoding='utf-8') as f:
                article_content = f.read()
            
            # Find the latest LinkedIn posts
            posts = sorted(self.content_dir.glob('linkedin_posts_*.json'))
            if not posts:
                logger.warning("No LinkedIn posts found")
                linkedin_posts = []
            else:
                latest_posts = posts[-1]
                with open(latest_posts, 'r', encoding='utf-8') as f:
                    linkedin_posts = json.load(f)
            
            return {
                'article': article_content,
                'posts': linkedin_posts,
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error loading content: {e}")
            return None
    
    async def send_to_channel(self, message_text):
        """Send a message to the Telegram channel"""
        try:
            logger.info(f"Sending message to channel {self.channel_username}")
            
            # Split long messages (Telegram limit is 4096 characters)
            max_length = 4096
            if len(message_text) > max_length:
                messages = [message_text[i:i+max_length] 
                           for i in range(0, len(message_text), max_length)]
            else:
                messages = [message_text]
            
            for msg in messages:
                await self.bot.send_message(
                    chat_id=self.channel_username,
                    text=msg,
                    parse_mode='HTML'
                )
                logger.info(f"Message sent successfully")
                await asyncio.sleep(1)  # Rate limiting
            
            return True
        except TelegramError as e:
            logger.error(f"Telegram error: {e}")
            return False
        except Exception as e:
            logger.error(f"Error sending message: {e}")
            return False
    
    def format_channel_message(self, content):
        """Format content for channel posting"""
        try:
            article = content.get('article', '')
            posts = content.get('posts', [])
            
            # Extract title and summary from article
            lines = article.split('\n')
            title = lines[0].replace('#', '').strip() if lines else "Bitcoin Analysis"
            
            # Create formatted message
            message = f"""
<b>📊 {title}</b>

<b>Daily Bitcoin Market Analysis</b>

{article[:500]}...

<b>Read full analysis:</b> https://www.aries76.com/funnel-bitcoin-report

<b>🔔 Subscribe to stay updated</b>
"""
            return message.strip()
        except Exception as e:
            logger.error(f"Error formatting message: {e}")
            return "Daily Bitcoin Analysis - Check ARIES76 for full report"
    
    async def publish_daily_analysis(self):
        """Publish daily Bitcoin analysis to channel"""
        try:
            logger.info("Starting daily analysis publication")
            
            # Load content
            content = self.load_latest_content()
            if not content:
                logger.warning("No content to publish")
                return False
            
            # Format message
            message = self.format_channel_message(content)
            
            # Send to channel
            success = await self.send_to_channel(message)
            
            if success:
                logger.info("Daily analysis published successfully")
                # Log the publication
                with open(self.logs_dir / 'publications.log', 'a') as f:
                    f.write(f"{datetime.now().isoformat()} - Published daily analysis\n")
            
            return success
        except Exception as e:
            logger.error(f"Error publishing daily analysis: {e}")
            return False
    
    async def send_trading_signal(self, signal_data):
        """Send trading signal to channel"""
        try:
            message = f"""
<b>🚨 Trading Signal</b>

{signal_data.get('description', 'New trading opportunity')}

<b>Details:</b>
• Asset: {signal_data.get('asset', 'BTC')}
• Signal: {signal_data.get('signal', 'N/A')}
• Confidence: {signal_data.get('confidence', 'N/A')}

<b>Full analysis:</b> https://www.aries76.com
"""
            return await self.send_to_channel(message)
        except Exception as e:
            logger.error(f"Error sending signal: {e}")
            return False
    
    async def test_connection(self):
        """Test bot connection"""
        try:
            me = await self.bot.get_me()
            logger.info(f"Bot connection successful: @{me.username}")
            return True
        except Exception as e:
            logger.error(f"Bot connection failed: {e}")
            return False

async def main():
    """Main function"""
    bot = ARIES76TelegramBot()
    
    # Test connection
    if not await bot.test_connection():
        logger.error("Failed to connect to Telegram")
        return
    
    # Publish daily analysis
    await bot.publish_daily_analysis()

if __name__ == '__main__':
    asyncio.run(main())
