#!/usr/bin/env python3
"""
ARIES76 Real-time Content Generator
Generates Bitcoin analysis content using live API data
"""

import logging
from datetime import datetime
from pathlib import Path
from bitcoin_data_fetcher import BitcoinDataFetcher

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'realtime_content_generator.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class RealtimeContentGenerator:
    """Generate Bitcoin analysis content from real-time data"""
    
    def __init__(self, newsapi_key=None):
        """Initialize content generator"""
        self.fetcher = BitcoinDataFetcher(newsapi_key)
        logger.info("Real-time Content Generator initialized")
    
    def generate_telegram_message(self):
        """Generate a Telegram-ready message with real-time data"""
        try:
            logger.info("Generating real-time Telegram message...")
            
            # Fetch all data
            price_data = self.fetcher.get_bitcoin_price()
            sentiment = self.fetcher.get_market_sentiment()
            levels = self.fetcher.get_resistance_support()
            news = self.fetcher.get_bitcoin_news(2)
            
            if not price_data or not sentiment or not levels:
                logger.error("Failed to fetch required data")
                return None
            
            # Format message
            message = f"""
<b>📊 Bitcoin Market Analysis - Real-time Update</b>

<b>Current Market Status</b>
💰 <b>Price:</b> ${price_data['price']:,.2f}
📈 <b>24h Change:</b> {price_data['change_24h']:+.2f}%
💎 <b>Market Cap:</b> ${price_data['market_cap']/1e12:.2f}T
📊 <b>Volume 24h:</b> ${price_data['volume_24h']/1e9:.2f}B

<b>Technical Levels</b>
🎯 <b>Resistance:</b> ${levels['resistance']:,.2f}
🛡️ <b>Support:</b> ${levels['support']:,.2f}
📍 <b>24h High:</b> ${technical['high_24h']:,.2f}
📍 <b>24h Low:</b> ${technical['low_24h']:,.2f}

<b>Market Sentiment</b>
{sentiment['emoji']} <b>{sentiment['sentiment']}</b>

<b>Latest News</b>
"""
            
            for i, article in enumerate(news, 1):
                title = article['title'][:50]
                message += f"\n{i}. {title}..."
            
            message += f"""

<b>📈 Trading Signals</b>
🟢 <b>Signal:</b> {"BUY" if price_data['change_24h'] > 0 else "SELL"}
📍 <b>Entry:</b> ${price_data['price']:,.2f}
🎯 <b>Target:</b> ${levels['resistance']:,.2f}
⛔ <b>Stop Loss:</b> ${levels['support']:,.2f}

<b>👉 Get Full Analysis:</b>
https://www.aries76.com/funnel-bitcoin-report

<b>🔔 Subscribe for daily updates</b>
"""
            
            logger.info("✓ Real-time message generated")
            return message.strip()
        except Exception as e:
            logger.error(f"Error generating message: {e}")
            return None
    
    def generate_detailed_article(self):
        """Generate a detailed article with real-time data"""
        try:
            logger.info("Generating detailed article...")
            
            # Fetch all data
            price_data = self.fetcher.get_bitcoin_price()
            sentiment = self.fetcher.get_market_sentiment()
            levels = self.fetcher.get_resistance_support()
            news = self.fetcher.get_bitcoin_news(3)
            
            if not price_data or not sentiment or not levels:
                logger.error("Failed to fetch required data")
                return None
            
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
            
            article = f"""# Bitcoin Market Analysis - {timestamp}

## Executive Summary
Bitcoin is currently trading at **${price_data['price']:,.2f}** with a **{price_data['change_24h']:+.2f}%** change in the last 24 hours. Market sentiment is **{sentiment['sentiment']}** {sentiment['emoji']}.

## Current Market Status
- **Bitcoin Price**: ${price_data['price']:,.2f} USD
- **24h Change**: {price_data['change_24h']:+.2f}%
- **Market Cap**: ${price_data['market_cap']/1e12:.2f} Trillion USD
- **24h Volume**: ${price_data['volume_24h']/1e9:.2f} Billion USD
- **Market Cap Rank**: #{technical['market_cap_rank']}

## Technical Analysis
Bitcoin has shown a **{price_data['change_24h']:+.2f}%** movement in the last 24 hours. Key technical levels are:

- **24h High**: ${technical['high_24h']:,.2f}
- **24h Low**: ${technical['low_24h']:,.2f}
- **All-Time High**: ${technical['ath']:,.2f}
- **All-Time Low**: ${technical['atl']:,.2f}

## Resistance & Support Levels
Based on current market data:

- **Resistance Level**: ${levels['resistance']:,.2f}
- **Support Level**: ${levels['support']:,.2f}
- **Current Price**: ${levels['current']:,.2f}

## Market Sentiment
The market sentiment is currently **{sentiment['sentiment']}** {sentiment['emoji']}, indicating a {"bullish" if "BULLISH" in sentiment['sentiment'] else "bearish" if "BEARISH" in sentiment['sentiment'] else "neutral"} outlook.

## Trading Signals
Based on current technical analysis:

- **Signal**: {"🟢 BUY" if price_data['change_24h'] > 0 else "🔴 SELL"}
- **Entry Point**: ${price_data['price']:,.2f}
- **Target Price**: ${levels['resistance']:,.2f}
- **Stop Loss**: ${levels['support']:,.2f}
- **Risk/Reward Ratio**: {((levels['resistance'] - price_data['price']) / (price_data['price'] - levels['support'])):.2f}:1

## Latest Bitcoin News

"""
            
            for i, article_data in enumerate(news, 1):
                article += f"\n### {i}. {article_data['title']}\n"
                article += f"**Source**: {article_data['source']}\n"
                article += f"**Description**: {article_data['description'][:200]}...\n"
                article += f"**Read more**: {article_data['url']}\n"
            
            article += f"""

## Key Takeaways

1. Bitcoin is currently trading at **${price_data['price']:,.2f}** with a **{price_data['change_24h']:+.2f}%** 24-hour change
2. Technical indicators suggest a **{sentiment['sentiment']}** market outlook
3. Key resistance is at **${levels['resistance']:,.2f}** and support at **${levels['support']:,.2f}**
4. Market sentiment is **{sentiment['sentiment']}** based on price action

## Disclaimer
This analysis is for informational purposes only and should not be considered as financial advice. Always do your own research and consult with a financial advisor before making investment decisions.

---

**Analysis Generated**: {timestamp}
**Data Source**: CoinGecko API + NewsAPI
**Next Update**: Daily at 6:00 AM CET

👉 **Get Full Analysis & Trading Signals**: https://www.aries76.com/funnel-bitcoin-report
"""
            
            logger.info("✓ Detailed article generated")
            return article
        except Exception as e:
            logger.error(f"Error generating article: {e}")
            return None
    
    def generate_short_post(self):
        """Generate a short social media post"""
        try:
            logger.info("Generating short post...")
            
            price_data = self.fetcher.get_bitcoin_price()
            sentiment = self.fetcher.get_market_sentiment()
            
            if not price_data:
                return None
            
            direction = "📈 UP" if price_data['change_24h'] > 0 else "📉 DOWN"
            
            post = f"""Bitcoin Update {direction}

Price: ${price_data['price']:,.0f}
Change: {price_data['change_24h']:+.2f}%
Sentiment: {sentiment['sentiment']} {sentiment['emoji']}

Full analysis: https://www.aries76.com/funnel-bitcoin-report

#Bitcoin #Crypto #Trading"""
            
            logger.info("✓ Short post generated")
            return post
        except Exception as e:
            logger.error(f"Error generating short post: {e}")
            return None

def main():
    """Main function for testing"""
    generator = RealtimeContentGenerator()
    
    print("\n" + "=" * 70)
    print("REAL-TIME CONTENT GENERATOR - TEST")
    print("=" * 70)
    
    # Generate Telegram message
    print("\n📱 TELEGRAM MESSAGE:")
    print("-" * 70)
    message = generator.generate_telegram_message()
    if message:
        print(message)
    
    # Generate short post
    print("\n\n📝 SHORT POST:")
    print("-" * 70)
    post = generator.generate_short_post()
    if post:
        print(post)
    
    print("\n" + "=" * 70 + "\n")

if __name__ == '__main__':
    main()
