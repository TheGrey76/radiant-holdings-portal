"""Backtesting engine for the portfolio management system."""

import pandas as pd
from backtesting import Backtest, Strategy
from backtesting.lib import crossover

from dynamic_allocation import DynamicAllocation

class PortfolioStrategy(Strategy):
    def init(self):
        self.allocation_model = DynamicAllocation(self.data.df)
        self.weights = self.I(self.get_weights)

    def get_weights(self):
        # For simplicity, we rebalance monthly
        if self.data.index[-1].month != self.data.index[-2].month:
            return self.allocation_model.get_hrp_allocation()
        else:
            return self.weights[-1]

    def next(self):
        # This is a simplified example. A full implementation would be more complex.
        # We are not actually placing trades here, just showing the concept.
        pass

if __name__ == '__main__':
    # Example usage with dummy data
    data = {
        'Open': [50000 + i*100 for i in range(300)],
        'High': [50100 + i*100 for i in range(300)],
        'Low': [49900 + i*100 for i in range(300)],
        'Close': [50050 + i*100 for i in range(300)],
        'Volume': [100 for i in range(300)]
    }
    prices_df = pd.DataFrame(data, index=pd.to_datetime(pd.date_range('2023-01-01', periods=300)))

    bt = Backtest(prices_df, PortfolioStrategy, cash=100000, commission=.002)
    stats = bt.run()
    print(stats)
    bt.plot()
