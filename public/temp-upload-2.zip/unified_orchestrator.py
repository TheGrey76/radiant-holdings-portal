#!/usr/bin/env python3
"""
ARIES76 Unified Automation Orchestrator
Coordinates Bitcoin content generation and Telegram publishing
"""

import sys
import os
import schedule
import time
import logging
import asyncio
from datetime import datetime
from pathlib import Path

# Add paths
sys.path.insert(0, '/home/ubuntu/bitcoin_automation')
sys.path.insert(0, '/home/ubuntu/telegram_automation')

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'orchestrator.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class UnifiedOrchestrator:
    """Orchestrate both Bitcoin content generation and Telegram publishing"""
    
    def __init__(self):
        """Initialize orchestrator"""
        self.bitcoin_dir = Path('/home/ubuntu/bitcoin_automation')
        self.telegram_dir = Path('/home/ubuntu/telegram_automation')
        self.content_dir = self.bitcoin_dir / 'generated_content'
        
        logger.info("Unified Orchestrator initialized")
    
    def job_generate_content(self):
        """Job: Generate Bitcoin content"""
        try:
            logger.info("=" * 60)
            logger.info("STARTING: Bitcoin Content Generation")
            logger.info("=" * 60)
            
            # Import and run Bitcoin generator
            try:
                from bitcoin_automation.bitcoin_content_generator import BitcoinContentGenerator
                
                generator = BitcoinContentGenerator()
                result = generator.generate_daily_content()
                
                if result:
                    logger.info("✓ Bitcoin content generated successfully")
                    logger.info(f"  Article: {result.get('article_file', 'N/A')}")
                    logger.info(f"  Posts: {result.get('posts_file', 'N/A')}")
                    return True
                else:
                    logger.error("✗ Bitcoin content generation failed")
                    return False
            except ImportError:
                logger.warning("Bitcoin generator module not found, skipping generation")
                return False
        except Exception as e:
            logger.error(f"Error in generate_content job: {e}")
            return False
    
    async def job_publish_content(self):
        """Job: Publish content to Telegram"""
        try:
            logger.info("=" * 60)
            logger.info("STARTING: Telegram Content Publishing")
            logger.info("=" * 60)
            
            # Import and run Telegram publisher
            from telegram_integration import TelegramIntegration
            
            integration = TelegramIntegration()
            
            # Check if content exists
            articles = sorted(self.content_dir.glob('article_*.md'))
            if not articles:
                logger.warning("No content found to publish")
                return False
            
            latest_article = articles[-1]
            logger.info(f"Publishing: {latest_article.name}")
            
            # Publish to Telegram
            result = await integration.publish_daily_content()
            
            if result:
                logger.info("✓ Content published to Telegram successfully")
                return True
            else:
                logger.error("✗ Telegram publishing failed")
                return False
        except Exception as e:
            logger.error(f"Error in publish_content job: {e}")
            return False
    
    def job_combined_workflow(self):
        """Combined job: Generate and publish"""
        try:
            logger.info("\n" + "=" * 60)
            logger.info("STARTING: Combined Workflow (Generate + Publish)")
            logger.info("=" * 60)
            
            # Step 1: Generate content
            logger.info("\nStep 1: Generating Bitcoin content...")
            gen_result = self.job_generate_content()
            
            if not gen_result:
                logger.error("Content generation failed, skipping publishing")
                return False
            
            # Wait for file to be written
            time.sleep(2)
            
            # Step 2: Publish content
            logger.info("\nStep 2: Publishing to Telegram...")
            pub_result = asyncio.run(self.job_publish_content())
            
            if pub_result:
                logger.info("\n✓ Workflow completed successfully")
                logger.info("=" * 60 + "\n")
                return True
            else:
                logger.error("\n✗ Workflow failed at publishing stage")
                logger.info("=" * 60 + "\n")
                return False
        except Exception as e:
            logger.error(f"Error in combined workflow: {e}")
            return False
    
    def schedule_jobs(self):
        """Schedule all jobs"""
        logger.info("Scheduling jobs...")
        
        # Combined workflow at 6:00 AM CET
        schedule.every().day.at("06:00").do(self.job_combined_workflow)
        
        logger.info("✓ Jobs scheduled:")
        logger.info("  - Combined workflow (Generate + Publish) at 06:00 CET")
    
    def run(self):
        """Run the orchestrator"""
        self.schedule_jobs()
        
        logger.info("\n" + "=" * 60)
        logger.info("ARIES76 UNIFIED ORCHESTRATOR STARTED")
        logger.info("=" * 60)
        logger.info(f"Start time: {datetime.now().isoformat()}")
        logger.info("Monitoring for scheduled jobs...")
        logger.info("Press Ctrl+C to stop\n")
        
        try:
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
        except KeyboardInterrupt:
            logger.info("\n" + "=" * 60)
            logger.info("ORCHESTRATOR STOPPED")
            logger.info("=" * 60)

def main():
    """Main function"""
    orchestrator = UnifiedOrchestrator()
    orchestrator.run()

if __name__ == '__main__':
    main()
