"""Dynamic allocation triggers for the portfolio management system."""

import pandas as pd

class DynamicTriggers:
    def __init__(self, prices_df):
        self.prices_df = prices_df

    def check_volatility_trigger(self, window=30, threshold=0.5):
        """Checks if the recent volatility exceeds a threshold compared to the long-term volatility."""
        long_term_vol = self.prices_df.pct_change().rolling(window=window * 6).std().iloc[-1]
        short_term_vol = self.prices_df.pct_change().rolling(window=window).std().iloc[-1]
        return (short_term_vol > long_term_vol * (1 + threshold)).any()

    def check_momentum_trigger(self, short_window=50, long_window=200):
        """Checks for a golden cross or death cross momentum signal."""
        short_mavg = self.prices_df.rolling(window=short_window).mean().iloc[-1]
        long_mavg = self.prices_df.rolling(window=long_window).mean().iloc[-1]
        # Golden cross
        if (self.prices_df.rolling(window=short_window).mean().iloc[-2] < self.prices_df.rolling(window=long_window).mean().iloc[-2]).all() and (short_mavg > long_mavg).all():
            return "golden_cross"
        # Death cross
        if (self.prices_df.rolling(window=short_window).mean().iloc[-2] > self.prices_df.rolling(window=long_window).mean().iloc[-2]).all() and (short_mavg < long_mavg).all():
            return "death_cross"
        return None

if __name__ == '__main__':
    # Example usage with dummy data
    data = {
        'BTC': [50000 + i*100 for i in range(300)],
        'ETH': [3000 + i*10 for i in range(300)]
    }
    prices_df = pd.DataFrame(data)

    trigger_model = DynamicTriggers(prices_df)

    print(f"Volatility Trigger: {trigger_model.check_volatility_trigger()}")
    print(f"Momentum Trigger: {trigger_model.check_momentum_trigger()}")
