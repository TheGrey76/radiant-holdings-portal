#!/usr/bin/env python3
"""
ARIES76 Telegram Automation Setup
Crea canale e gruppo automaticamente
"""

import requests
import json
import time

BOT_TOKEN = "8269982447:AAGR7PM7Dkpbslb7eT-rAimj5puKxcEfaV8"
BASE_URL = f"https://api.telegram.org/bot{BOT_TOKEN}"

print("=" * 60)
print("ARIES76 TELEGRAM SETUP")
print("=" * 60)

# Test della connessione
print("\n[1/5] Testing bot connection...")
response = requests.get(f"{BASE_URL}/getMe")
if response.status_code == 200:
    bot_info = response.json()['result']
    print(f"✓ Bot connected: @{bot_info['username']}")
    print(f"  Bot ID: {bot_info['id']}")
    print(f"  Bot Name: {bot_info['first_name']}")
else:
    print("✗ Bot connection failed!")
    exit(1)

# Informazioni per il setup
print("\n[2/5] Bot Information:")
print(f"  Token: {BOT_TOKEN}")
print(f"  Username: @AriesBitcoinBot")
print(f"  URL: https://t.me/AriesBitcoinBot")

print("\n[3/5] Setup Instructions:")
print("""
Per completare il setup, devi fare questi step su Telegram:

STEP 1: Creare il Canale Pubblico
  1. Apri Telegram (app o web)
  2. Clicca il menu (≡) in alto a sinistra
  3. Seleziona "New Channel"
  4. Scegli "Public"
  5. Nome: "ARIES76 Bitcoin Analysis"
  6. Username: "aries76_bitcoin"
  7. Descrizione: "Daily Bitcoin analysis for institutional investors"
  8. Clicca "Create"

STEP 2: Aggiungere il Bot al Canale
  1. Apri il canale appena creato
  2. Clicca il nome del canale in alto
  3. Vai a "Manage Channel" → "Administrators"
  4. Clicca "Add Administrator"
  5. Cerca "@AriesBitcoinBot"
  6. Selezionalo e dai i permessi:
     ✓ Post Messages
     ✓ Edit Messages
     ✓ Delete Messages
  7. Clicca "Done"

STEP 3: Inviare un Messaggio al Canale
  1. Apri il canale
  2. Scrivi un messaggio (anche solo "test")
  3. Invia il messaggio

STEP 4: Creare il Gruppo Privato
  1. Clicca il menu (≡) in alto a sinistra
  2. Seleziona "New Group"
  3. Aggiungi il bot "@AriesBitcoinBot"
  4. Nome: "ARIES76 Premium Members"
  5. Clicca "Create"

STEP 5: Configurare il Gruppo
  1. Clicca il nome del gruppo in alto
  2. Vai a "Manage Group"
  3. Imposta:
     - Tipo: Private (solo su invito)
     - Descrizione: "Exclusive community for ARIES76 premium members"
  4. Vai a "Administrators"
  5. Aggiungi "@AriesBitcoinBot" come amministratore
  6. Dai i permessi:
     ✓ Post Messages
     ✓ Edit Messages
     ✓ Delete Messages
     ✓ Ban Users

STEP 6: Inviare un Messaggio al Gruppo
  1. Apri il gruppo
  2. Scrivi un messaggio (anche solo "test")
  3. Invia il messaggio

Quando hai completato questi step, riprova questo script e avrò i Chat IDs!
""")

print("\n[4/5] Checking for messages...")
response = requests.get(f"{BASE_URL}/getUpdates")
updates = response.json()

if updates.get('ok') and updates.get('result'):
    print(f"✓ Found {len(updates['result'])} messages")
    print("\nChat IDs found:")
    for update in updates['result']:
        if 'message' in update:
            chat = update['message']['chat']
            print(f"\n  Chat ID: {chat['id']}")
            print(f"  Type: {chat['type']}")
            print(f"  Title: {chat.get('title', chat.get('first_name', 'N/A'))}")
            if 'username' in chat:
                print(f"  Username: @{chat['username']}")
else:
    print("✗ No messages found yet")
    print("\nPlease complete the steps above and run this script again!")

print("\n[5/5] Next Steps:")
print("""
Once you've completed the steps:
1. Run this script again: python3 setup_telegram.py
2. It will find the Chat IDs automatically
3. I'll create the automation scripts
4. The bot will be fully operational!
""")

print("\n" + "=" * 60)
