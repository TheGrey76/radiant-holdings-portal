#!/usr/bin/env python3
"""
ARIES76 Telegram Group Manager
Manages premium member groups and private channels
"""

import logging
from pathlib import Path
from telegram import Bot
from telegram.error import TelegramError
import asyncio

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'group_manager.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class TelegramGroupManager:
    """Manage Telegram groups and premium tiers"""
    
    def __init__(self):
        """Initialize group manager"""
        self.bot_token = "8269982447:AAGR7PM7Dkpbslb7eT-rAimj5puKxcEfaV8"
        self.bot = Bot(token=self.bot_token)
        
        # Premium group details
        self.premium_group_name = "ARIES76 Premium Members"
        self.premium_group_description = """
🔐 ARIES76 Premium Members Group

Exclusive access to:
✓ Advanced Bitcoin analysis
✓ Trading signals
✓ Market insights
✓ Direct consultation with analysts
✓ Premium reports

Join our premium tier for full access!
https://www.aries76.com
"""
        
        logger.info("Telegram Group Manager initialized")
    
    async def create_premium_group(self):
        """Create premium members group"""
        try:
            logger.info("Creating premium members group")
            
            # Note: Groups must be created manually in Telegram
            # This function provides instructions
            instructions = """
To create the premium members group manually:

1. Open Telegram
2. Create a new group: "ARIES76 Premium Members"
3. Add @AriesBitcoinBot as administrator
4. Set group description:
   
   🔐 ARIES76 Premium Members Group
   
   Exclusive access to:
   ✓ Advanced Bitcoin analysis
   ✓ Trading signals
   ✓ Market insights
   ✓ Direct consultation
   ✓ Premium reports
   
   Join premium tier: https://www.aries76.com

5. Copy the group ID from the URL or use @userinfobot
6. Add the group ID to the .env file as TELEGRAM_PREMIUM_GROUP_ID
"""
            logger.info(instructions)
            return instructions
        except Exception as e:
            logger.error(f"Error creating premium group: {e}")
            return None
    
    async def send_to_group(self, group_id, message_text):
        """Send message to a specific group"""
        try:
            logger.info(f"Sending message to group {group_id}")
            
            # Split long messages
            max_length = 4096
            if len(message_text) > max_length:
                messages = [message_text[i:i+max_length] 
                           for i in range(0, len(message_text), max_length)]
            else:
                messages = [message_text]
            
            for msg in messages:
                await self.bot.send_message(
                    chat_id=group_id,
                    text=msg,
                    parse_mode='HTML'
                )
                logger.info("Message sent to group")
                await asyncio.sleep(1)
            
            return True
        except TelegramError as e:
            logger.error(f"Telegram error: {e}")
            return False
        except Exception as e:
            logger.error(f"Error sending to group: {e}")
            return False
    
    async def send_premium_alert(self, group_id, alert_data):
        """Send premium alert to group"""
        try:
            message = f"""
<b>🎯 Premium Alert</b>

{alert_data.get('title', 'Market Update')}

<b>Analysis:</b>
{alert_data.get('analysis', 'N/A')}

<b>Recommendation:</b>
{alert_data.get('recommendation', 'N/A')}

<b>Confidence Level:</b> {alert_data.get('confidence', 'N/A')}

<i>This analysis is exclusive to ARIES76 Premium Members</i>
"""
            return await self.send_to_group(group_id, message)
        except Exception as e:
            logger.error(f"Error sending premium alert: {e}")
            return False

async def main():
    """Main function"""
    manager = TelegramGroupManager()
    instructions = await manager.create_premium_group()
    print(instructions)

if __name__ == '__main__':
    asyncio.run(main())
