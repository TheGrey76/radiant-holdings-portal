#!/usr/bin/env python3
"""
Simple runner script for manual execution of the automation
Can be called directly or via cron
"""

import sys
import os

# Add project to path
sys.path.insert(0, '/home/ubuntu/bitcoin_automation')

from automation_orchestrator import AutomationOrchestrator

def main():
    """Run the automation"""
    
    orchestrator = AutomationOrchestrator()
    result = orchestrator.run_daily_automation()
    
    return 0 if result["overall_status"] == "success" else 1

if __name__ == "__main__":
    sys.exit(main())
