import React, { useState, useEffect } from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface PortfolioMetrics {
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdown: number;
  volatility: number;
  expectedReturn: number;
  var95: number;
  cvar95: number;
}

interface AllocationData {
  name: string;
  value: number;
  color: string;
}

interface TimeseriesData {
  date: string;
  value: number;
  allocation: string;
}

const AdvancedPortfolioDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<PortfolioMetrics | null>(null);
  const [allocation, setAllocation] = useState<AllocationData[]>([]);
  const [timeseries, setTimeseries] = useState<TimeseriesData[]>([]);
  const [fearGreedIndex, setFearGreedIndex] = useState<number>(50);
  const [onchainMetrics, setOnchainMetrics] = useState<number>(1.5);

  useEffect(() => {
    // Fetch portfolio metrics from API
    const fetchMetrics = async () => {
      try {
        const response = await fetch('/api/portfolio/metrics');
        const data = await response.json();
        setMetrics(data);
      } catch (error) {
        console.error('Error fetching metrics:', error);
      }
    };

    // Fetch allocation data
    const fetchAllocation = async () => {
      try {
        const response = await fetch('/api/portfolio/allocation');
        const data = await response.json();
        setAllocation(data);
      } catch (error) {
        console.error('Error fetching allocation:', error);
      }
    };

    // Fetch timeseries data
    const fetchTimeseries = async () => {
      try {
        const response = await fetch('/api/portfolio/timeseries');
        const data = await response.json();
        setTimeseries(data);
      } catch (error) {
        console.error('Error fetching timeseries:', error);
      }
    };

    // Fetch sentiment data
    const fetchSentiment = async () => {
      try {
        const response = await fetch('/api/sentiment/fear-greed');
        const data = await response.json();
        setFearGreedIndex(data.value);
      } catch (error) {
        console.error('Error fetching sentiment:', error);
      }
    };

    fetchMetrics();
    fetchAllocation();
    fetchTimeseries();
    fetchSentiment();
  }, []);

  const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1', '#d084d0'];

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <h1 className="text-3xl font-bold mb-6">Advanced Portfolio Dashboard</h1>

      {/* Key Metrics */}
      {metrics && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-sm font-semibold text-gray-600">Sharpe Ratio</h3>
            <p className="text-2xl font-bold text-blue-600">{metrics.sharpeRatio.toFixed(2)}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-sm font-semibold text-gray-600">Sortino Ratio</h3>
            <p className="text-2xl font-bold text-green-600">{metrics.sortinoRatio.toFixed(2)}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-sm font-semibold text-gray-600">Max Drawdown</h3>
            <p className="text-2xl font-bold text-red-600">{(metrics.maxDrawdown * 100).toFixed(2)}%</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-sm font-semibold text-gray-600">Volatility</h3>
            <p className="text-2xl font-bold text-orange-600">{(metrics.volatility * 100).toFixed(2)}%</p>
          </div>
        </div>
      )}

      {/* Sentiment & On-Chain Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Fear & Greed Index</h3>
          <div className="flex items-center justify-between">
            <div className="text-4xl font-bold text-indigo-600">{fearGreedIndex}</div>
            <div className="text-sm text-gray-600">
              {fearGreedIndex < 25 ? 'Extreme Fear' : fearGreedIndex < 45 ? 'Fear' : fearGreedIndex < 55 ? 'Neutral' : fearGreedIndex < 75 ? 'Greed' : 'Extreme Greed'}
            </div>
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">On-Chain Metrics (MVRV Z-Score)</h3>
          <div className="flex items-center justify-between">
            <div className="text-4xl font-bold text-purple-600">{onchainMetrics.toFixed(2)}</div>
            <div className="text-sm text-gray-600">
              {onchainMetrics < 0 ? 'Undervalued' : onchainMetrics < 1 ? 'Fair Value' : 'Overvalued'}
            </div>
          </div>
        </div>
      </div>

      {/* Allocation Pie Chart */}
      {allocation.length > 0 && (
        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <h3 className="text-lg font-semibold mb-4">Current Allocation</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={allocation} cx="50%" cy="50%" labelLine={false} label dataKey="value" outerRadius={100}>
                {allocation.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => `${(value * 100).toFixed(2)}%`} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Portfolio Value Timeseries */}
      {timeseries.length > 0 && (
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4">Portfolio Value Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={timeseries}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="value" stroke="#8884d8" name="Portfolio Value" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
};

export default AdvancedPortfolioDashboard;
