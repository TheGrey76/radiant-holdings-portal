#!/usr/bin/env python3
"""
Script to generate and publish Ethereum analysis to Telegram.
"""

import requests
import subprocess

# Telegram Bot Token and Channel
BOT_TOKEN = "8269982447:AAFEMS6qWKAfRt_CXuqB763LZf6VpgKzJeg"
CHANNEL_ID = "@aries76_bitcoin"
TELEGRAM_API_URL = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"

# Generate the analysis
print("📊 Generando analisi avanzata per Ethereum...")
result = subprocess.run(
    ["python3", "advanced_content_generator.py", "--symbol", "ETH-USD", "--correlation_assets", "SPY,GLD"],
    capture_output=True,
    text=True
)

if result.returncode != 0:
    print(f"❌ Errore nella generazione dell'analisi: {result.stderr}")
    exit(1)

analysis_message = result.stdout.strip()

# Publish to Telegram
print("📤 Pubblicando su Telegram...")
payload = {
    "chat_id": CHANNEL_ID,
    "text": analysis_message,
    "parse_mode": "Markdown"
}

response = requests.post(TELEGRAM_API_URL, json=payload)

if response.status_code == 200:
    print("✅ Analisi pubblicata con successo su @aries76_bitcoin!")
    print("\n" + "="*60)
    print("MESSAGGIO PUBBLICATO:")
    print("="*60)
    print(analysis_message)
    print("="*60)
else:
    print(f"❌ Errore nella pubblicazione: {response.status_code}")
    print(response.text)
