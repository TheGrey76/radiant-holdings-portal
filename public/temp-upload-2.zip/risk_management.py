"""Risk management and metrics engine for the portfolio management system."""

import numpy as np
import pandas as pd
from scipy.stats import norm

class RiskManagement:
    def __init__(self, returns_series, risk_free_rate=0.02):
        self.returns = returns_series
        self.risk_free_rate = risk_free_rate

    def get_sharpe_ratio(self, annualization_factor=252):
        """Calculates the annualized Sharpe Ratio."""
        excess_returns = self.returns - self.risk_free_rate / annualization_factor
        return np.sqrt(annualization_factor) * excess_returns.mean() / excess_returns.std()

    def get_sortino_ratio(self, annualization_factor=252):
        """Calculates the annualized Sortino Ratio."""
        excess_returns = self.returns - self.risk_free_rate / annualization_factor
        downside_returns = excess_returns[excess_returns < 0]
        downside_std = downside_returns.std()
        if downside_std == 0:
            return np.inf
        return np.sqrt(annualization_factor) * excess_returns.mean() / downside_std

    def get_var(self, confidence_level=0.95):
        """Calculates the Value at Risk (VaR)."""
        return self.returns.quantile(1 - confidence_level)

    def get_cvar(self, confidence_level=0.95):
        """Calculates the Conditional Value at Risk (CVaR)."""
        var = self.get_var(confidence_level)
        return self.returns[self.returns <= var].mean()

if __name__ == '__main__':
    # Example usage with dummy data
    np.random.seed(42)
    returns_series = pd.Series(np.random.normal(0.001, 0.02, 1000))

    risk_model = RiskManagement(returns_series)

    print(f"Sharpe Ratio: {risk_model.get_sharpe_ratio():.2f}")
    print(f"Sortino Ratio: {risk_model.get_sortino_ratio():.2f}")
    print(f"Value at Risk (95%): {risk_model.get_var():.2%}")
    print(f"Conditional VaR (95%): {risk_model.get_cvar():.2%}")
