#!/usr/bin/env python3
"""API wrapper for portfolio management operations."""

import sys
import json
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta

from dynamic_allocation import DynamicAllocation
from risk_management import RiskManagement

def fetch_market_data(symbols, period="1y"):
    """Fetch market data for the given symbols."""
    data = yf.download(symbols, period=period, progress=False)
    return data['Close']

def get_portfolio_allocation(model_name):
    """Get the current portfolio allocation for the specified model."""
    symbols = ['BTC-USD', 'ETH-USD', '^GSPC', 'GLD']
    prices_df = fetch_market_data(symbols)
    
    allocation_model = DynamicAllocation(prices_df)
    
    if model_name == "conservative":
        weights = allocation_model.get_hrp_allocation()
    elif model_name == "balanced":
        weights = allocation_model.get_mean_variance_allocation(target_volatility=0.15)
    elif model_name == "aggressive":
        market_caps = {"BTC-USD": 1e12, "ETH-USD": 4e11, "^GSPC": 4e11, "GLD": 1e11}
        view_dict = {"BTC-USD": 0.20, "ETH-USD": 0.25}
        weights = allocation_model.get_black_litterman_allocation(market_caps, view_dict, risk_aversion=2.5)
    else:
        weights = {}
    
    return {
        "model": model_name,
        "allocation": {k: float(v) for k, v in weights.items()},
        "timestamp": datetime.now().isoformat()
    }

def get_risk_metrics(model_name):
    """Get risk metrics for the specified model."""
    symbols = ['BTC-USD', 'ETH-USD', '^GSPC', 'GLD']
    prices_df = fetch_market_data(symbols)
    returns = prices_df.pct_change().dropna()
    
    # Calculate portfolio returns based on allocation
    allocation_model = DynamicAllocation(prices_df)
    if model_name == "conservative":
        weights = allocation_model.get_hrp_allocation()
    elif model_name == "balanced":
        weights = allocation_model.get_mean_variance_allocation(target_volatility=0.15)
    elif model_name == "aggressive":
        market_caps = {"BTC-USD": 1e12, "ETH-USD": 4e11, "^GSPC": 4e11, "GLD": 1e11}
        view_dict = {"BTC-USD": 0.20, "ETH-USD": 0.25}
        weights = allocation_model.get_black_litterman_allocation(market_caps, view_dict, risk_aversion=2.5)
    else:
        weights = {symbol: 0.25 for symbol in symbols}
    
    # Calculate weighted portfolio returns
    portfolio_returns = sum(returns[symbol] * weights.get(symbol, 0) for symbol in symbols)
    
    risk_model = RiskManagement(portfolio_returns)
    
    return {
        "model": model_name,
        "sharpe_ratio": float(risk_model.get_sharpe_ratio()),
        "sortino_ratio": float(risk_model.get_sortino_ratio()),
        "var_95": float(risk_model.get_var()),
        "cvar_95": float(risk_model.get_cvar()),
        "timestamp": datetime.now().isoformat()
    }

def main():
    if len(sys.argv) < 3:
        print(json.dumps({"error": "Missing arguments"}))
        sys.exit(1)
    
    model_name = sys.argv[1]
    action = sys.argv[2]
    
    if action == "allocation":
        result = get_portfolio_allocation(model_name)
    elif action == "risk":
        result = get_risk_metrics(model_name)
    else:
        result = {"error": "Unknown action"}
    
    print(json.dumps(result))

if __name__ == "__main__":
    main()
