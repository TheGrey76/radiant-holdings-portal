#!/usr/bin/env python3
"""
ARIES76 System Monitor
Monitors and reports on the status of all automation systems
"""

import os
import sys
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
import subprocess

# Add paths
sys.path.insert(0, '/home/ubuntu/bitcoin_automation')
sys.path.insert(0, '/home/ubuntu/telegram_automation')

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'system_monitor.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class SystemMonitor:
    """Monitor all ARIES76 automation systems"""
    
    def __init__(self):
        """Initialize monitor"""
        self.bitcoin_dir = Path('/home/ubuntu/bitcoin_automation')
        self.telegram_dir = Path('/home/ubuntu/telegram_automation')
        self.content_dir = self.bitcoin_dir / 'generated_content'
        self.logs_dir = self.telegram_dir / 'logs'
        
        logger.info("System Monitor initialized")
    
    def check_bitcoin_generator(self):
        """Check Bitcoin content generator status"""
        try:
            # Check if process is running
            result = subprocess.run(
                ['pgrep', '-f', 'bitcoin_content_generator.py'],
                capture_output=True
            )
            is_running = result.returncode == 0
            
            # Check latest content
            articles = sorted(self.content_dir.glob('article_*.md'))
            latest_article = None
            if articles:
                latest_article = articles[-1]
                age = datetime.now() - datetime.fromtimestamp(latest_article.stat().st_mtime)
            else:
                age = None
            
            return {
                'status': 'running' if is_running else 'stopped',
                'latest_content': str(latest_article) if latest_article else None,
                'content_age_hours': age.total_seconds() / 3600 if age else None,
                'content_count': len(articles)
            }
        except Exception as e:
            logger.error(f"Error checking Bitcoin generator: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def check_telegram_scheduler(self):
        """Check Telegram scheduler status"""
        try:
            # Check if process is running
            result = subprocess.run(
                ['pgrep', '-f', 'telegram_scheduler.py'],
                capture_output=True
            )
            is_running = result.returncode == 0
            
            # Check latest publication
            pub_log = self.logs_dir / 'publications.log'
            latest_pub = None
            if pub_log.exists():
                with open(pub_log, 'r') as f:
                    lines = f.readlines()
                    if lines:
                        latest_pub = lines[-1].strip()
            
            return {
                'status': 'running' if is_running else 'stopped',
                'latest_publication': latest_pub,
                'publications_count': len(lines) if pub_log.exists() else 0
            }
        except Exception as e:
            logger.error(f"Error checking Telegram scheduler: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def check_bot_connection(self):
        """Check Telegram bot connection"""
        try:
            import asyncio
            from telegram_bot import ARIES76TelegramBot
            
            async def test():
                bot = ARIES76TelegramBot()
                return await bot.test_connection()
            
            result = asyncio.run(test())
            return {
                'status': 'connected' if result else 'disconnected',
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error checking bot connection: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def check_disk_space(self):
        """Check disk space usage"""
        try:
            import shutil
            
            total, used, free = shutil.disk_usage('/')
            
            return {
                'total_gb': total / (1024**3),
                'used_gb': used / (1024**3),
                'free_gb': free / (1024**3),
                'used_percent': (used / total) * 100
            }
        except Exception as e:
            logger.error(f"Error checking disk space: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def check_logs_health(self):
        """Check logs for errors"""
        try:
            errors = {}
            
            for log_file in self.logs_dir.glob('*.log'):
                try:
                    with open(log_file, 'r') as f:
                        content = f.read()
                        error_count = content.count('ERROR')
                        warning_count = content.count('WARNING')
                        
                        errors[log_file.name] = {
                            'error_count': error_count,
                            'warning_count': warning_count,
                            'size_kb': log_file.stat().st_size / 1024
                        }
                except Exception as e:
                    logger.error(f"Error reading {log_file}: {e}")
            
            return errors
        except Exception as e:
            logger.error(f"Error checking logs: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def generate_report(self):
        """Generate comprehensive system report"""
        try:
            report = {
                'timestamp': datetime.now().isoformat(),
                'bitcoin_generator': self.check_bitcoin_generator(),
                'telegram_scheduler': self.check_telegram_scheduler(),
                'bot_connection': self.check_bot_connection(),
                'disk_space': self.check_disk_space(),
                'logs_health': self.check_logs_health()
            }
            
            return report
        except Exception as e:
            logger.error(f"Error generating report: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def print_report(self, report):
        """Print formatted report"""
        print("\n" + "="*60)
        print("ARIES76 SYSTEM STATUS REPORT")
        print("="*60)
        print(f"Timestamp: {report.get('timestamp', 'N/A')}\n")
        
        # Bitcoin Generator
        print("📊 BITCOIN CONTENT GENERATOR")
        print("-" * 60)
        bg = report.get('bitcoin_generator', {})
        print(f"  Status: {bg.get('status', 'N/A')}")
        print(f"  Latest Content: {bg.get('latest_content', 'N/A')}")
        if bg.get('content_age_hours'):
            print(f"  Content Age: {bg['content_age_hours']:.1f} hours")
        print(f"  Content Count: {bg.get('content_count', 0)}\n")
        
        # Telegram Scheduler
        print("🤖 TELEGRAM SCHEDULER")
        print("-" * 60)
        ts = report.get('telegram_scheduler', {})
        print(f"  Status: {ts.get('status', 'N/A')}")
        print(f"  Latest Publication: {ts.get('latest_publication', 'N/A')}")
        print(f"  Total Publications: {ts.get('publications_count', 0)}\n")
        
        # Bot Connection
        print("🔗 BOT CONNECTION")
        print("-" * 60)
        bc = report.get('bot_connection', {})
        print(f"  Status: {bc.get('status', 'N/A')}\n")
        
        # Disk Space
        print("💾 DISK SPACE")
        print("-" * 60)
        ds = report.get('disk_space', {})
        if 'error' not in ds:
            print(f"  Total: {ds.get('total_gb', 0):.1f} GB")
            print(f"  Used: {ds.get('used_gb', 0):.1f} GB ({ds.get('used_percent', 0):.1f}%)")
            print(f"  Free: {ds.get('free_gb', 0):.1f} GB\n")
        else:
            print(f"  Error: {ds.get('error', 'N/A')}\n")
        
        # Logs Health
        print("📝 LOGS HEALTH")
        print("-" * 60)
        lh = report.get('logs_health', {})
        for log_name, stats in lh.items():
            if isinstance(stats, dict) and 'error_count' in stats:
                print(f"  {log_name}:")
                print(f"    Errors: {stats.get('error_count', 0)}")
                print(f"    Warnings: {stats.get('warning_count', 0)}")
                print(f"    Size: {stats.get('size_kb', 0):.1f} KB")
        
        print("\n" + "="*60 + "\n")
    
    def save_report(self, report):
        """Save report to file"""
        try:
            report_file = self.logs_dir / f"system_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2)
            logger.info(f"Report saved to {report_file}")
            return report_file
        except Exception as e:
            logger.error(f"Error saving report: {e}")
            return None

def main():
    """Main function"""
    monitor = SystemMonitor()
    
    # Generate report
    report = monitor.generate_report()
    
    # Print report
    monitor.print_report(report)
    
    # Save report
    monitor.save_report(report)

if __name__ == '__main__':
    main()
