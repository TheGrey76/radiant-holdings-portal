#!/usr/bin/env python3
"""
Bitcoin Content Automation - Scheduler
Runs the automation daily at 6:00 AM CET
"""

import os
import sys
import logging
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
import pytz

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from automation_orchestrator import AutomationOrchestrator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def run_automation():
    """Run the automation workflow"""
    logger.info("=" * 80)
    logger.info("Starting Bitcoin Content Automation")
    logger.info("=" * 80)
    
    try:
        orchestrator = AutomationOrchestrator()
        result = orchestrator.run()
        
        if result.get('success'):
            logger.info("✓ Automation completed successfully")
        else:
            logger.error(f"✗ Automation failed: {result.get('error')}")
    except Exception as e:
        logger.error(f"✗ Error running automation: {str(e)}", exc_info=True)
    
    logger.info("=" * 80)

def main():
    """Start the scheduler"""
    logger.info("Bitcoin Content Automation Scheduler Starting")
    logger.info(f"Current time: {datetime.now()}")
    
    # Create scheduler
    scheduler = BackgroundScheduler()
    
    # Set timezone
    tz = pytz.timezone('Europe/Rome')  # CET timezone
    
    # Schedule the job for 6:00 AM CET every day
    scheduler.add_job(
        run_automation,
        CronTrigger(hour=6, minute=0, timezone=tz),
        id='bitcoin_automation',
        name='Bitcoin Content Automation',
        replace_existing=True
    )
    
    logger.info("Scheduler configured:")
    logger.info("  - Job: Bitcoin Content Automation")
    logger.info("  - Trigger: Daily at 6:00 AM CET")
    logger.info("  - Timezone: Europe/Rome")
    
    # Start scheduler
    scheduler.start()
    logger.info("✓ Scheduler started successfully")
    logger.info("Press Ctrl+C to stop the scheduler")
    
    try:
        # Keep the scheduler running
        while True:
            pass
    except KeyboardInterrupt:
        logger.info("Scheduler stopped by user")
        scheduler.shutdown()
        sys.exit(0)

if __name__ == '__main__':
    main()
