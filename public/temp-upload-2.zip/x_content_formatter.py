#!/usr/bin/env python3
"""
X (Twitter) Content Formatter
Formats Bitcoin and Digital Assets content for X (Twitter)
"""

import logging
from pathlib import Path
from bitcoin_data_fetcher import BitcoinDataFetcher
from digital_assets_news_generator import DigitalAssetsNewsGenerator

logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'x_content_formatter.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class XContentFormatter:
    """Format content for X (Twitter)"""
    
    def __init__(self):
        self.bitcoin_fetcher = BitcoinDataFetcher()
        self.news_generator = DigitalAssetsNewsGenerator()
        logger.info("X Content Formatter initialized")
    
    def format_bitcoin_morning_tweet(self):
        """Format morning Bitcoin analysis tweet"""
        try:
            logger.info("Formatting morning Bitcoin tweet...")
            
            data = self.bitcoin_fetcher.fetch_bitcoin_data()
            
            if not data:
                logger.error("Failed to fetch Bitcoin data")
                return None
            
            price = data.get('price', 0)
            change_24h = data.get('change_24h', 0)
            signal = data.get('signal', 'HOLD')
            resistance = data.get('resistance', 0)
            support = data.get('support', 0)
            
            # Format signal emoji
            signal_emoji = "🟢" if signal == "BUY" else "🔴" if signal == "SELL" else "🟡"
            
            # Create tweet (max 280 chars)
            tweet = f"""📊 Bitcoin Analysis - Morning Update

Price: ${price:,.0f}
24h Change: {change_24h:+.2f}%
Signal: {signal_emoji} {signal}

Resistance: ${resistance:,.0f}
Support: ${support:,.0f}

🔗 Full Report: https://www.aries76.com/bitcoin-2026-report-preview

#Bitcoin #Crypto #Trading"""
            
            logger.info("✓ Morning tweet formatted")
            return tweet
        
        except Exception as e:
            logger.error(f"Error formatting morning tweet: {e}")
            return None
    
    def format_bitcoin_evening_tweet(self):
        """Format evening Bitcoin analysis tweet"""
        try:
            logger.info("Formatting evening Bitcoin tweet...")
            
            data = self.bitcoin_fetcher.fetch_bitcoin_data()
            news = self.bitcoin_fetcher.fetch_bitcoin_news()
            
            if not data:
                logger.error("Failed to fetch Bitcoin data")
                return None
            
            price = data.get('price', 0)
            change_24h = data.get('change_24h', 0)
            
            # Get top news headline
            top_news = ""
            if news:
                top_news = f"\n📰 {news[0].get('title', '')[:80]}"
            
            # Create tweet
            tweet = f"""📈 Bitcoin Evening Update

Price: ${price:,.0f}
24h Change: {change_24h:+.2f}%
{top_news}

Get the full analysis:
https://www.aries76.com/bitcoin-2026-report-preview

#Bitcoin #Crypto #News"""
            
            logger.info("✓ Evening tweet formatted")
            return tweet
        
        except Exception as e:
            logger.error(f"Error formatting evening tweet: {e}")
            return None
    
    def format_digital_assets_news_tweet(self):
        """Format digital assets news tweet"""
        try:
            logger.info("Formatting digital assets news tweet...")
            
            articles = self.news_generator.fetch_digital_assets_news()
            
            if not articles:
                logger.error("Failed to fetch news")
                return None
            
            # Get top 3 headlines
            headlines = []
            for article in articles[:3]:
                title = article.get('title', '')
                if len(title) > 60:
                    title = title[:57] + "..."
                headlines.append(f"• {title}")
            
            # Create tweet
            tweet = f"""🌍 Digital Assets News Update

{chr(10).join(headlines)}

Read more: https://www.aries76.com/bitcoin-2026-report-preview

#Crypto #Blockchain #Web3 #DigitalAssets"""
            
            logger.info("✓ Digital assets news tweet formatted")
            return tweet
        
        except Exception as e:
            logger.error(f"Error formatting digital assets tweet: {e}")
            return None
    
    def format_bitcoin_thread(self):
        """Format Bitcoin analysis as thread"""
        try:
            logger.info("Formatting Bitcoin thread...")
            
            data = self.bitcoin_fetcher.fetch_bitcoin_data()
            news = self.bitcoin_fetcher.fetch_bitcoin_news()
            
            if not data:
                logger.error("Failed to fetch Bitcoin data")
                return None
            
            price = data.get('price', 0)
            change_24h = data.get('change_24h', 0)
            market_cap = data.get('market_cap', 0)
            signal = data.get('signal', 'HOLD')
            resistance = data.get('resistance', 0)
            support = data.get('support', 0)
            
            tweets = [
                f"""1/5 📊 Bitcoin Technical Analysis

Price: ${price:,.0f}
24h Change: {change_24h:+.2f}%
Market Cap: ${market_cap/1e12:.2f}T

#Bitcoin #Crypto""",
                
                f"""2/5 📈 Key Levels

Resistance: ${resistance:,.0f}
Support: ${support:,.0f}

Watch these levels for breakouts!

#Trading""",
                
                f"""3/5 🎯 Trading Signal

Current Signal: {signal}

Based on technical indicators and market sentiment

#Analysis""",
                
                f"""4/5 📰 Latest News

Top story: {news[0].get('title', '')[:100] if news else 'No news available'}

#News""",
                
                f"""5/5 🔗 Full Report

Get complete analysis and trading signals:
https://www.aries76.com/bitcoin-2026-report-preview

Subscribe for daily updates!

#Bitcoin #Crypto #Trading"""
            ]
            
            logger.info("✓ Bitcoin thread formatted (5 tweets)")
            return tweets
        
        except Exception as e:
            logger.error(f"Error formatting thread: {e}")
            return None

def main():
    """Test the formatter"""
    formatter = XContentFormatter()
    
    print("=" * 70)
    print("MORNING BITCOIN TWEET:")
    print("=" * 70)
    morning = formatter.format_bitcoin_morning_tweet()
    if morning:
        print(morning)
        print(f"\nLength: {len(morning)} characters")
    
    print("\n" + "=" * 70)
    print("EVENING BITCOIN TWEET:")
    print("=" * 70)
    evening = formatter.format_bitcoin_evening_tweet()
    if evening:
        print(evening)
        print(f"\nLength: {len(evening)} characters")
    
    print("\n" + "=" * 70)
    print("DIGITAL ASSETS NEWS TWEET:")
    print("=" * 70)
    news = formatter.format_digital_assets_news_tweet()
    if news:
        print(news)
        print(f"\nLength: {len(news)} characters")

if __name__ == '__main__':
    main()
