#!/usr/bin/env python3
"""
ARIES76 Premium Tier Manager
Manages premium subscriptions and user tiers
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from enum import Enum
import asyncio

# Configure logging
logs_dir = Path('/home/ubuntu/telegram_automation/logs')
logs_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(logs_dir / 'premium_tier.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class SubscriptionTier(Enum):
    """Subscription tiers"""
    FREE = "free"
    PREMIUM = "premium"
    ENTERPRISE = "enterprise"

class PremiumTierManager:
    """Manage premium subscriptions and user tiers"""
    
    def __init__(self):
        """Initialize premium tier manager"""
        self.data_dir = Path('/home/ubuntu/telegram_automation/data')
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.users_file = self.data_dir / 'users.json'
        self.subscriptions_file = self.data_dir / 'subscriptions.json'
        
        # Load existing data
        self.users = self._load_users()
        self.subscriptions = self._load_subscriptions()
        
        logger.info("Premium Tier Manager initialized")
    
    def _load_users(self):
        """Load users from file"""
        try:
            if self.users_file.exists():
                with open(self.users_file, 'r') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            logger.error(f"Error loading users: {e}")
            return {}
    
    def _load_subscriptions(self):
        """Load subscriptions from file"""
        try:
            if self.subscriptions_file.exists():
                with open(self.subscriptions_file, 'r') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            logger.error(f"Error loading subscriptions: {e}")
            return {}
    
    def _save_users(self):
        """Save users to file"""
        try:
            with open(self.users_file, 'w') as f:
                json.dump(self.users, f, indent=2)
            logger.info(f"Users saved: {len(self.users)} users")
        except Exception as e:
            logger.error(f"Error saving users: {e}")
    
    def _save_subscriptions(self):
        """Save subscriptions to file"""
        try:
            with open(self.subscriptions_file, 'w') as f:
                json.dump(self.subscriptions, f, indent=2)
            logger.info(f"Subscriptions saved: {len(self.subscriptions)} subscriptions")
        except Exception as e:
            logger.error(f"Error saving subscriptions: {e}")
    
    def add_user(self, user_id, username, email=None, tier=SubscriptionTier.FREE):
        """Add a new user"""
        try:
            if str(user_id) in self.users:
                logger.warning(f"User {user_id} already exists")
                return False
            
            self.users[str(user_id)] = {
                'user_id': user_id,
                'username': username,
                'email': email,
                'tier': tier.value,
                'created_at': datetime.now().isoformat(),
                'updated_at': datetime.now().isoformat()
            }
            
            self._save_users()
            logger.info(f"User added: {username} (ID: {user_id})")
            return True
        except Exception as e:
            logger.error(f"Error adding user: {e}")
            return False
    
    def upgrade_to_premium(self, user_id, duration_days=30):
        """Upgrade user to premium tier"""
        try:
            if str(user_id) not in self.users:
                logger.warning(f"User {user_id} not found")
                return False
            
            # Update user tier
            self.users[str(user_id)]['tier'] = SubscriptionTier.PREMIUM.value
            self.users[str(user_id)]['updated_at'] = datetime.now().isoformat()
            
            # Create subscription
            subscription_id = f"sub_{user_id}_{int(datetime.now().timestamp())}"
            self.subscriptions[subscription_id] = {
                'subscription_id': subscription_id,
                'user_id': user_id,
                'tier': SubscriptionTier.PREMIUM.value,
                'start_date': datetime.now().isoformat(),
                'end_date': (datetime.now() + timedelta(days=duration_days)).isoformat(),
                'status': 'active'
            }
            
            self._save_users()
            self._save_subscriptions()
            
            logger.info(f"User {user_id} upgraded to premium for {duration_days} days")
            return True
        except Exception as e:
            logger.error(f"Error upgrading user: {e}")
            return False
    
    def get_user_tier(self, user_id):
        """Get user's current tier"""
        try:
            user = self.users.get(str(user_id))
            if not user:
                return SubscriptionTier.FREE
            
            tier_str = user.get('tier', 'free')
            return SubscriptionTier(tier_str)
        except Exception as e:
            logger.error(f"Error getting user tier: {e}")
            return SubscriptionTier.FREE
    
    def is_premium(self, user_id):
        """Check if user is premium"""
        try:
            tier = self.get_user_tier(user_id)
            return tier in [SubscriptionTier.PREMIUM, SubscriptionTier.ENTERPRISE]
        except Exception as e:
            logger.error(f"Error checking premium status: {e}")
            return False
    
    def get_premium_users(self):
        """Get all premium users"""
        try:
            premium_users = []
            for user_id, user_data in self.users.items():
                if user_data.get('tier') in ['premium', 'enterprise']:
                    premium_users.append(user_data)
            
            logger.info(f"Found {len(premium_users)} premium users")
            return premium_users
        except Exception as e:
            logger.error(f"Error getting premium users: {e}")
            return []
    
    def get_active_subscriptions(self):
        """Get all active subscriptions"""
        try:
            active_subs = []
            now = datetime.now()
            
            for sub_id, sub_data in self.subscriptions.items():
                end_date = datetime.fromisoformat(sub_data.get('end_date', ''))
                if end_date > now and sub_data.get('status') == 'active':
                    active_subs.append(sub_data)
            
            logger.info(f"Found {len(active_subs)} active subscriptions")
            return active_subs
        except Exception as e:
            logger.error(f"Error getting active subscriptions: {e}")
            return []
    
    def renew_subscription(self, subscription_id, duration_days=30):
        """Renew a subscription"""
        try:
            if subscription_id not in self.subscriptions:
                logger.warning(f"Subscription {subscription_id} not found")
                return False
            
            sub = self.subscriptions[subscription_id]
            
            # Update end date
            current_end = datetime.fromisoformat(sub.get('end_date', datetime.now().isoformat()))
            new_end = current_end + timedelta(days=duration_days)
            
            sub['end_date'] = new_end.isoformat()
            sub['status'] = 'active'
            
            self._save_subscriptions()
            logger.info(f"Subscription {subscription_id} renewed until {new_end.isoformat()}")
            return True
        except Exception as e:
            logger.error(f"Error renewing subscription: {e}")
            return False
    
    def cancel_subscription(self, subscription_id):
        """Cancel a subscription"""
        try:
            if subscription_id not in self.subscriptions:
                logger.warning(f"Subscription {subscription_id} not found")
                return False
            
            self.subscriptions[subscription_id]['status'] = 'cancelled'
            
            # Downgrade user to free
            user_id = self.subscriptions[subscription_id].get('user_id')
            if user_id and str(user_id) in self.users:
                self.users[str(user_id)]['tier'] = SubscriptionTier.FREE.value
            
            self._save_subscriptions()
            self._save_users()
            
            logger.info(f"Subscription {subscription_id} cancelled")
            return True
        except Exception as e:
            logger.error(f"Error cancelling subscription: {e}")
            return False
    
    def get_subscription_stats(self):
        """Get subscription statistics"""
        try:
            total_users = len(self.users)
            premium_users = len(self.get_premium_users())
            active_subs = len(self.get_active_subscriptions())
            
            stats = {
                'total_users': total_users,
                'free_users': total_users - premium_users,
                'premium_users': premium_users,
                'active_subscriptions': active_subs,
                'premium_percentage': (premium_users / total_users * 100) if total_users > 0 else 0
            }
            
            logger.info(f"Stats: {stats}")
            return stats
        except Exception as e:
            logger.error(f"Error getting stats: {e}")
            return {}
    
    def send_premium_content(self, user_id, content):
        """Send premium content to user"""
        try:
            if not self.is_premium(user_id):
                logger.warning(f"User {user_id} is not premium")
                return False
            
            # This would integrate with Telegram to send content
            logger.info(f"Sending premium content to user {user_id}")
            return True
        except Exception as e:
            logger.error(f"Error sending premium content: {e}")
            return False
    
    def generate_report(self):
        """Generate premium tier report"""
        try:
            report = {
                'timestamp': datetime.now().isoformat(),
                'statistics': self.get_subscription_stats(),
                'premium_users': self.get_premium_users(),
                'active_subscriptions': self.get_active_subscriptions()
            }
            
            return report
        except Exception as e:
            logger.error(f"Error generating report: {e}")
            return {}

def main():
    """Main function for testing"""
    manager = PremiumTierManager()
    
    # Add test users
    manager.add_user(123456, "test_user1", "user1@example.com", SubscriptionTier.FREE)
    manager.add_user(234567, "test_user2", "user2@example.com", SubscriptionTier.FREE)
    
    # Upgrade to premium
    manager.upgrade_to_premium(123456, 30)
    
    # Get stats
    stats = manager.get_subscription_stats()
    print(f"\nSubscription Stats:")
    print(f"  Total users: {stats['total_users']}")
    print(f"  Premium users: {stats['premium_users']}")
    print(f"  Free users: {stats['free_users']}")
    print(f"  Premium percentage: {stats['premium_percentage']:.1f}%")
    
    # Generate report
    report = manager.generate_report()
    print(f"\nReport generated: {report['timestamp']}")

if __name__ == '__main__':
    main()
