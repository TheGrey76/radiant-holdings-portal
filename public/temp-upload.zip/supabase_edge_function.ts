// Supabase Edge Function: Bitcoin Report Daily Updater
// File: supabase/functions/bitcoin-report-updater/index.ts
// Esecuzione: Ogni giorno alle 6:00 AM CET tramite pg_cron

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Configurazione
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
const FRED_API_KEY = Deno.env.get("FRED_API_KEY") || "";

// Inizializza Supabase client
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

// API Endpoints
const COINGECKO_API = "https://api.coingecko.com/api/v3";
const FRED_API = "https://api.stlouisfed.org/fred";

interface BitcoinData {
  timestamp: string;
  bitcoin: {
    price_usd: number;
    price_eur: number;
    market_cap_usd: number;
    volume_24h: number;
    change_24h: number;
  };
  macro: {
    m2_value: number;
    real_rate: number;
    unemployment_rate: number;
    inflation_rate: number;
  };
  model: {
    current_regime: string;
    regime_confidence: number;
    price_target_low: number;
    price_target_high: number;
    probability: number;
    institutional_target: number;
  };
}

/**
 * Raccoglie dati Bitcoin da CoinGecko
 */
async function fetchBitcoinData(): Promise<any> {
  console.log("📊 Raccogliendo dati Bitcoin...");

  try {
    // Prezzo Bitcoin attuale
    const priceResponse = await fetch(
      `${COINGECKO_API}/simple/price?ids=bitcoin&vs_currencies=usd,eur&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true`
    );
    const priceData = await priceResponse.json();
    const btc = priceData.bitcoin;

    // Dati on-chain
    const coinResponse = await fetch(
      `${COINGECKO_API}/coins/bitcoin?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false`
    );
    const coinData = await coinResponse.json();

    const bitcoinData = {
      price_usd: btc.usd,
      price_eur: btc.eur,
      market_cap_usd: btc.usd_market_cap,
      volume_24h: btc.usd_24h_vol,
      change_24h: btc.usd_24h_change,
      ath_usd: coinData.market_data.ath.usd,
      atl_usd: coinData.market_data.atl.usd,
      circulating_supply: coinData.market_data.circulating_supply,
    };

    console.log(`✓ Prezzo Bitcoin: $${bitcoinData.price_usd}`);
    return bitcoinData;
  } catch (error) {
    console.error("✗ Errore nel recupero dati Bitcoin:", error);
    throw error;
  }
}

/**
 * Raccoglie dati macro da FRED
 */
async function fetchMacroData(): Promise<any> {
  console.log("📈 Raccogliendo dati macro...");

  try {
    const macroData: any = {};

    // M2 Money Supply
    const m2Response = await fetch(
      `${FRED_API}/series/observations?series_id=M2SL&api_key=${FRED_API_KEY}&limit=1&sort_order=desc`
    );
    const m2Data = await m2Response.json();
    macroData.m2_value = parseFloat(m2Data.observations[0].value);
    macroData.m2_date = m2Data.observations[0].date;

    // Real Interest Rates
    const realRateResponse = await fetch(
      `${FRED_API}/series/observations?series_id=REAINTRATREARAT10Y&api_key=${FRED_API_KEY}&limit=1&sort_order=desc`
    );
    const realRateData = await realRateResponse.json();
    macroData.real_rate = parseFloat(realRateData.observations[0].value);

    // Unemployment Rate
    const unemploymentResponse = await fetch(
      `${FRED_API}/series/observations?series_id=UNRATE&api_key=${FRED_API_KEY}&limit=1&sort_order=desc`
    );
    const unemploymentData = await unemploymentResponse.json();
    macroData.unemployment_rate = parseFloat(unemploymentData.observations[0].value);

    // Inflation Rate (CPI)
    const inflationResponse = await fetch(
      `${FRED_API}/series/observations?series_id=CPIAUCSL&api_key=${FRED_API_KEY}&limit=1&sort_order=desc`
    );
    const inflationData = await inflationResponse.json();
    macroData.inflation_rate = parseFloat(inflationData.observations[0].value);

    console.log(`✓ M2: ${macroData.m2_value}`);
    console.log(`✓ Real Rate: ${macroData.real_rate}%`);

    return macroData;
  } catch (error) {
    console.error("✗ Errore nel recupero dati macro:", error);
    throw error;
  }
}

/**
 * Calcola il regime attuale del modello
 */
function calculateModelRegime(macroData: any): any {
  console.log("🎯 Calcolando regime del modello...");

  const m2 = macroData.m2_value || 0;
  const realRate = macroData.real_rate || 0;

  // Logica semplificata per regime identification
  let regime = "ACCUMULATION";
  let regimeScore = 0.6;
  let priceLow = 96000;
  let priceHigh = 132000;
  let probability = 0.6;

  if (realRate < 0 && m2 > 0) {
    regime = "EXPANSION";
    regimeScore = 0.85;
    priceLow = 180000;
    priceHigh = 260000;
    probability = 0.25;
  } else if (realRate > 2 && m2 < 0) {
    regime = "STRESS";
    regimeScore = 0.15;
    priceLow = 45000;
    priceHigh = 60000;
    probability = 0.15;
  }

  const modelData = {
    current_regime: regime,
    regime_confidence: regimeScore,
    price_target_low: priceLow,
    price_target_high: priceHigh,
    probability: probability,
    institutional_target: 138000,
  };

  console.log(`✓ Regime: ${regime} (Confidence: ${regimeScore * 100}%)`);

  return modelData;
}

/**
 * Salva i dati in Supabase
 */
async function saveToSupabase(data: BitcoinData): Promise<void> {
  console.log("💾 Salvando dati in Supabase...");

  try {
    const record = {
      timestamp: data.timestamp,
      bitcoin_price_usd: data.bitcoin.price_usd,
      bitcoin_price_eur: data.bitcoin.price_eur,
      bitcoin_market_cap: data.bitcoin.market_cap_usd,
      bitcoin_volume_24h: data.bitcoin.volume_24h,
      bitcoin_change_24h: data.bitcoin.change_24h,
      m2_value: data.macro.m2_value,
      real_rate: data.macro.real_rate,
      unemployment_rate: data.macro.unemployment_rate,
      inflation_rate: data.macro.inflation_rate,
      current_regime: data.model.current_regime,
      regime_confidence: data.model.regime_confidence,
      price_target_low: data.model.price_target_low,
      price_target_high: data.model.price_target_high,
      probability: data.model.probability,
      institutional_target: data.model.institutional_target,
      raw_data: data,
    };

    // Inserisci nella tabella storica
    const { error: insertError } = await supabase
      .from("bitcoin_report_data")
      .insert([record]);

    if (insertError) throw insertError;

    console.log("✓ Dati salvati nella tabella storica");

    // Aggiorna la tabella "latest"
    const latestRecord = {
      id: 1,
      timestamp: data.timestamp,
      bitcoin_price_usd: data.bitcoin.price_usd,
      current_regime: data.model.current_regime,
      price_target_low: data.model.price_target_low,
      price_target_high: data.model.price_target_high,
      institutional_target: data.model.institutional_target,
      raw_data: data,
    };

    const { error: upsertError } = await supabase
      .from("bitcoin_report_latest")
      .upsert([latestRecord]);

    if (upsertError) throw upsertError;

    console.log("✓ Tabella 'latest' aggiornata");

    // Registra l'aggiornamento nel log
    const { error: logError } = await supabase
      .from("bitcoin_report_updates_log")
      .insert([
        {
          update_timestamp: data.timestamp,
          status: "success",
          bitcoin_data_updated: true,
          macro_data_updated: true,
          model_updated: true,
          execution_time_ms: Date.now(),
        },
      ]);

    if (logError) throw logError;

    console.log("✓ Log aggiornamento registrato");
  } catch (error) {
    console.error("✗ Errore nel salvataggio in Supabase:", error);
    throw error;
  }
}

/**
 * Funzione principale
 */
async function updateBitcoinReport(): Promise<void> {
  console.log("=".repeat(60));
  console.log("🚀 Inizio aggiornamento Bitcoin Report");
  console.log("=".repeat(60));

  try {
    const timestamp = new Date().toISOString();

    // Raccoglie dati
    const bitcoinData = await fetchBitcoinData();
    const macroData = await fetchMacroData();
    const modelData = calculateModelRegime(macroData);

    // Prepara i dati completi
    const data: BitcoinData = {
      timestamp,
      bitcoin: bitcoinData,
      macro: macroData,
      model: modelData,
    };

    // Salva in database
    await saveToSupabase(data);

    console.log("=".repeat(60));
    console.log("✅ Aggiornamento completato con successo!");
    console.log("=".repeat(60));
  } catch (error) {
    console.error("=".repeat(60));
    console.error("❌ Errore durante l'aggiornamento:", error);
    console.error("=".repeat(60));
    throw error;
  }
}

/**
 * Handler HTTP per la Edge Function
 */
serve(async (req) => {
  // Verifica il metodo HTTP
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  // Verifica il token di autorizzazione (opzionale ma consigliato)
  const authHeader = req.headers.get("authorization");
  const expectedToken = Deno.env.get("EDGE_FUNCTION_SECRET") || "secret";

  if (authHeader !== `Bearer ${expectedToken}`) {
    return new Response("Unauthorized", { status: 401 });
  }

  try {
    await updateBitcoinReport();

    return new Response(
      JSON.stringify({
        success: true,
        message: "Bitcoin Report updated successfully",
        timestamp: new Date().toISOString(),
      }),
      {
        headers: { "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Edge Function Error:", error);

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      }),
      {
        headers: { "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});
