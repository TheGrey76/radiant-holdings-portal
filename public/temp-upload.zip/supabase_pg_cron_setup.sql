-- Supabase pg_cron Setup
-- Configura l'esecuzione automatica della Edge Function ogni giorno alle 6:00 AM CET

-- NOTA: pg_cron è disponibile in Supabase ma potrebbe essere disabilitato per default
-- Se ricevi errore "extension pg_cron not found", contatta Supabase support per abilitarlo

-- 1. Abilita l'estensione pg_cron (se non è già abilitata)
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- 2. Crea una funzione che chiama la Edge Function
CREATE OR REPLACE FUNCTION public.call_bitcoin_report_updater()
RETURNS void AS $$
DECLARE
  response RECORD;
BEGIN
  -- Chiama la Edge Function
  SELECT 
    status,
    content::text as body
  INTO response
  FROM http_post(
    'https://YOUR_PROJECT_ID.supabase.co/functions/v1/bitcoin-report-updater',
    '{}',
    'application/json',
    ARRAY[
      http_header('Authorization', 'Bearer YOUR_EDGE_FUNCTION_SECRET'),
      http_header('Content-Type', 'application/json')
    ]
  );
  
  -- Log della risposta
  INSERT INTO bitcoin_report_updates_log (
    update_timestamp,
    status,
    bitcoin_data_updated,
    macro_data_updated,
    model_updated,
    execution_time_ms
  ) VALUES (
    NOW(),
    CASE WHEN response.status = 200 THEN 'success' ELSE 'failed' END,
    response.status = 200,
    response.status = 200,
    response.status = 200,
    0
  );
  
  RAISE NOTICE 'Bitcoin Report Updater called. Status: %', response.status;
END;
$$ LANGUAGE plpgsql;

-- 3. Configura il cron job per eseguire ogni giorno alle 6:00 AM CET
-- Formato: minuto ora giorno_mese mese giorno_settimana
-- 0 6 * * * = Ogni giorno alle 6:00 AM
-- NOTA: Supabase usa UTC, quindi per CET (UTC+1) devi usare 5:00 AM UTC

SELECT cron.schedule(
  'bitcoin-report-daily-update',  -- Nome del job
  '0 5 * * *',                    -- 5:00 AM UTC = 6:00 AM CET (durante ora solare)
  'SELECT public.call_bitcoin_report_updater()'
);

-- ALTERNATIVA: Se durante l'ora legale (CEST = UTC+2), usa 4:00 AM UTC
-- SELECT cron.schedule(
--   'bitcoin-report-daily-update',
--   '0 4 * * *',  -- 4:00 AM UTC = 6:00 AM CEST
--   'SELECT public.call_bitcoin_report_updater()'
-- );

-- 4. Visualizza i cron jobs configurati
SELECT * FROM cron.job;

-- 5. Visualizza la cronologia dei cron jobs
SELECT * FROM cron.job_run_details ORDER BY start_time DESC LIMIT 10;

-- 6. Per disabilitare il cron job (se necessario)
-- SELECT cron.unschedule('bitcoin-report-daily-update');

-- 7. Per modificare il cron job
-- SELECT cron.alter_job(
--   job_id := (SELECT jobid FROM cron.job WHERE jobname = 'bitcoin-report-daily-update'),
--   schedule := '0 6 * * *'
-- );
