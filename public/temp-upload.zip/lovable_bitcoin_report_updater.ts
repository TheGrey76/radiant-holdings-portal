/**
 * Bitcoin 2026 Report - Daily Data Updater
 * File unico per Lovable
 * 
 * Installazione:
 * 1. Copia questo file in: server/api/bitcoin-report-updater.ts
 * 2. Configura le variabili di ambiente nel file .env
 * 3. Aggiungi il cron job nel tuo package.json o usa un servizio esterno
 * 
 * Uso:
 * - POST /api/bitcoin-report-updater per eseguire manualmente
 * - Configura un cron job per eseguire automaticamente ogni giorno alle 6:00 AM CET
 */

import type { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@supabase/supabase-js';

// ============================================================================
// CONFIGURAZIONE
// ============================================================================

const SUPABASE_URL = process.env.SUPABASE_URL || '';
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const FRED_API_KEY = process.env.FRED_API_KEY || '';
const API_SECRET = process.env.BITCOIN_UPDATER_SECRET || 'secret';

const COINGECKO_API = 'https://api.coingecko.com/api/v3';
const FRED_API = 'https://api.stlouisfed.org/fred';

// ============================================================================
// TIPI DI DATI
// ============================================================================

interface BitcoinData {
  price_usd: number;
  price_eur: number;
  market_cap_usd: number;
  volume_24h: number;
  change_24h: number;
  ath_usd?: number;
  atl_usd?: number;
  circulating_supply?: number;
}

interface MacroData {
  m2_value: number;
  m2_date: string;
  real_rate: number;
  unemployment_rate: number;
  inflation_rate: number;
}

interface ModelData {
  current_regime: string;
  regime_confidence: number;
  price_target_low: number;
  price_target_high: number;
  probability: number;
  institutional_target: number;
}

interface UpdateResponse {
  success: boolean;
  message: string;
  timestamp: string;
  data?: {
    bitcoin: BitcoinData;
    macro: MacroData;
    model: ModelData;
  };
  error?: string;
}

// ============================================================================
// FUNZIONI DI RACCOLTA DATI
// ============================================================================

/**
 * Raccoglie dati Bitcoin da CoinGecko
 */
async function fetchBitcoinData(): Promise<BitcoinData> {
  console.log('📊 Raccogliendo dati Bitcoin...');

  try {
    // Prezzo Bitcoin attuale
    const priceResponse = await fetch(
      `${COINGECKO_API}/simple/price?ids=bitcoin&vs_currencies=usd,eur&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true`,
      { timeout: 10000 }
    );

    if (!priceResponse.ok) {
      throw new Error(`CoinGecko API error: ${priceResponse.status}`);
    }

    const priceData = await priceResponse.json();
    const btc = priceData.bitcoin;

    // Dati on-chain
    const coinResponse = await fetch(
      `${COINGECKO_API}/coins/bitcoin?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false`,
      { timeout: 10000 }
    );

    if (!coinResponse.ok) {
      throw new Error(`CoinGecko API error: ${coinResponse.status}`);
    }

    const coinData = await coinResponse.json();

    const bitcoinData: BitcoinData = {
      price_usd: btc.usd,
      price_eur: btc.eur,
      market_cap_usd: btc.usd_market_cap,
      volume_24h: btc.usd_24h_vol,
      change_24h: btc.usd_24h_change,
      ath_usd: coinData.market_data?.ath?.usd,
      atl_usd: coinData.market_data?.atl?.usd,
      circulating_supply: coinData.market_data?.circulating_supply,
    };

    console.log(`✓ Prezzo Bitcoin: $${bitcoinData.price_usd}`);
    return bitcoinData;
  } catch (error) {
    console.error('✗ Errore nel recupero dati Bitcoin:', error);
    throw error;
  }
}

/**
 * Raccoglie dati macro da FRED
 */
async function fetchMacroData(): Promise<MacroData> {
  console.log('📈 Raccogliendo dati macro...');

  try {
    const macroData: any = {};

    // M2 Money Supply
    const m2Response = await fetch(
      `${FRED_API}/series/observations?series_id=M2SL&api_key=${FRED_API_KEY}&limit=1&sort_order=desc`,
      { timeout: 10000 }
    );

    if (!m2Response.ok) {
      throw new Error(`FRED API error: ${m2Response.status}`);
    }

    const m2Data = await m2Response.json();
    macroData.m2_value = parseFloat(m2Data.observations[0].value);
    macroData.m2_date = m2Data.observations[0].date;

    // Real Interest Rates
    const realRateResponse = await fetch(
      `${FRED_API}/series/observations?series_id=REAINTRATREARAT10Y&api_key=${FRED_API_KEY}&limit=1&sort_order=desc`,
      { timeout: 10000 }
    );

    if (!realRateResponse.ok) {
      throw new Error(`FRED API error: ${realRateResponse.status}`);
    }

    const realRateData = await realRateResponse.json();
    macroData.real_rate = parseFloat(realRateData.observations[0].value);

    // Unemployment Rate
    const unemploymentResponse = await fetch(
      `${FRED_API}/series/observations?series_id=UNRATE&api_key=${FRED_API_KEY}&limit=1&sort_order=desc`,
      { timeout: 10000 }
    );

    if (!unemploymentResponse.ok) {
      throw new Error(`FRED API error: ${unemploymentResponse.status}`);
    }

    const unemploymentData = await unemploymentResponse.json();
    macroData.unemployment_rate = parseFloat(unemploymentData.observations[0].value);

    // Inflation Rate (CPI)
    const inflationResponse = await fetch(
      `${FRED_API}/series/observations?series_id=CPIAUCSL&api_key=${FRED_API_KEY}&limit=1&sort_order=desc`,
      { timeout: 10000 }
    );

    if (!inflationResponse.ok) {
      throw new Error(`FRED API error: ${inflationResponse.status}`);
    }

    const inflationData = await inflationResponse.json();
    macroData.inflation_rate = parseFloat(inflationData.observations[0].value);

    console.log(`✓ M2: ${macroData.m2_value}`);
    console.log(`✓ Real Rate: ${macroData.real_rate}%`);

    return macroData as MacroData;
  } catch (error) {
    console.error('✗ Errore nel recupero dati macro:', error);
    throw error;
  }
}

/**
 * Calcola il regime attuale del modello
 */
function calculateModelRegime(macroData: MacroData): ModelData {
  console.log('🎯 Calcolando regime del modello...');

  const m2 = macroData.m2_value || 0;
  const realRate = macroData.real_rate || 0;

  let regime = 'ACCUMULATION';
  let regimeScore = 0.6;
  let priceLow = 96000;
  let priceHigh = 132000;
  let probability = 0.6;

  if (realRate < 0 && m2 > 0) {
    regime = 'EXPANSION';
    regimeScore = 0.85;
    priceLow = 180000;
    priceHigh = 260000;
    probability = 0.25;
  } else if (realRate > 2 && m2 < 0) {
    regime = 'STRESS';
    regimeScore = 0.15;
    priceLow = 45000;
    priceHigh = 60000;
    probability = 0.15;
  }

  const modelData: ModelData = {
    current_regime: regime,
    regime_confidence: regimeScore,
    price_target_low: priceLow,
    price_target_high: priceHigh,
    probability: probability,
    institutional_target: 138000,
  };

  console.log(`✓ Regime: ${regime} (Confidence: ${regimeScore * 100}%)`);

  return modelData;
}

/**
 * Salva i dati in Supabase
 */
async function saveToSupabase(
  timestamp: string,
  bitcoinData: BitcoinData,
  macroData: MacroData,
  modelData: ModelData
): Promise<void> {
  console.log('💾 Salvando dati in Supabase...');

  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const record = {
      timestamp,
      bitcoin_price_usd: bitcoinData.price_usd,
      bitcoin_price_eur: bitcoinData.price_eur,
      bitcoin_market_cap: bitcoinData.market_cap_usd,
      bitcoin_volume_24h: bitcoinData.volume_24h,
      bitcoin_change_24h: bitcoinData.change_24h,
      m2_value: macroData.m2_value,
      real_rate: macroData.real_rate,
      unemployment_rate: macroData.unemployment_rate,
      inflation_rate: macroData.inflation_rate,
      current_regime: modelData.current_regime,
      regime_confidence: modelData.regime_confidence,
      price_target_low: modelData.price_target_low,
      price_target_high: modelData.price_target_high,
      probability: modelData.probability,
      institutional_target: modelData.institutional_target,
      raw_data: {
        bitcoin: bitcoinData,
        macro: macroData,
        model: modelData,
      },
    };

    // Inserisci nella tabella storica
    const { error: insertError } = await supabase
      .from('bitcoin_report_data')
      .insert([record]);

    if (insertError) throw insertError;

    console.log('✓ Dati salvati nella tabella storica');

    // Aggiorna la tabella "latest"
    const latestRecord = {
      id: 1,
      timestamp,
      bitcoin_price_usd: bitcoinData.price_usd,
      current_regime: modelData.current_regime,
      price_target_low: modelData.price_target_low,
      price_target_high: modelData.price_target_high,
      institutional_target: modelData.institutional_target,
      raw_data: {
        bitcoin: bitcoinData,
        macro: macroData,
        model: modelData,
      },
    };

    const { error: upsertError } = await supabase
      .from('bitcoin_report_latest')
      .upsert([latestRecord]);

    if (upsertError) throw upsertError;

    console.log('✓ Tabella "latest" aggiornata');

    // Registra l'aggiornamento nel log
    const { error: logError } = await supabase
      .from('bitcoin_report_updates_log')
      .insert([
        {
          update_timestamp: timestamp,
          status: 'success',
          bitcoin_data_updated: true,
          macro_data_updated: true,
          model_updated: true,
          execution_time_ms: Date.now(),
        },
      ]);

    if (logError) throw logError;

    console.log('✓ Log aggiornamento registrato');
  } catch (error) {
    console.error('✗ Errore nel salvataggio in Supabase:', error);
    throw error;
  }
}

// ============================================================================
// HANDLER API
// ============================================================================

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<UpdateResponse>
) {
  console.log('='.repeat(60));
  console.log('🚀 Inizio aggiornamento Bitcoin Report');
  console.log('='.repeat(60));

  // Verifica il metodo HTTP
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      message: 'Method not allowed',
      timestamp: new Date().toISOString(),
      error: 'Only POST requests are allowed',
    });
  }

  // Verifica il token di autorizzazione
  const authHeader = req.headers.authorization;
  if (authHeader !== `Bearer ${API_SECRET}`) {
    return res.status(401).json({
      success: false,
      message: 'Unauthorized',
      timestamp: new Date().toISOString(),
      error: 'Invalid or missing authorization token',
    });
  }

  try {
    const timestamp = new Date().toISOString();

    // Raccoglie dati
    const bitcoinData = await fetchBitcoinData();
    const macroData = await fetchMacroData();
    const modelData = calculateModelRegime(macroData);

    // Salva in database
    await saveToSupabase(timestamp, bitcoinData, macroData, modelData);

    console.log('='.repeat(60));
    console.log('✅ Aggiornamento completato con successo!');
    console.log('='.repeat(60));

    return res.status(200).json({
      success: true,
      message: 'Bitcoin Report updated successfully',
      timestamp,
      data: {
        bitcoin: bitcoinData,
        macro: macroData,
        model: modelData,
      },
    });
  } catch (error) {
    console.error('='.repeat(60));
    console.error('❌ Errore durante l\'aggiornamento:', error);
    console.error('='.repeat(60));

    return res.status(500).json({
      success: false,
      message: 'Error updating Bitcoin Report',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
    });
  }
}

// ============================================================================
// ESPORTAZIONE PER USO COME FUNZIONE (per cron job esterno)
// ============================================================================

export async function updateBitcoinReport(): Promise<UpdateResponse> {
  try {
    const timestamp = new Date().toISOString();

    const bitcoinData = await fetchBitcoinData();
    const macroData = await fetchMacroData();
    const modelData = calculateModelRegime(macroData);

    await saveToSupabase(timestamp, bitcoinData, macroData, modelData);

    return {
      success: true,
      message: 'Bitcoin Report updated successfully',
      timestamp,
      data: {
        bitcoin: bitcoinData,
        macro: macroData,
        model: modelData,
      },
    };
  } catch (error) {
    return {
      success: false,
      message: 'Error updating Bitcoin Report',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}
