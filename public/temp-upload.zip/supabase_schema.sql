-- Schema Supabase per Bitcoin Report Data
-- Esegui questi comandi nel tuo database Supabase

-- Tabella storica: Tutti i dati raccolti
CREATE TABLE IF NOT EXISTS bitcoin_report_data (
    id BIGSERIAL PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    -- Dati Bitcoin
    bitcoin_price_usd DECIMAL(15, 2),
    bitcoin_price_eur DECIMAL(15, 2),
    bitcoin_market_cap DECIMAL(20, 2),
    bitcoin_volume_24h DECIMAL(20, 2),
    bitcoin_change_24h DECIMAL(10, 2),
    
    -- Dati Macro
    m2_value DECIMAL(20, 2),
    real_rate DECIMAL(10, 2),
    unemployment_rate DECIMAL(10, 2),
    inflation_rate DECIMAL(10, 2),
    
    -- Dati Modello
    current_regime VARCHAR(50),
    regime_confidence DECIMAL(5, 2),
    price_target_low DECIMAL(15, 2),
    price_target_high DECIMAL(15, 2),
    probability DECIMAL(5, 2),
    institutional_target DECIMAL(15, 2),
    
    -- Dati grezzi JSON
    raw_data JSONB,
    
    -- Metadati
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indici per performance
CREATE INDEX idx_bitcoin_report_data_timestamp ON bitcoin_report_data(timestamp DESC);
CREATE INDEX idx_bitcoin_report_data_regime ON bitcoin_report_data(current_regime);

-- Tabella per accesso rapido ai dati più recenti
CREATE TABLE IF NOT EXISTS bitcoin_report_latest (
    id INTEGER PRIMARY KEY DEFAULT 1,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    bitcoin_price_usd DECIMAL(15, 2),
    bitcoin_price_eur DECIMAL(15, 2),
    m2_value DECIMAL(20, 2),
    real_rate DECIMAL(10, 2),
    current_regime VARCHAR(50),
    regime_confidence DECIMAL(5, 2),
    price_target_low DECIMAL(15, 2),
    price_target_high DECIMAL(15, 2),
    probability DECIMAL(5, 2),
    institutional_target DECIMAL(15, 2),
    raw_data JSONB,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabella per storico dei regimi
CREATE TABLE IF NOT EXISTS bitcoin_regime_history (
    id BIGSERIAL PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    regime VARCHAR(50) NOT NULL,
    confidence DECIMAL(5, 2),
    price_target_low DECIMAL(15, 2),
    price_target_high DECIMAL(15, 2),
    probability DECIMAL(5, 2),
    bitcoin_price_at_time DECIMAL(15, 2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indici per regime history
CREATE INDEX idx_regime_history_timestamp ON bitcoin_regime_history(timestamp DESC);
CREATE INDEX idx_regime_history_regime ON bitcoin_regime_history(regime);

-- Tabella per alert e notifiche
CREATE TABLE IF NOT EXISTS bitcoin_report_alerts (
    id BIGSERIAL PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    alert_type VARCHAR(50),
    alert_message TEXT,
    severity VARCHAR(20), -- 'info', 'warning', 'critical'
    data_snapshot JSONB,
    sent_to_users BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indici per alerts
CREATE INDEX idx_alerts_timestamp ON bitcoin_report_alerts(timestamp DESC);
CREATE INDEX idx_alerts_severity ON bitcoin_report_alerts(severity);

-- Tabella per tracciare gli aggiornamenti
CREATE TABLE IF NOT EXISTS bitcoin_report_updates_log (
    id BIGSERIAL PRIMARY KEY,
    update_timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(50), -- 'success', 'partial', 'failed'
    bitcoin_data_updated BOOLEAN,
    macro_data_updated BOOLEAN,
    model_updated BOOLEAN,
    error_message TEXT,
    execution_time_ms INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indici per update log
CREATE INDEX idx_updates_log_timestamp ON bitcoin_report_updates_log(update_timestamp DESC);
CREATE INDEX idx_updates_log_status ON bitcoin_report_updates_log(status);

-- Tabella per configurazione del report
CREATE TABLE IF NOT EXISTS bitcoin_report_config (
    id INTEGER PRIMARY KEY DEFAULT 1,
    update_frequency VARCHAR(50), -- 'daily', 'weekly', 'monthly'
    update_time_cet VARCHAR(10), -- 'HH:MM' format
    data_sources JSONB,
    price_target_base_low DECIMAL(15, 2),
    price_target_base_high DECIMAL(15, 2),
    price_target_high_low DECIMAL(15, 2),
    price_target_high_high DECIMAL(15, 2),
    price_target_stress_low DECIMAL(15, 2),
    price_target_stress_high DECIMAL(15, 2),
    institutional_target DECIMAL(15, 2),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Inserisci configurazione di default
INSERT INTO bitcoin_report_config (
    id,
    update_frequency,
    update_time_cet,
    data_sources,
    price_target_base_low,
    price_target_base_high,
    price_target_high_low,
    price_target_high_high,
    price_target_stress_low,
    price_target_stress_high,
    institutional_target
) VALUES (
    1,
    'daily',
    '06:00',
    '{"bitcoin": "coingecko", "macro": "fred", "on_chain": "glassnode"}',
    96000,
    132000,
    180000,
    260000,
    45000,
    60000,
    138000
) ON CONFLICT (id) DO NOTHING;

-- Abilita Row Level Security (RLS) per sicurezza
ALTER TABLE bitcoin_report_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE bitcoin_report_latest ENABLE ROW LEVEL SECURITY;
ALTER TABLE bitcoin_regime_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE bitcoin_report_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE bitcoin_report_updates_log ENABLE ROW LEVEL SECURITY;

-- Crea policy per lettura pubblica (i dati sono pubblici)
CREATE POLICY "Allow public read on bitcoin_report_latest" ON bitcoin_report_latest
    FOR SELECT USING (true);

CREATE POLICY "Allow public read on bitcoin_report_data" ON bitcoin_report_data
    FOR SELECT USING (true);

CREATE POLICY "Allow public read on bitcoin_regime_history" ON bitcoin_regime_history
    FOR SELECT USING (true);

-- Crea policy per scrittura solo da admin/backend
CREATE POLICY "Allow admin write on bitcoin_report_latest" ON bitcoin_report_latest
    FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY "Allow admin write on bitcoin_report_data" ON bitcoin_report_data
    FOR ALL USING (auth.role() = 'service_role');

-- Crea funzione per trigger automatico
CREATE OR REPLACE FUNCTION update_bitcoin_report_latest()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE bitcoin_report_latest
    SET 
        timestamp = NEW.timestamp,
        bitcoin_price_usd = NEW.bitcoin_price_usd,
        bitcoin_price_eur = NEW.bitcoin_price_eur,
        m2_value = NEW.m2_value,
        real_rate = NEW.real_rate,
        current_regime = NEW.current_regime,
        regime_confidence = NEW.regime_confidence,
        price_target_low = NEW.price_target_low,
        price_target_high = NEW.price_target_high,
        probability = NEW.probability,
        institutional_target = NEW.institutional_target,
        raw_data = NEW.raw_data,
        updated_at = NOW()
    WHERE id = 1;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Crea trigger per aggiornamento automatico
CREATE TRIGGER trigger_update_latest
AFTER INSERT ON bitcoin_report_data
FOR EACH ROW
EXECUTE FUNCTION update_bitcoin_report_latest();

-- Crea vista per dati aggregati
CREATE OR REPLACE VIEW bitcoin_report_summary AS
SELECT 
    (SELECT bitcoin_price_usd FROM bitcoin_report_latest) as current_price,
    (SELECT current_regime FROM bitcoin_report_latest) as current_regime,
    (SELECT price_target_low FROM bitcoin_report_latest) as target_low,
    (SELECT price_target_high FROM bitcoin_report_latest) as target_high,
    (SELECT institutional_target FROM bitcoin_report_latest) as target_institutional,
    (SELECT COUNT(*) FROM bitcoin_report_data WHERE DATE(timestamp) = CURRENT_DATE) as updates_today,
    (SELECT MAX(timestamp) FROM bitcoin_report_data) as last_update;

-- Commenti per documentazione
COMMENT ON TABLE bitcoin_report_data IS 'Tabella storica con tutti i dati raccolti dal cron job';
COMMENT ON TABLE bitcoin_report_latest IS 'Tabella con i dati più recenti per accesso rapido';
COMMENT ON TABLE bitcoin_regime_history IS 'Storico dei cambiamenti di regime del modello';
COMMENT ON TABLE bitcoin_report_alerts IS 'Alert e notifiche generate dal sistema';
COMMENT ON TABLE bitcoin_report_updates_log IS 'Log di tutti gli aggiornamenti eseguiti';
COMMENT ON TABLE bitcoin_report_config IS 'Configurazione del sistema di aggiornamento';
