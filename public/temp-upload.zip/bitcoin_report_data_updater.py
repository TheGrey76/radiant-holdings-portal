#!/usr/bin/env python3
"""
Bitcoin 2026 Report - Daily Data Updater
Raccoglie dati aggiornati da API pubbliche e li salva in Supabase
Esecuzione: Ogni giorno alle 6:00 AM CET
"""

import os
import json
from datetime import datetime
import requests
from supabase import create_client, Client
import logging

# Configurazione logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/var/log/bitcoin_report_updater.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Configurazione Supabase
SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY")
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# API Endpoints
COINGECKO_API = "https://api.coingecko.com/api/v3"
FRED_API = "https://api.stlouisfed.org/fred"
FRED_API_KEY = os.environ.get("FRED_API_KEY")

class BitcoinReportUpdater:
    """Classe per aggiornare i dati del Bitcoin Report"""
    
    def __init__(self):
        self.timestamp = datetime.utcnow().isoformat()
        self.data = {
            "timestamp": self.timestamp,
            "bitcoin": {},
            "macro": {},
            "model": {}
        }
    
    def fetch_bitcoin_data(self):
        """Raccoglie dati Bitcoin da CoinGecko"""
        try:
            logger.info("Raccogliendo dati Bitcoin...")
            
            # Prezzo Bitcoin attuale
            url = f"{COINGECKO_API}/simple/price"
            params = {
                "ids": "bitcoin",
                "vs_currencies": "usd,eur",
                "include_market_cap": "true",
                "include_24hr_vol": "true",
                "include_24hr_change": "true"
            }
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            btc_data = response.json()["bitcoin"]
            self.data["bitcoin"]["price_usd"] = btc_data.get("usd")
            self.data["bitcoin"]["price_eur"] = btc_data.get("eur")
            self.data["bitcoin"]["market_cap_usd"] = btc_data.get("usd_market_cap")
            self.data["bitcoin"]["volume_24h"] = btc_data.get("usd_24h_vol")
            self.data["bitcoin"]["change_24h"] = btc_data.get("usd_24h_change")
            
            logger.info(f"✓ Prezzo Bitcoin: ${self.data['bitcoin']['price_usd']}")
            
            # Dati on-chain
            url = f"{COINGECKO_API}/coins/bitcoin"
            params = {
                "localization": "false",
                "tickers": "false",
                "market_data": "true",
                "community_data": "false",
                "developer_data": "false"
            }
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            coin_data = response.json()
            self.data["bitcoin"]["ath_usd"] = coin_data["market_data"]["ath"]["usd"]
            self.data["bitcoin"]["atl_usd"] = coin_data["market_data"]["atl"]["usd"]
            self.data["bitcoin"]["circulating_supply"] = coin_data["market_data"]["circulating_supply"]
            
            return True
            
        except Exception as e:
            logger.error(f"✗ Errore nel recupero dati Bitcoin: {str(e)}")
            return False
    
    def fetch_macro_data(self):
        """Raccoglie dati macro (M2, tassi reali) da FRED"""
        try:
            logger.info("Raccogliendo dati macro...")
            
            # M2 Money Supply
            m2_series = "M2SL"  # M2 Money Supply
            url = f"{FRED_API}/series/observations"
            params = {
                "series_id": m2_series,
                "api_key": FRED_API_KEY,
                "limit": 1,
                "sort_order": "desc"
            }
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            m2_data = response.json()["observations"][0]
            self.data["macro"]["m2_value"] = float(m2_data["value"])
            self.data["macro"]["m2_date"] = m2_data["date"]
            
            logger.info(f"✓ M2 Money Supply: {self.data['macro']['m2_value']}")
            
            # Real Interest Rates (10-Year Real Rate)
            real_rate_series = "REAINTRATREARAT10Y"
            params["series_id"] = real_rate_series
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            real_rate_data = response.json()["observations"][0]
            self.data["macro"]["real_rate"] = float(real_rate_data["value"])
            self.data["macro"]["real_rate_date"] = real_rate_data["date"]
            
            logger.info(f"✓ Real Rate: {self.data['macro']['real_rate']}%")
            
            # Unemployment Rate
            unemployment_series = "UNRATE"
            params["series_id"] = unemployment_series
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            unemployment_data = response.json()["observations"][0]
            self.data["macro"]["unemployment_rate"] = float(unemployment_data["value"])
            
            logger.info(f"✓ Unemployment Rate: {self.data['macro']['unemployment_rate']}%")
            
            # Inflation Rate (CPI)
            inflation_series = "CPIAUCSL"
            params["series_id"] = inflation_series
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            inflation_data = response.json()["observations"][0]
            self.data["macro"]["inflation_rate"] = float(inflation_data["value"])
            
            logger.info(f"✓ Inflation Rate: {self.data['macro']['inflation_rate']}%")
            
            return True
            
        except Exception as e:
            logger.error(f"✗ Errore nel recupero dati macro: {str(e)}")
            return False
    
    def calculate_model_regime(self):
        """Calcola il regime attuale del modello basato su M2 e tassi reali"""
        try:
            logger.info("Calcolando regime del modello...")
            
            m2 = self.data["macro"].get("m2_value", 0)
            real_rate = self.data["macro"].get("real_rate", 0)
            btc_price = self.data["bitcoin"].get("price_usd", 0)
            
            # Logica semplificata per regime identification
            # In produzione, usare Hidden Markov Model più sofisticato
            
            if real_rate < 0 and m2 > 0:
                regime = "EXPANSION"
                regime_score = 0.85
            elif real_rate > 2 and m2 < 0:
                regime = "STRESS"
                regime_score = 0.15
            else:
                regime = "ACCUMULATION"
                regime_score = 0.60
            
            self.data["model"]["current_regime"] = regime
            self.data["model"]["regime_confidence"] = regime_score
            
            # Calcolo price targets basato su regime
            if regime == "EXPANSION":
                price_target_low = 180000
                price_target_high = 260000
                probability = 0.25
            elif regime == "STRESS":
                price_target_low = 45000
                price_target_high = 60000
                probability = 0.15
            else:  # ACCUMULATION
                price_target_low = 96000
                price_target_high = 132000
                probability = 0.60
            
            self.data["model"]["price_target_low"] = price_target_low
            self.data["model"]["price_target_high"] = price_target_high
            self.data["model"]["probability"] = probability
            self.data["model"]["institutional_target"] = 138000
            
            logger.info(f"✓ Regime: {regime} (Confidence: {regime_score*100}%)")
            logger.info(f"✓ Price Target: ${price_target_low:,} - ${price_target_high:,}")
            
            return True
            
        except Exception as e:
            logger.error(f"✗ Errore nel calcolo regime: {str(e)}")
            return False
    
    def save_to_supabase(self):
        """Salva i dati nel database Supabase"""
        try:
            logger.info("Salvando dati in Supabase...")
            
            # Prepara i dati per il salvataggio
            record = {
                "timestamp": self.data["timestamp"],
                "bitcoin_price_usd": self.data["bitcoin"].get("price_usd"),
                "bitcoin_price_eur": self.data["bitcoin"].get("price_eur"),
                "bitcoin_market_cap": self.data["bitcoin"].get("market_cap_usd"),
                "bitcoin_volume_24h": self.data["bitcoin"].get("volume_24h"),
                "bitcoin_change_24h": self.data["bitcoin"].get("change_24h"),
                "m2_value": self.data["macro"].get("m2_value"),
                "real_rate": self.data["macro"].get("real_rate"),
                "unemployment_rate": self.data["macro"].get("unemployment_rate"),
                "inflation_rate": self.data["macro"].get("inflation_rate"),
                "current_regime": self.data["model"].get("current_regime"),
                "regime_confidence": self.data["model"].get("regime_confidence"),
                "price_target_low": self.data["model"].get("price_target_low"),
                "price_target_high": self.data["model"].get("price_target_high"),
                "probability": self.data["model"].get("probability"),
                "institutional_target": self.data["model"].get("institutional_target"),
                "raw_data": json.dumps(self.data)
            }
            
            # Inserisci i dati nella tabella
            response = supabase.table("bitcoin_report_data").insert(record).execute()
            
            logger.info(f"✓ Dati salvati in Supabase con ID: {response.data[0]['id']}")
            
            # Aggiorna la tabella di stato per accesso rapido
            latest_record = {
                "id": 1,  # ID fisso per il record "latest"
                "timestamp": self.data["timestamp"],
                "bitcoin_price_usd": self.data["bitcoin"].get("price_usd"),
                "current_regime": self.data["model"].get("current_regime"),
                "price_target_low": self.data["model"].get("price_target_low"),
                "price_target_high": self.data["model"].get("price_target_high"),
                "institutional_target": self.data["model"].get("institutional_target"),
                "raw_data": json.dumps(self.data)
            }
            
            supabase.table("bitcoin_report_latest").upsert(latest_record).execute()
            
            logger.info("✓ Tabella 'latest' aggiornata")
            
            return True
            
        except Exception as e:
            logger.error(f"✗ Errore nel salvataggio in Supabase: {str(e)}")
            return False
    
    def run(self):
        """Esegue l'aggiornamento completo"""
        logger.info("=" * 60)
        logger.info("Inizio aggiornamento dati Bitcoin Report")
        logger.info("=" * 60)
        
        success = True
        
        # Raccoglie dati
        if not self.fetch_bitcoin_data():
            success = False
        
        if not self.fetch_macro_data():
            success = False
        
        # Calcola regime e targets
        if not self.calculate_model_regime():
            success = False
        
        # Salva in database
        if not self.save_to_supabase():
            success = False
        
        if success:
            logger.info("=" * 60)
            logger.info("✓ Aggiornamento completato con successo!")
            logger.info("=" * 60)
        else:
            logger.error("=" * 60)
            logger.error("✗ Aggiornamento completato con errori")
            logger.error("=" * 60)
        
        return success


def main():
    """Funzione principale"""
    updater = BitcoinReportUpdater()
    updater.run()


if __name__ == "__main__":
    main()
