import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

/**
 * Componente React per visualizzare i dati del Bitcoin Report in tempo reale
 * I dati vengono caricati dal database Supabase e aggiornati automaticamente
 */

const SUPABASE_URL = process.env.REACT_APP_SUPABASE_URL;
const SUPABASE_KEY = process.env.REACT_APP_SUPABASE_KEY;
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

export const BitcoinReportLiveData = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdate, setLastUpdate] = useState(null);

  // Carica i dati dal database
  const fetchLatestData = async () => {
    try {
      setLoading(true);
      
      // Recupera i dati più recenti
      const { data: latestData, error: fetchError } = await supabase
        .from('bitcoin_report_latest')
        .select('*')
        .eq('id', 1)
        .single();

      if (fetchError) throw fetchError;

      setData(latestData);
      setLastUpdate(new Date(latestData.timestamp));
      setError(null);
    } catch (err) {
      console.error('Errore nel caricamento dati:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Carica i dati al mount del componente
  useEffect(() => {
    fetchLatestData();

    // Sottoscrivi a cambiamenti in tempo reale
    const subscription = supabase
      .from('bitcoin_report_latest')
      .on('*', payload => {
        console.log('Dati aggiornati:', payload);
        setData(payload.new);
        setLastUpdate(new Date(payload.new.timestamp));
      })
      .subscribe();

    // Cleanup
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  if (loading) {
    return (
      <div className="bitcoin-report-loading">
        <p>Caricamento dati in tempo reale...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bitcoin-report-error">
        <p>Errore nel caricamento dei dati: {error}</p>
        <button onClick={fetchLatestData}>Riprova</button>
      </div>
    );
  }

  if (!data) {
    return <div className="bitcoin-report-empty">Nessun dato disponibile</div>;
  }

  // Formattazione valori
  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  const formatPercent = (value) => {
    return `${value.toFixed(2)}%`;
  };

  const formatDate = (date) => {
    return new Intl.DateTimeFormat('it-IT', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(date));
  };

  // Colore regime
  const getRegimeColor = (regime) => {
    switch (regime) {
      case 'EXPANSION':
        return '#4CAF50'; // Verde
      case 'STRESS':
        return '#f44336'; // Rosso
      case 'ACCUMULATION':
        return '#ff6b35'; // Arancione
      default:
        return '#999';
    }
  };

  return (
    <div className="bitcoin-report-live-data">
      {/* Header con timestamp */}
      <div className="data-header">
        <h2>Bitcoin 2026 Report - Dati in Tempo Reale</h2>
        <p className="last-update">
          Ultimo aggiornamento: {formatDate(lastUpdate)}
          <span className="update-badge">Live</span>
        </p>
      </div>

      {/* Prezzo Bitcoin Attuale */}
      <section className="data-section">
        <h3>Prezzo Bitcoin Attuale</h3>
        <div className="price-display">
          <div className="price-usd">
            <span className="label">USD</span>
            <span className="value">{formatPrice(data.bitcoin_price_usd)}</span>
          </div>
          <div className="price-eur">
            <span className="label">EUR</span>
            <span className="value">{formatPrice(data.bitcoin_price_eur)}</span>
          </div>
        </div>
      </section>

      {/* Regime Attuale */}
      <section className="data-section">
        <h3>Regime di Mercato Attuale</h3>
        <div className="regime-display">
          <div 
            className="regime-badge"
            style={{ borderColor: getRegimeColor(data.current_regime) }}
          >
            <span className="regime-name">{data.current_regime}</span>
            <span className="regime-confidence">
              Confidenza: {formatPercent(data.regime_confidence)}
            </span>
          </div>
        </div>
      </section>

      {/* Price Targets */}
      <section className="data-section">
        <h3>Price Targets 2026</h3>
        <div className="targets-grid">
          <div className="target-card">
            <span className="target-label">Range Obiettivo</span>
            <span className="target-value">
              {formatPrice(data.price_target_low)} - {formatPrice(data.price_target_high)}
            </span>
            <span className="target-probability">
              Probabilità: {formatPercent(data.probability)}
            </span>
          </div>
          <div className="target-card institutional">
            <span className="target-label">Target Istituzionale</span>
            <span className="target-value">{formatPrice(data.institutional_target)}</span>
            <span className="target-note">Valore ponderato per probabilità</span>
          </div>
        </div>
      </section>

      {/* Dati Macro */}
      <section className="data-section">
        <h3>Dati Macroeconomici</h3>
        <div className="macro-grid">
          <div className="macro-item">
            <span className="label">M2 Money Supply</span>
            <span className="value">
              ${(data.raw_data?.macro?.m2_value / 1e12).toFixed(2)}T
            </span>
          </div>
          <div className="macro-item">
            <span className="label">Real Rate</span>
            <span className="value">{formatPercent(data.raw_data?.macro?.real_rate)}</span>
          </div>
          <div className="macro-item">
            <span className="label">Unemployment</span>
            <span className="value">{formatPercent(data.raw_data?.macro?.unemployment_rate)}</span>
          </div>
          <div className="macro-item">
            <span className="label">Inflation</span>
            <span className="value">{formatPercent(data.raw_data?.macro?.inflation_rate)}</span>
          </div>
        </div>
      </section>

      {/* Footer con info aggiornamento */}
      <div className="data-footer">
        <p className="update-info">
          ✓ Dati aggiornati automaticamente ogni giorno alle 6:00 AM CET
        </p>
        <p className="data-source">
          Fonti: CoinGecko (Bitcoin), FRED (Macro Data)
        </p>
      </div>

      <style jsx>{`
        .bitcoin-report-live-data {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          max-width: 1200px;
          margin: 0 auto;
          padding: 2rem;
        }

        .data-header {
          margin-bottom: 2rem;
          border-bottom: 2px solid #ff6b35;
          padding-bottom: 1rem;
        }

        .data-header h2 {
          margin: 0;
          color: #1a1a1a;
          font-size: 2rem;
        }

        .last-update {
          margin: 0.5rem 0 0;
          color: #666;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .update-badge {
          display: inline-block;
          background: #4CAF50;
          color: white;
          padding: 0.25rem 0.75rem;
          border-radius: 20px;
          font-size: 0.75rem;
          font-weight: bold;
        }

        .data-section {
          background: #f9f9f9;
          padding: 1.5rem;
          margin: 1.5rem 0;
          border-radius: 8px;
          border-left: 4px solid #ff6b35;
        }

        .data-section h3 {
          margin: 0 0 1rem;
          color: #1a1a1a;
          font-size: 1.3rem;
        }

        .price-display {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .price-usd,
        .price-eur {
          background: white;
          padding: 1.5rem;
          border-radius: 8px;
          text-align: center;
          border: 1px solid #e0e0e0;
        }

        .price-usd .label,
        .price-eur .label {
          display: block;
          font-size: 0.9rem;
          color: #666;
          margin-bottom: 0.5rem;
        }

        .price-usd .value,
        .price-eur .value {
          display: block;
          font-size: 2rem;
          font-weight: bold;
          color: #ff6b35;
        }

        .regime-display {
          display: flex;
          gap: 1rem;
        }

        .regime-badge {
          background: white;
          border: 2px solid;
          padding: 1.5rem;
          border-radius: 8px;
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .regime-name {
          font-size: 1.5rem;
          font-weight: bold;
          color: #1a1a1a;
        }

        .regime-confidence {
          font-size: 0.9rem;
          color: #666;
        }

        .targets-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .target-card {
          background: white;
          padding: 1.5rem;
          border-radius: 8px;
          border: 1px solid #e0e0e0;
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .target-card.institutional {
          border-color: #ff6b35;
          background: #fffaf7;
        }

        .target-label {
          font-size: 0.9rem;
          color: #666;
          text-transform: uppercase;
          letter-spacing: 1px;
        }

        .target-value {
          font-size: 1.5rem;
          font-weight: bold;
          color: #1a1a1a;
        }

        .target-probability,
        .target-note {
          font-size: 0.85rem;
          color: #888;
        }

        .macro-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
        }

        .macro-item {
          background: white;
          padding: 1rem;
          border-radius: 8px;
          border: 1px solid #e0e0e0;
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .macro-item .label {
          font-size: 0.85rem;
          color: #666;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .macro-item .value {
          font-size: 1.3rem;
          font-weight: bold;
          color: #ff6b35;
        }

        .data-footer {
          margin-top: 2rem;
          padding-top: 1rem;
          border-top: 1px solid #e0e0e0;
          text-align: center;
          color: #666;
          font-size: 0.9rem;
        }

        .update-info,
        .data-source {
          margin: 0.5rem 0;
        }

        .bitcoin-report-loading,
        .bitcoin-report-error,
        .bitcoin-report-empty {
          padding: 2rem;
          text-align: center;
          background: #f9f9f9;
          border-radius: 8px;
          color: #666;
        }

        .bitcoin-report-error button {
          margin-top: 1rem;
          padding: 0.5rem 1.5rem;
          background: #ff6b35;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 1rem;
        }

        .bitcoin-report-error button:hover {
          background: #e55a24;
        }

        @media (max-width: 768px) {
          .bitcoin-report-live-data {
            padding: 1rem;
          }

          .data-header h2 {
            font-size: 1.5rem;
          }

          .price-display,
          .targets-grid {
            grid-template-columns: 1fr;
          }

          .price-usd .value,
          .price-eur .value {
            font-size: 1.5rem;
          }

          .target-value {
            font-size: 1.2rem;
          }
        }
      `}</style>
    </div>
  );
};

export default BitcoinReportLiveData;
